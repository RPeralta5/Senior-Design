﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventsForm03262020.Models
{
    public class EventTableRow
    {
        public int ID { get; set; }
        public DateTime Date { get; set; }
        public string Hours { get; set; }
        public int Attendance { get; set; }
        public string IsAlcoholServed { get; set; }
        public string IsAlcoholSold { get; set; }
    }
}
