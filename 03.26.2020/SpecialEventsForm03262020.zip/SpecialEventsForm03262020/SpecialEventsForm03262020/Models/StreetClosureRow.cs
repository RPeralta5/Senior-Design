﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventsForm03262020.Models
{
    public class StreetClosureRow
    {
        public int ID { get; set; }
        public string StreetName { get; set; }
        public int ZipCode { get; set; }
    }
}
