﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventsForm04012020.Models
{
    public class FormSectionEventLocation
    {
        // Event Location Form Variables
        public string FacilityName { get; set; }
        public string FacilityStreetName { get; set; }
        public string FacilityCity { get; set; }
        public string FacilityState { get; set; }
        public int FacilityZip { get; set; }
        public string OutdoorAreaSize { get; set; }
        public string OutdoorAreaInsured { get; set; }
        public string IsVendorSellingAlcohol { get; set; }
        public string VendorsTableFile { get; set; }
        public string ExhibitorsTableFile { get; set; }
        public string HeldBefore { get; set; }
        public string CertificationOfEventLocationFile { get; set; }
        public string EvacuationPlan { get; set; }
        public string EvacuationPlanDescription { get; set; }
        public string IsThereMedicalPresence { get; set; }
        public string NumOfDoctors { get; set; }
        public string NumOfParamedics { get; set; }
        public string NumOfNurses { get; set; }
        public string NumOfEMTOrEMS { get; set; }
        public string NumOfOther { get; set; }
        public string AmbulanceOnSite { get; set; }

        public string StreetClosure { get; set; }
        public string TrafficMitigation { get; set; }
        public string TrafficMitigationDescription { get; set; }


        //These are already in the controller parameters so these variables are practically for nothing (I Hope)
        public string lACertificationFile { get; set; }
        public string allVendorsCertificationsFile { get; set; }
        public string allBrochuresFile { get; set; }
        public string completeScheduleOfEventsFile { get; set; }
        public string waiverReleasesSignedFile { get; set; }
        public string diagramOrSitePlanFile { get; set; }
        public string fiveYearLossHistoryFile { get; set; }
        public string evacuationParkAndTrafficPlanDiagramFile { get; set; }
    }
}
