﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventsForm04012020.Models
{
    public class EventTableRow
    {
        public int ID { get; set; }
        public DateTime Date { get; set; }
        public string Hours { get; set; }
        public int Attendance { get; set; }
        public string IsAlcoholServed { get; set; }
        public string IsAlcoholSold { get; set; }
        
        public EventTableRow (int id, DateTime date, string hours, int attendance, string isAlcoholServed, string isAlcoholSold)
        {
            this.ID = id;
            this.Date = date;
            this.Hours = hours;
            this.Attendance = attendance;
            this.IsAlcoholServed = isAlcoholServed;
            this.IsAlcoholSold = isAlcoholSold;
        }

        public EventTableRow() {}
        
    }
}
