﻿using System;
namespace Parks_SpecialEvents.Models
{
    public class QueryAmenityImages
    {
        public QueryAmenityImages()
        {
        }

    }
}
