﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Parks_SpecialEvents.Models
{
    public class ReturningProfileInfo
    {
        public int ID { get; set; }
        public string password { get; set; }

        public ReturningProfileInfo(int id, string pw)
        {
            this.ID = id;
            this.password = pw;
        }
        public ReturningProfileInfo() { }

    }
}
