﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Parks_SpecialEvents.Models
{
    public class PastEventRow
    {
        public int ID { get; set; }
        public DateTime DateOfClaim { get; set; }
        public string Claimant { get; set; }
        public string Description { get; set; }
        public DateTime DateOfPaid { get; set; }
        public string TotalIncurred { get; set; }

        public PastEventRow(int id, DateTime dateOfClaim, string claimant, string description,
            DateTime dateOfPaid, string totalIncurred)
        {
            this.ID = id;
            this.DateOfClaim = dateOfClaim;
            this.Claimant = claimant;
            this.Description = description;
            this.DateOfPaid = dateOfPaid;
            this.TotalIncurred = totalIncurred;
        }

        public PastEventRow() { }
    }
}
