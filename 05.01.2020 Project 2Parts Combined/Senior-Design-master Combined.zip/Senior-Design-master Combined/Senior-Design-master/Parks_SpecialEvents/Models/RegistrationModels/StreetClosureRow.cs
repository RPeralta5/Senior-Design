﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Parks_SpecialEvents.Models
{
    public class StreetClosureRow
    {
        public int ID { get; set; }
        public string StreetName { get; set; }
        public string ZipCode { get; set; }

        public StreetClosureRow(int id, string streetName, string zipCode)
        {
            this.ID = id;
            this.StreetName = streetName;
            this.ZipCode = zipCode;
        }

        public StreetClosureRow() { }
    }
}
