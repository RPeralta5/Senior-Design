﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Parks_SpecialEvents.Models
{
    public class FinalSectionPermit
    {
        public string Name { get; set; }
        public string Radio { get; set; }
        public string Approval { get; set; }
        public DateTime SignedDate { get; set; }

        public FinalSectionPermit(string rowName)
        {
            this.Name = rowName;
        }
    }
}
