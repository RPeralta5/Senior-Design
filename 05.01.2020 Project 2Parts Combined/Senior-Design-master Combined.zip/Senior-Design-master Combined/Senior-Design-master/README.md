# Senior-Design
2019-2020 Senior Design Project

Group 6: S.E.R.F. 

Special Event Registration & F.A.Q.

Team Lead: Ryan Peralta

QA Lead: Jonathan Wang

Development Lead: Jose Garcia

Documentation Lead: Tony Orellana

Interface Lead: Huy Nguyen

Parks Department Liaison: Feza Sanigok

ISD Liaisons: Andrew Charlton and Alan Zabaro

Advisor: Keenan Knaur



