﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LAParks1.Models
{
    public class ApplicationInformationModel
    { 
        public int ApplicantId { get; set; }
        public string InsurerRole { get; set; }
        public string NameInsured { get; set; }
        public string Dba { get; set; }//Doing Business As
        public string MailingAddress { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zipcode { get; set; }
        public string ContactPerson { get; set; }
        public string Email { get; set; }
        public string HomeNumber { get; set; }
        public string BusinessNumber { get; set; }
        public string Fax { get; set; }
        public string Website { get; set; }
    }   

}
