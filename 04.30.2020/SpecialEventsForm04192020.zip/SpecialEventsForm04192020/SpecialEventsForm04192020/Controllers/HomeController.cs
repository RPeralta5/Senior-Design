﻿using System;
using System.Collections;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SpecialEventsForm04192020.Models;

namespace SpecialEventsForm04192020.Controllers
{
    public class HomeController : Controller
    {
        //Password encryption
        private string Encrypt(string clearText)
        {
            string EncryptionKey = "2020LAPARKSANDREACREATION";
            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    clearText = Convert.ToBase64String(ms.ToArray());
                }
            }
            return clearText;
        }

        //Password decryption
        private string Decrypt(string cipherText)
        {
            string EncryptionKey = "2020LAPARKSANDREACREATION";
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }

        public IActionResult ReturningApplicationForm(ReturningProfileInfo loginCredentials)
        {
            // Model to hold information retreived from database and returned to view
            RegisterInformation profile = new RegisterInformation(0, null);


            // Connection String
            string connectionString = @"Data Source=DESKTOP-FSJF92K\JWSQL;Initial Catalog=cs4961;Integrated Security=True";

            if (loginCredentials.ID == 0)
            {
                loginCredentials.ID = 1;
            }
            if (loginCredentials.password == null)
            {
                loginCredentials.password = "__";
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////
            // Get information from Importent Notice table

            using (SqlConnection connection = new SqlConnection(
            connectionString))
            {
                string queryImportantNoticeString = "Use cs4961; " +
                    "Select * from ImportantNotice " + "Where ImportantNotice.ID = " + "\'" + loginCredentials.ID.ToString() + "\'" + " AND " +
                    "ImportantNotice.Password = " + "\'" + Encrypt(loginCredentials.password.ToString()) + "\';";

                connection.Open();
                SqlCommand command = new SqlCommand(queryImportantNoticeString, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    profile.ApplicationID = (int)reader[0];
                    profile.Agreement = (string)reader[1];
                    profile.Password = Decrypt((string)reader[2]);
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////
            // Get information from Application Information table

            using (SqlConnection connection = new SqlConnection(
            connectionString))
            {
                string queryApplicationInformationString = "Use cs4961; " + "Select * from ApplicationInformation " + "Where ApplicationInformation.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command = new SqlCommand(queryApplicationInformationString, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.NameIsAIndividual = (string)reader[1];
                    profile.NameIsACorporation = (string)reader[2];
                    profile.NameIsATrustOfEstate = (string)reader[3];
                    profile.NameIsAUnicorpAssoc = (string)reader[4];
                    profile.NameIsAGeneralPartnership = (string)reader[5];
                    profile.NameIsALLCorLLP = (string)reader[6];
                    profile.NameIsAPublicAgency = (string)reader[7];
                    profile.NameIsALaborUnion = (string)reader[8];
                    profile.NameIsAInformalGroup = (string)reader[9];
                    profile.NameIsALimitedPartnership = (string)reader[10];
                    profile.NameIsANotForProfit = (string)reader[11];
                    profile.NameIsARegliousGroup = (string)reader[12];
                    profile.NameIsAJointVenture = (string)reader[13];

                    profile.NameIsAOther = (string)reader[14];
                    profile.NameIsAOtherIs = (string)reader[15];  // This is for textbox

                    profile.NameAsAppeared = (string)reader[16];
                    profile.DoingBusinessAs = (string)reader[17];
                    profile.MailingAddress = (string)reader[18];
                    profile.ApplicantCity = (string)reader[19];
                    profile.ApplicantState = (string)reader[20];
                    profile.ApplicantZip = (string)reader[21];
                    profile.ApplicantContact = (string)reader[22];
                    profile.ApplicantEmail = (string)reader[23];
                    profile.ApplicantHomePhone = (string)reader[24];
                    profile.ApplicantBusinessPhone = (string)reader[25];
                    profile.ApplicantFax = (string)reader[26];
                    profile.ApplicantWebAddress = (string)reader[27];
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////
            // Get information from Event Information table           

            using (SqlConnection connection = new SqlConnection(
            connectionString))
            {
                string queryEventInformationString = "Use cs4961; " + "Select * from EventInformation " + "Where EventInformation.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command = new SqlCommand(queryEventInformationString, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.EventName = (string)reader[1];
                    profile.EventDateFileLabel = (string)reader[2];
                    profile.ActivitiesDescription = (string)reader[3];
                    profile.ActivitiesDescriptionFileLabel = (string)reader[4];

                    profile.InsuredIsOwner = (string)reader[5];
                    profile.InsuredIsManager = (string)reader[6];
                    profile.InsuredIsThirdParty = (string)reader[7];
                    profile.EventIsPrivacy = (string)reader[8];

                    profile.AdmissionCharge = (string)reader[9];
                    profile.AdmissionCost = (string)reader[10];
                    profile.SellTicket = (string)reader[11];
                    profile.SellHowManyTickets = (string)reader[12];
                    profile.TotalTicketSalesAmount = (string)reader[13];
                    profile.PricePerTicket = (string)reader[14];
                    profile.HowToSellTicket = (string)reader[15];
                    profile.WhoSellTickets = (string)reader[16];
                    profile.RecieveDonate = (string)reader[17];

                    profile.SeatType1 = (string)reader[18];
                    profile.SeatType2 = (string)reader[19];
                    profile.SeatType3 = (string)reader[20];
                    profile.SeatType4 = (string)reader[21];
                    profile.SeatType5 = (string)reader[22];

                    profile.NumOfPrivateSecurityPersons = (string)reader[23];
                    profile.NumOfPoliceOrSheriffPersons = (string)reader[24];
                    profile.NumOfPeerGroupOrUshersPersons = (string)reader[25];
                    profile.NumOfEmployeesPersons = (string)reader[26];
                    profile.NumOfParentChaperonsPersons = (string)reader[27];
                    profile.NumOfVolunteersPersons = (string)reader[28];

                    profile.Armed = (string)reader[29];
                    profile.BagCheck = (string)reader[30];
                    profile.FirstAid = (string)reader[31];
                    profile.CompanyForFirstAide = (string)reader[32];
                    profile.RecievedInsurance = (string)reader[33];

                    profile.EntranceExit = (string)reader[34];
                    profile.AccessibleParking = (string)reader[35];

                    profile.EventAdvertise = (string)reader[36];
                    profile.EventIsOnWebsite = (string)reader[37];
                    profile.EventWebsite = (string)reader[38];
                    profile.EventTelevised = (string)reader[39];
                    profile.EventRadio = (string)reader[40];
                    profile.EventNewsPaper = (string)reader[41];
                    profile.EventBrochure = (string)reader[42];
                    profile.EventHandOut = (string)reader[43];
                    profile.EventBillBoard = (string)reader[44];
                    profile.EventPoster = (string)reader[45];
                    profile.EventOther = (string)reader[46];

                    profile.AlcoholServe = (string)reader[47];
                    profile.AlcoholIsSold = (string)reader[48];
                    profile.AlcoholFee = (string)reader[49];

                    profile.EventFee = (string)reader[50];
                    profile.EventDonation = (string)reader[51];

                    profile.AlcoholType1 = (string)reader[52];
                    profile.AlcoholType2 = (string)reader[53];
                    profile.AlcoholType3 = (string)reader[54];
                    //
                    profile.AlcoholVending = (string)reader[55];
                    profile.AlcoholVendingInsurance = (string)reader[56];
                    profile.EstimatedAlcoholSales = (string)reader[57];
                    profile.NumOfAlcoholLocations = (string)reader[58];
                    profile.LiquorLicense = (string)reader[59];
                    profile.LiquorDrinkArea = (string)reader[60];
                    profile.LiquorIdentification = (string)reader[61];
                    profile.DrinkingAge = (string)reader[62];
                    profile.LiquorServingLimit = (string)reader[63];
                    profile.LiquorStaffMonitor = (string)reader[64];
                    profile.LiquorBarClose = (string)reader[65];

                    profile.AthleticRecreationalActivity = (string)reader[66];
                    profile.WaiverAndLiabilityProcedure = (string)reader[67];
                    profile.LiabilityReleaseFileLabel = (string)reader[68];

                    profile.HaveMusic = (string)reader[69];
                    profile.TypeOfMusic1 = (string)reader[70];
                    profile.TypeOfMusic2 = (string)reader[71];
                    profile.TypeOfMusic3 = (string)reader[72];
                    profile.AmplifiedMusic = (string)reader[73];
                    profile.NumOfBandsOrArtists = (string)reader[74];

                    profile.OwnElectricity = (string)reader[75];
                    profile.ElectricityArranging = (string)reader[76];

                    profile.OtherEntertainment = (string)reader[77];
                    profile.OtherEntertainmentDescription = (string)reader[78];

                    profile.ActivityStuff = (string)reader[79];
                    profile.HiredCompanyForActivities = (string)reader[80];
                    profile.FollowingActivitiesFileLabel = (string)reader[81];
                    profile.ExplainProcedureForWaivers = (string)reader[82];
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////
            // Get information from MusicTypes table

            using (SqlConnection connection = new SqlConnection(
            connectionString))
            {
                string queryMusicTypesString = "Use cs4961; " + "Select * from MusicTypes " + "Where MusicTypes.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command = new SqlCommand(queryMusicTypesString, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.MusicType1 = (string)reader[1];
                    profile.MusicType2 = (string)reader[2];
                    profile.MusicType3 = (string)reader[3];
                    profile.MusicType4 = (string)reader[4];
                    profile.MusicType5 = (string)reader[5];
                    profile.MusicType6 = (string)reader[6];
                    profile.MusicType7 = (string)reader[7];
                    profile.MusicType8 = (string)reader[8];
                    profile.MusicType9 = (string)reader[9];
                    profile.MusicType10 = (string)reader[10];

                    profile.MusicType11 = (string)reader[11];
                    profile.MusicType12 = (string)reader[12];
                    profile.MusicType13 = (string)reader[13];
                    profile.MusicType14 = (string)reader[14];
                    profile.MusicType15 = (string)reader[15];
                    profile.MusicType16 = (string)reader[16];
                    profile.MusicType17 = (string)reader[17];
                    profile.MusicType18 = (string)reader[18];
                    profile.MusicType19 = (string)reader[19];
                    profile.MusicType20 = (string)reader[20];

                    profile.MusicType21 = (string)reader[21];
                    profile.MusicType22 = (string)reader[22];
                    profile.MusicType23 = (string)reader[23];
                    profile.MusicType24 = (string)reader[24];
                    profile.MusicType25 = (string)reader[25];
                    profile.MusicType26 = (string)reader[26];
                    profile.MusicType27 = (string)reader[27];
                    profile.MusicType28 = (string)reader[28];
                    profile.MusicType29 = (string)reader[29];
                    profile.MusicType30 = (string)reader[30];

                    profile.MusicType31 = (string)reader[31];
                    profile.MusicType32 = (string)reader[32];
                    profile.MusicType33 = (string)reader[33];
                    profile.MusicType34 = (string)reader[34];
                    profile.MusicType35 = (string)reader[35];
                    profile.MusicType36 = (string)reader[36];
                    profile.MusicType37 = (string)reader[37];
                    profile.MusicType38 = (string)reader[38];

                    profile.OtherTypeOfMusic = (string)reader[39];
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////
            // Get information from IncludeFollowingActivities1 table

            using (SqlConnection connection = new SqlConnection(
            connectionString))
            {
                string queryIncludeFollowingActivities1String = "Use cs4961; " + "Select * from IncludeFollowingActivities1 " + "Where IncludeFollowingActivities1.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command = new SqlCommand(queryIncludeFollowingActivities1String, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.ClimbWall = (string)reader[1];
                    profile.SkateBoard = (string)reader[2];
                    profile.RollerAct = (string)reader[3];
                    profile.CycleAct = (string)reader[4];
                    profile.WaterAct = (string)reader[5];
                    profile.GunAct = (string)reader[6];
                    profile.FireAct = (string)reader[7];
                    profile.ArmoryAct = (string)reader[8];
                    profile.ChemicalAct = (string)reader[9];
                    profile.MedicalAct = (string)reader[10];
                    profile.DemolitionAct = (string)reader[11];
                    profile.ScaffoldingfAct = (string)reader[12];
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////
            // Get information from IncludeFollowingActivities2 table

            using (SqlConnection connection = new SqlConnection(
            connectionString))
            {
                string queryIncludeFollowingActivities2String = "Use cs4961; " + "Select * from IncludeFollowingActivities2 " + "Where IncludeFollowingActivities2.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command = new SqlCommand(queryIncludeFollowingActivities2String, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.AirRiding = (string)reader[1];
                    profile.TerrainBoarding = (string)reader[2];
                    profile.BaseJumping = (string)reader[3];
                    profile.Bouldering = (string)reader[4];
                    profile.BoxingMaritalArts = (string)reader[5];
                    profile.BungeeAct = (string)reader[6];
                    profile.CircusCarnival = (string)reader[7];
                    profile.Concert6HrAct = (string)reader[8];
                    profile.ConcertDanceAct = (string)reader[9];
                    profile.PlatformBoardDiving = (string)reader[10];
                    profile.HangGliding = (string)reader[11];
                    profile.KayalRaftCanoeing = (string)reader[12];
                    profile.MechanicalRide = (string)reader[13];
                    profile.MotorSportEquipment = (string)reader[14];
                    profile.MountainBiking = (string)reader[15];
                    profile.PowerBoats = (string)reader[16];
                    profile.ProSportCash = (string)reader[17];
                    profile.PyroFireAct = (string)reader[18];
                    profile.RapRockConcert = (string)reader[19];
                    profile.RockClimbAct = (string)reader[20];
                    profile.RodeoRopeAct = (string)reader[21];
                    profile.SkinDiveAct = (string)reader[22];
                    profile.ScubaDiveAct = (string)reader[23];
                    profile.TractorTruckPull = (string)reader[24];
                    profile.Trampoline = (string)reader[25];
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////
            // Get information from Event Location table

            using (SqlConnection connection = new SqlConnection(
            connectionString))
            {
                string queryEventLocationString = "Use cs4961; " + "Select * from EventLocation " + "Where EventLocation.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command = new SqlCommand(queryEventLocationString, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.FacilityName = (string)reader[1];
                    profile.FacilityStreetName = (string)reader[2];
                    profile.FacilityCity = (string)reader[3];
                    profile.FacilityState = (string)reader[4];
                    profile.FacilityZip = (string)reader[5];
                    profile.OutdoorAreaSize = (string)reader[6];
                    profile.OutdoorAreaInsured = (string)reader[7];
                    profile.IsVendorSellingAlcohol = (string)reader[8];
                    profile.VendorsTableFileLabel = (string)reader[9];
                    profile.ExhibitorsTableFileLabel = (string)reader[10];
                    profile.HeldBefore = (string)reader[11];
                    profile.CertificationOfEventLocationFileLabel = (string)reader[12];
                    profile.EvacuationPlan = (string)reader[13];
                    profile.EvacuationPlanDescription = (string)reader[14];
                    profile.IsThereMedicalPresence = (string)reader[15];
                    profile.NumOfDoctors = (string)reader[16];
                    profile.NumOfParamedics = (string)reader[17];
                    profile.NumOfNurses = (string)reader[18];
                    profile.NumOfEMTOrEMS = (string)reader[19];
                    profile.NumOfOther = (string)reader[20];
                    profile.AmbulanceOnSite = (string)reader[21];

                    profile.StreetClosure = (string)reader[22];
                    profile.TrafficMitigation = (string)reader[23];
                    profile.TrafficMitigationDescription = (string)reader[24];

                    profile.LACertificationFileLabel = (string)reader[25];
                    profile.AllVendorsCertificationsFileLabel = (string)reader[26];
                    profile.AllBrochuresFileLabel = (string)reader[27];
                    profile.CompleteScheduleOfEventsFileLabel = (string)reader[28];
                    profile.WaiverReleasesSignedFileLabel = (string)reader[29];
                    profile.DiagramOrSitePlanFileLabel = (string)reader[30];
                    profile.FiveYearLossHistoryFileLabel = (string)reader[31];
                    profile.EvacuationParkAndTrafficPlanDiagramFileLabel = (string)reader[32];
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////
            // Get information from Final Section table

            using (SqlConnection connection = new SqlConnection(
            connectionString))
            {
                string queryFinalSectionString = "Use cs4961; " + "Select * from FinalSection " + "Where FinalSection.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command = new SqlCommand(queryFinalSectionString, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.ApplicantSignature = (string)reader[1];
                    profile.ApplicantTitle = (string)reader[2];
                    profile.ApplicationDate = (DateTime)reader[3];
                    profile.SupervisorInitials = (string)reader[4];
                    profile.AssemblingsPermitSignedDate = (DateTime)reader[5];
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////
            // Get information from Final Section Permit table

            string queryFinalSectionPermitString1 = "Use cs4961; " +
    "Select * from Permit " + "Where Permit.ID = " + "\'" + loginCredentials.ID.ToString() + "\'" + " AND FSPermitName = 'Security Deposit/Fee';";
            string queryFinalSectionPermitString2 = "Use cs4961; " +
    "Select * from Permit " + "Where Permit.ID = " + "\'" + loginCredentials.ID.ToString() + "\'" + " AND FSPermitName = 'Business License';";
            string queryFinalSectionPermitString3 = "Use cs4961; " +
    "Select * from Permit " + "Where Permit.ID = " + "\'" + loginCredentials.ID.ToString() + "\'" + " AND FSPermitName = 'Dance Permit Required';";
            string queryFinalSectionPermitString4 = "Use cs4961; " +
    "Select * from Permit " + "Where Permit.ID = " + "\'" + loginCredentials.ID.ToString() + "\'" + " AND FSPermitName = 'Environmental Health Permit';";
            string queryFinalSectionPermitString5 = "Use cs4961; " +
    "Select * from Permit " + "Where Permit.ID = " + "\'" + loginCredentials.ID.ToString() + "\'" + " AND FSPermitName = 'ABC License';";
            string queryFinalSectionPermitString6 = "Use cs4961; " +
    "Select * from Permit " + "Where Permit.ID = " + "\'" + loginCredentials.ID.ToString() + "\'" + " AND FSPermitName = 'Police Services';";
            string queryFinalSectionPermitString7 = "Use cs4961; " +
    "Select * from Permit " + "Where Permit.ID = " + "\'" + loginCredentials.ID.ToString() + "\'" + " AND FSPermitName = 'Assemblage Permit';";
            string queryFinalSectionPermitString8 = "Use cs4961; " +
    "Select * from Permit " + "Where Permit.ID = " + "\'" + loginCredentials.ID.ToString() + "\'" + " AND FSPermitName = 'Specific Event Permit';";
            string queryFinalSectionPermitString9 = "Use cs4961; " +
    "Select * from Permit " + "Where Permit.ID = " + "\'" + loginCredentials.ID.ToString() + "\'" + " AND FSPermitName = 'Street Closure';";
            string queryFinalSectionPermitString10 = "Use cs4961; " +
    "Select * from Permit " + "Where Permit.ID = " + "\'" + loginCredentials.ID.ToString() + "\'" + " AND FSPermitName = 'Tent/Canopy Approval';";
            string queryFinalSectionPermitString11 = "Use cs4961; " +
    "Select * from Permit " + "Where Permit.ID = " + "\'" + loginCredentials.ID.ToString() + "\'" + " AND FSPermitName = 'Electrician Services';";
            string queryFinalSectionPermitString12 = "Use cs4961; " +
    "Select * from Permit " + "Where Permit.ID = " + "\'" + loginCredentials.ID.ToString() + "\'" + " AND FSPermitName = 'Liquor Liability Insurance';";
            string queryFinalSectionPermitString13 = "Use cs4961; " +
    "Select * from Permit " + "Where Permit.ID = " + "\'" + loginCredentials.ID.ToString() + "\'" + " AND FSPermitName = 'Event Liability Insurance';";
            string queryFinalSectionPermitString14 = "Use cs4961; " +
    "Select * from Permit " + "Where Permit.ID = " + "\'" + loginCredentials.ID.ToString() + "\'" + " AND FSPermitName = 'Suppliers Insurance';";
            string queryFinalSectionPermitString15 = "Use cs4961; " +
    "Select * from Permit " + "Where Permit.ID = " + "\'" + loginCredentials.ID.ToString() + "\'" + " AND FSPermitName = 'Vendors Insurance';";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(queryFinalSectionPermitString1, connection); SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.SecurityDepositRow = (string)reader[1]; profile.SecurityDepositRadio = (string)reader[2];
                    profile.SecurityDepositApproval = (string)reader[3]; profile.SecurityDepositSignedDate = (DateTime)reader[4];
                }
            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(queryFinalSectionPermitString2, connection); SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.BusinessLicenseRow = (string)reader[1]; profile.BusinessLicenseRadio = (string)reader[2];
                    profile.BusinessLicenseApproval = (string)reader[3]; profile.BusinessLicenseSignedDate = (DateTime)reader[4];
                }
            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(queryFinalSectionPermitString3, connection); SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.DancePermitRow = (string)reader[1]; profile.DancePermitRadio = (string)reader[2];
                    profile.DancePermitApproval = (string)reader[3]; profile.DancePermitSignedDate = (DateTime)reader[4];
                }
            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(queryFinalSectionPermitString4, connection); SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.EnvironmentalHealthPermitRow = (string)reader[1]; profile.EnvironmentalHealthPermitRadio = (string)reader[2];
                    profile.EnvironmentalHealthPermitApproval = (string)reader[3]; profile.EnvironmentalHealthPermitSignedDate = (DateTime)reader[4];
                }
            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(queryFinalSectionPermitString5, connection); SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.ABCLicenseRow = (string)reader[1]; profile.ABCLicenseRadio = (string)reader[2];
                    profile.ABCLicenseApproval = (string)reader[3]; profile.ABCLicenseSignedDate = (DateTime)reader[4];
                }
            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(queryFinalSectionPermitString6, connection); SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.PoliceServicesRow = (string)reader[1]; profile.PoliceServicesRadio = (string)reader[2];
                    profile.PoliceServicesApproval = (string)reader[3]; profile.PoliceServicesSignedDate = (DateTime)reader[4];
                }
            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(queryFinalSectionPermitString7, connection); SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.AssemblagePermitRow = (string)reader[1]; profile.AssemblagePermitRadio = (string)reader[2];
                    profile.AssemblagePermitApproval = (string)reader[3]; profile.AssemblagePermitSignedDate = (DateTime)reader[4];
                }
            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(queryFinalSectionPermitString8, connection); SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.SpecialEventPermitRow = (string)reader[1]; profile.SpecialEventPermitRadio = (string)reader[2];
                    profile.SpecialEventPermitApproval = (string)reader[3]; profile.SpecialEventPermitSignedDate = (DateTime)reader[4];
                }
            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(queryFinalSectionPermitString9, connection); SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.StreetClosureRow = (string)reader[1]; profile.StreetClosureRadio = (string)reader[2];
                    profile.StreetClosureApproval = (string)reader[3]; profile.StreetClosureSignedDate = (DateTime)reader[4];
                }
            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(queryFinalSectionPermitString10, connection); SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.TentCanopyApprovalRow = (string)reader[1]; profile.TentCanopyApprovalRadio = (string)reader[2];
                    profile.TentCanopyApprovalApproval = (string)reader[3]; profile.TentCanopyApprovalSignedDate = (DateTime)reader[4];
                }
            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(queryFinalSectionPermitString11, connection); SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.ElectricianServicesRow = (string)reader[1]; profile.ElectricianServicesRadio = (string)reader[2];
                    profile.ElectricianServicesApproval = (string)reader[3]; profile.ElectricianServicesSignedDate = (DateTime)reader[4];
                }
            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(queryFinalSectionPermitString12, connection); SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.LiquorLicenseRow = (string)reader[1]; profile.LiquorLicenseRadio = (string)reader[2];
                    profile.LiquorLicenseApproval = (string)reader[3]; profile.LiquorLicenseSignedDate = (DateTime)reader[4];
                }
            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(queryFinalSectionPermitString13, connection); SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.LiabilityInsuranceRow = (string)reader[1]; profile.LiabilityInsuranceRadio = (string)reader[2];
                    profile.LiabilityInsuranceApproval = (string)reader[3]; profile.LiabilityInsuranceSignedDate = (DateTime)reader[4];
                }
            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(queryFinalSectionPermitString14, connection); SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.SupplierInsuranceRow = (string)reader[1]; profile.SupplierInsuranceRadio = (string)reader[2];
                    profile.SupplierInsuranceApproval = (string)reader[3]; profile.SupplierInsuranceSignedDate = (DateTime)reader[4];
                }
            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(queryFinalSectionPermitString15, connection); SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //profile.ApplicationID = (int)reader[0];
                    profile.VendorInsuranceRow = (string)reader[1]; profile.VendorInsuranceRadio = (string)reader[2];
                    profile.VendorInsuranceApproval = (string)reader[3]; profile.VendorInsuranceSignedDate = (DateTime)reader[4];
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////
            // Get information from EventTable table

            using (SqlConnection connection = new SqlConnection(
            connectionString))
            {
                int rowCount1 = 0;
                string queryCountEventTableRowsString = "Use cs4961; " + "Select COUNT(*) from EventTable " + "Where EventTable.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command1 = new SqlCommand(queryCountEventTableRowsString, connection);
                SqlDataReader reader1 = command1.ExecuteReader();
                while (reader1.Read())
                {
                    rowCount1 = (int)reader1[0];
                }
                connection.Close();

                string queryEventTableRowsString = "Use cs4961; " + "Select * from EventTable " + "Where EventTable.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command2 = new SqlCommand(queryEventTableRowsString, connection);
                SqlDataReader reader2 = command2.ExecuteReader();

                if (rowCount1 != 0)
                {
                    int index = 0;
                    profile.eventTableRows = new EventTableRow[rowCount1];

                    while (reader2.Read())
                    {
                        profile.eventTableRows[index] = new EventTableRow((int)reader2[0], (DateTime)reader2[1], (string)reader2[2], (string)reader2[3], (string)reader2[4], (string)reader2[5]);
                        index++;
                    }
                }
                connection.Close();
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////
            // Get information from Activity table

            using (SqlConnection connection = new SqlConnection(
            connectionString))
            {
                int rowCount2 = 0;
                string queryCountActivityTableRowsString = "Use cs4961; " + "Select COUNT(*) from Activity " + "Where Activity.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command1 = new SqlCommand(queryCountActivityTableRowsString, connection);
                SqlDataReader reader1 = command1.ExecuteReader();
                while (reader1.Read())
                {
                    rowCount2 = (int)reader1[0];
                }
                connection.Close();

                string queryActivityTableRowsString = "Use cs4961; " + "Select * from Activity " + "Where Activity.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command2 = new SqlCommand(queryActivityTableRowsString, connection);
                SqlDataReader reader2 = command2.ExecuteReader();

                if (rowCount2 != 0)
                {
                    int index = 0;
                    profile.activityTableRows = new ActivityTableRow[rowCount2];

                    while (reader2.Read())
                    {
                        profile.activityTableRows[index] = new ActivityTableRow((int)reader2[0], (DateTime)reader2[1], (string)reader2[2], (string)reader2[3]);
                        index++;
                    }
                }
                connection.Close();
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////
            // Get information from MusicArtists table

            using (SqlConnection connection = new SqlConnection(
            connectionString))
            {
                int rowCount3 = 0;
                string queryCountMusicArtistsTableRowsString = "Use cs4961; " + "Select COUNT(*) from MusicArtists " + "Where MusicArtists.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command1 = new SqlCommand(queryCountMusicArtistsTableRowsString, connection);
                SqlDataReader reader1 = command1.ExecuteReader();
                while (reader1.Read())
                {
                    rowCount3 = (int)reader1[0];
                }
                connection.Close();

                string queryMusicArtistsTableRowsString = "Use cs4961; " + "Select * from MusicArtists " + "Where MusicArtists.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command2 = new SqlCommand(queryMusicArtistsTableRowsString, connection);
                SqlDataReader reader2 = command2.ExecuteReader();

                if (rowCount3 != 0)
                {
                    int index = 0;
                    profile.musicArtistsTableRows = new MusicArtistsTableRow[rowCount3];

                    while (reader2.Read())
                    {
                        profile.musicArtistsTableRows[index] = new MusicArtistsTableRow((int)reader2[0], (string)reader2[1], (string)reader2[2], (string)reader2[3], (string)reader2[4]);
                        index++;
                    }
                }
                connection.Close();
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////
            // Get information from Vendor table

            using (SqlConnection connection = new SqlConnection(
            connectionString))
            {
                int rowCount4 = 0;
                string queryCountVendorTableRowsString = "Use cs4961; " + "Select COUNT(*) from Vendor " + "Where Vendor.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command1 = new SqlCommand(queryCountVendorTableRowsString, connection);
                SqlDataReader reader1 = command1.ExecuteReader();
                while (reader1.Read())
                {
                    rowCount4 = (int)reader1[0];
                }
                connection.Close();

                string queryVendorTableRowsString = "Use cs4961; " + "Select * from Vendor " + "Where Vendor.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command2 = new SqlCommand(queryVendorTableRowsString, connection);
                SqlDataReader reader2 = command2.ExecuteReader();

                if (rowCount4 != 0)
                {
                    int index = 0;
                    profile.vendorTableRows = new VendorTableRow[rowCount4];

                    while (reader2.Read())
                    {
                        profile.vendorTableRows[index] = new VendorTableRow((int)reader2[0], (string)reader2[1], (string)reader2[2], (string)reader2[3], (string)reader2[4], (string)reader2[5], (string)reader2[6], (string)reader2[7]);
                        index++;
                    }
                }
                connection.Close();
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////
            // Get information from Exhibitior table

            using (SqlConnection connection = new SqlConnection(
            connectionString))
            {
                int rowCount5 = 0;
                string queryCountExhibitorTableRowsString = "Use cs4961; " + "Select COUNT(*) from Exhibitor " + "Where Exhibitor.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command1 = new SqlCommand(queryCountExhibitorTableRowsString, connection);
                SqlDataReader reader1 = command1.ExecuteReader();
                while (reader1.Read())
                {
                    rowCount5 = (int)reader1[0];
                }
                connection.Close();

                string queryExhibitiorTableRowsString = "Use cs4961; " + "Select * from Exhibitor " + "Where Exhibitor.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command2 = new SqlCommand(queryExhibitiorTableRowsString, connection);
                SqlDataReader reader2 = command2.ExecuteReader();

                if (rowCount5 != 0)
                {
                    int index = 0;
                    profile.exhibitorTableRows = new ExhibitorTableRow[rowCount5];

                    while (reader2.Read())
                    {
                        profile.exhibitorTableRows[index] = new ExhibitorTableRow((int)reader2[0], (string)reader2[1], (string)reader2[2], (string)reader2[3], (string)reader2[4], (string)reader2[5], (string)reader2[6], (string)reader2[7]);
                        index++;
                    }
                }
                connection.Close();
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////
            // Get information from PastEvent table

            using (SqlConnection connection = new SqlConnection(
            connectionString))
            {
                int rowCount6 = 0;
                string queryCountPastEventTableRowsString = "Use cs4961; " + "Select COUNT(*) from PastEvent " + "Where PastEvent.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command1 = new SqlCommand(queryCountPastEventTableRowsString, connection);
                SqlDataReader reader1 = command1.ExecuteReader();
                while (reader1.Read())
                {
                    rowCount6 = (int)reader1[0];
                }
                connection.Close();

                string queryPastEventTableRowsString = "Use cs4961; " + "Select * from PastEvent " + "Where PastEvent.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command2 = new SqlCommand(queryPastEventTableRowsString, connection);
                SqlDataReader reader2 = command2.ExecuteReader();

                if (rowCount6 != 0)
                {
                    int index = 0;
                    profile.pastEventTableRows = new PastEventRow[rowCount6];

                    while (reader2.Read())
                    {
                        profile.pastEventTableRows[index] = new PastEventRow((int)reader2[0], (DateTime)reader2[1], (string)reader2[2], (string)reader2[3], (DateTime)reader2[4], (string)reader2[5]);
                        index++;
                    }
                }
                connection.Close();
            }

            //////////////////////////////////////////////////////////////////////////////////////////////////////////
            // Get information from StreetClosure table

            using (SqlConnection connection = new SqlConnection(
            connectionString))
            {
                int rowCount7 = 0;
                string queryCountStreetClosureTableRowsString = "Use cs4961; " + "Select COUNT(*) from StreetClosure " + "Where StreetClosure.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command1 = new SqlCommand(queryCountStreetClosureTableRowsString, connection);
                SqlDataReader reader1 = command1.ExecuteReader();
                while (reader1.Read())
                {
                    rowCount7 = (int)reader1[0];
                }
                connection.Close();

                string queryStreetClosureTableRowsString = "Use cs4961; " + "Select * from StreetClosure " + "Where StreetClosure.ID = " + "\'" + loginCredentials.ID.ToString() + "\';";
                connection.Open();
                SqlCommand command2 = new SqlCommand(queryStreetClosureTableRowsString, connection);
                SqlDataReader reader2 = command2.ExecuteReader();

                if (rowCount7 != 0)
                {
                    int index = 0;
                    profile.streetClosureRows = new StreetClosureRow[rowCount7];

                    while (reader2.Read())
                    {
                        profile.streetClosureRows[index] = new StreetClosureRow((int)reader2[0], (string)reader2[1], (string)reader2[2]);
                        index++;
                    }
                }
                connection.Close();
            }

            ///////////////////////////////////////////////////////////////////// Switch to view if identical id and password found or else just stay in login view
            ViewBag.loginMessage = "";

            if (profile.ApplicationID == 0 && profile.Password == null)
            {
                ViewBag.loginMessage = "Sorry, either wrong ID or wrong password or this account does not exist.";
                return View("Index");
            }
            else
            {
                ViewData["returningUser"] = profile;
                return View();
            }
        }

        public IActionResult NewApplicationForm()
        {
            return View();
        }


        public IActionResult Index() { return View(); }

        ///////////

        public int id = 0;
        //public String password = "";

        private readonly IWebHostEnvironment hostingEnvironment;
        public HomeController(IWebHostEnvironment e)
        {
            hostingEnvironment = e;
        }

        ///////////

        [HttpPost]
        // Parameter variables for holding file inputs and one registration object
        public IActionResult FormSubmitted(RegisterInformation registerInformation)
        {


            //////////////////////////////////////////////////////////////////////////////////////////

            // SQL Connection String
            string connectionString = @"Data Source=DESKTOP-FSJF92K\JWSQL;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            string importantNoticeString;

            // Check if application finished and record into database
            registerInformation.ApplicationFinished = "Yes";

            if (registerInformation.Password == null && registerInformation.ApplicationID.ToString() == "0")
            {
                var length = 16;
                string charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789`~!@#$%^&*()-_=+[{]}|;:,<.>/?";


                Random rand = new Random();
                for (int i = 0, n = charset.Length; i < length; ++i)
                {
                    registerInformation.Password += charset[rand.Next(0, charset.Length - 1)];
                }

                importantNoticeString = "Use CS4961;" + "Insert into ImportantNotice (Password, Agreement, FinishedApplication) values (\'" + Encrypt(registerInformation.Password) + "\'," + "\'" + registerInformation.Agreement + "\'," + "\'" + registerInformation.ApplicationFinished + "\');";
            }
            else
            {
                //First delete any account that is alike in database

                // Delete current id to overwrite it
                string deleteQueryString =

                "use cs4961; " +

                "delete from Exhibitor " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from PastEvent " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from StreetClosure " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from Vendor " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from IncludeFollowingActivities1 " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from IncludeFollowingActivities2 " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from Activity " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from MusicArtists " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from MusicTypes " + "where id = " + registerInformation.ApplicationID + "; " +

                "use cs4961;" + // Too many transactions in one go has to execute use database again

                "delete from EventTable " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from EventInformation " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from EventLocation " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from ApplicationInformation " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from Permit " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from FinalSection " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from ImportantNotice " + "where id = " + registerInformation.ApplicationID + "; ";

                id = registerInformation.ApplicationID;

                importantNoticeString = "Use CS4961;" +
                    "SET IDENTITY_INSERT ImportantNotice on;" +
                    "Use CS4961;" + "Insert into ImportantNotice (ID, Password, Agreement, FinishedApplication) values ( " + id + ", \'" + Encrypt(registerInformation.Password) + "\'," + "\'" + registerInformation.Agreement + "\'," + "\'" + registerInformation.ApplicationFinished + "\');" +
                    "SET IDENTITY_INSERT ImportantNotice off;";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {

                    using (SqlCommand cmd = new SqlCommand(deleteQueryString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }

            }

            // Important Notice retrieve query here
            string retrieveString = "Use CS4961;" + "Select Id from ImportantNotice where password = \'" + Encrypt(registerInformation.Password) + "\';";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(importantNoticeString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }

                SqlCommand command = new SqlCommand(retrieveString, connection);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    id = (int)reader[0];
                }
                connection.Close();
            }
            //////////////////////////////////////////////////////////////////////////////////////////

            // Applicant Information Action

            // Application Information query all here
            string applicationInformationString = ApplicantInformationQueryString(registerInformation);


            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                using (SqlCommand cmd = new SqlCommand(applicationInformationString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }
            //////////////////////////////////////////////////////////////////////////////////////////

            // Event Information Action

            // Event Information query all here
            string eventInformationString = EventInformationQueryStringString(registerInformation);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(eventInformationString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////

            // Music Types Action

            // Music Types query all here
            string musicTypesString = MusicTypesQueryString(registerInformation);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(musicTypesString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }
            //////////////////////////////////////////////////////////////////////////////////////////

            // FolowingActivities1 Action

            // FolowingActivities1 query all here
            string followingActivities1String = FolowingActivities1QueryString(registerInformation);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(followingActivities1String, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }
            //////////////////////////////////////////////////////////////////////////////////////////

            // FolowingActivities2 Action

            // FolowingActivities2 query all here
            string followingActivities2String = FolowingActivities2QueryString(registerInformation);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(followingActivities2String, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////

            // Event Location Action

            // Event Location query all here

            string eventLocationString = EventLocationQueryString(registerInformation);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(eventLocationString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////

            // Final Section Action

            // Final Section query all here

            string finalSectionString = FinalSectionQueryString(registerInformation);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(finalSectionString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////

            // Final Section Permit Action

            // Final Section Permit query all here

            string permitString = FinalSectionPermitQueryString(registerInformation);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(permitString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////
            // Storing input files !!!

            //Creating folder by id into wwwroot/CustomerProfiles folder
            string pathString1 = System.IO.Path.Combine(hostingEnvironment.WebRootPath + "/CustomerProfiles", id.ToString());
            System.IO.Directory.CreateDirectory(pathString1);


            IFormFile[] inputFileArray = {registerInformation.EventDateFile, registerInformation.ActivitiesDescriptionFile, registerInformation.LiabilityReleaseFile, registerInformation.FollowingActivitiesFile,
                registerInformation.VendorsTableFile, registerInformation.ExhibitorsTableFile, registerInformation.CertificationOfEventLocationFile, registerInformation.LACertificationFile,
                registerInformation.AllVendorsCertificationsFile, registerInformation.AllBrochuresFile, registerInformation.CompleteScheduleOfEventsFile, registerInformation.WaiverReleasesSignedFile,
                registerInformation.DiagramOrSitePlanFile, registerInformation.FiveYearLossHistoryFile, registerInformation.EvacuationParkAndTrafficPlanDiagramFile};

            foreach (IFormFile tempfile in inputFileArray)
            {

                if (tempfile != null)
                {
                    string pathString2 = System.IO.Path.Combine(hostingEnvironment.WebRootPath + "/CustomerProfiles" + "/" + id.ToString(), tempfile.Name.ToString());
                    System.IO.Directory.CreateDirectory(pathString2);

                    var tempFileName = Path.Combine(hostingEnvironment.WebRootPath + "/CustomerProfiles/" + id.ToString() + "/" + tempfile.Name.ToString(), Path.GetFileName(tempfile.FileName));
                    tempfile.CopyTo(new FileStream(tempFileName, FileMode.Create));
                }
            }
            //////////////////////////////////////////////////////////////////////////////////////////

            // Event Table Action

            // Event Table query all here
            //if (registerInformation.eventTableRows[0].Hours == null && registerInformation.eventTableRows[0].IsAlcoholServed == null && registerInformation.eventTableRows[0].IsAlcoholSold == null) { }
            if (registerInformation.eventTableRows == null) { }
            else if (registerInformation.eventTableRows[0].Hours != null && registerInformation.eventTableRows[0].IsAlcoholServed != null && registerInformation.eventTableRows[0].IsAlcoholSold != null)
            {
                string eventTableString = EventTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(eventTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }




            //////////////////////////////////////////////////////////////////////////////////////////
            // Activity Table Action

            // Activity Table query all here
            if (registerInformation.activityTableRows == null) { }
            else if (registerInformation.activityTableRows[0].Activity != null && registerInformation.activityTableRows[0].Attendance != null)
            {
                string activityTableString = ActivityTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(activityTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////
            // MusicArtists Table Action

            // MusicArtists Table query all here

            // if (registerInformation.musicArtistsTableRows[0].Name == null && registerInformation.musicArtistsTableRows[0].Address == null) { }
            if (registerInformation.musicArtistsTableRows == null) { }
            else if (registerInformation.musicArtistsTableRows[0].Name != null && registerInformation.musicArtistsTableRows[0].Address != null)
            {
                string musicArtistsTableString = MusicTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(musicArtistsTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////
            // Vendor Table Action

            // Vendor Table query all here

            //if (registerInformation.vendorTableRows[0].TypeOfService == null && registerInformation.vendorTableRows[0].Name == null && registerInformation.vendorTableRows[0].MailAddress == null) { }
            if (registerInformation.vendorTableRows == null) { }
            else if (registerInformation.vendorTableRows[0].TypeOfService != null && registerInformation.vendorTableRows[0].Name != null && registerInformation.vendorTableRows[0].MailAddress != null && registerInformation.vendorTableRows[0].City != null && registerInformation.vendorTableRows[0].State != null)
            {
                string vendorTableString = VendorTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(vendorTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////
            // Exhibitor Table Action

            // Exhibitor Table query all here

            //if (registerInformation.exhibitorTableRows[0].TypeOfService == null && registerInformation.exhibitorTableRows[0].Name == null && registerInformation.exhibitorTableRows[0].MailAddress == null) { }
            if (registerInformation.exhibitorTableRows == null) { }
            else if (registerInformation.exhibitorTableRows[0].TypeOfService != null && registerInformation.exhibitorTableRows[0].Name != null && registerInformation.exhibitorTableRows[0].MailAddress != null && registerInformation.exhibitorTableRows[0].City != null && registerInformation.exhibitorTableRows[0].State != null)
            {
                string exhibitorTableString = ExhibitorTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(exhibitorTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////
            // PastEvent Table Action

            // PastEvent Table query all here

            //if (registerInformation.pastEventTableRows[0].Claimant == null && registerInformation.pastEventTableRows[0].Description == null) { }
            if (registerInformation.pastEventTableRows == null) { }
            else if (registerInformation.pastEventTableRows[0].Claimant != null && registerInformation.pastEventTableRows[0].Description != null)
            {
                string pastEventTableString = PastEventTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(pastEventTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////
            // StreetClosure Table Action

            // StreetClosure Table query all here

            //if (registerInformation.streetClosureRows[0].StreetName == null) { }
            if (registerInformation.streetClosureRows == null) { }
            else if (registerInformation.streetClosureRows[0].StreetName != null)
            {
                string streetClosureTableString = StreetClosureTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(streetClosureTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////


            // Creating objects to hold what we want to return such as ID and Password to FormTurnedIn.cshtml

            RegisterInformation temp = new RegisterInformation(id, registerInformation.Password, registerInformation.ApplicationFinished);
            ArrayOfRegistry array = new ArrayOfRegistry();
            array.AddRegistry(temp);

            ViewBag.temporary = array;
            return View("FormTurnedIn",array);
        }

        [HttpPost]
        // Parameter variables for holding file inputs and one registration object
        public IActionResult FormTurnedIn(RegisterInformation registerInformation)
        {


            //////////////////////////////////////////////////////////////////////////////////////////

            // SQL Connection String
            string connectionString = @"Data Source=DESKTOP-FSJF92K\JWSQL;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            string importantNoticeString;

            // Check if application finished and record into database
            registerInformation.ApplicationFinished = "No";


            if (registerInformation.Password == null && registerInformation.ApplicationID.ToString() == "0")
            {
                var length = 16;
                string charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789`~!@#$%^&*()-_=+[{]}|;:,<.>/?";


                Random rand = new Random();
                for (int i = 0, n = charset.Length; i < length; ++i)
                {
                    registerInformation.Password += charset[rand.Next(0, charset.Length - 1)];
                }

                importantNoticeString = "Use CS4961;" + "Insert into ImportantNotice (Password, Agreement, FinishedApplication) values (\'" + Encrypt(registerInformation.Password) + "\'," + "\'" + registerInformation.Agreement + "\'," + "\'" + registerInformation.ApplicationFinished + "\');";
            }
            else
            {
                //First delete any account that is alike in database

                // Delete current id to overwrite it
                string deleteQueryString =

                "use cs4961; " +

                "delete from Exhibitor " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from PastEvent " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from StreetClosure " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from Vendor " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from IncludeFollowingActivities1 " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from IncludeFollowingActivities2 " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from Activity " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from MusicArtists " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from MusicTypes " + "where id = " + registerInformation.ApplicationID + "; " +

                "use cs4961;" + // Too many transactions in one go has to execute use database again

                "delete from EventTable " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from EventInformation " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from EventLocation " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from ApplicationInformation " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from Permit " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from FinalSection " + "where id = " + registerInformation.ApplicationID + "; " +
                "delete from ImportantNotice " + "where id = " + registerInformation.ApplicationID + "; ";

                id = registerInformation.ApplicationID;

                importantNoticeString = "Use CS4961;" +
                    "SET IDENTITY_INSERT ImportantNotice on;" +
                    "Use CS4961;" + "Insert into ImportantNotice (ID, Password, Agreement, FinishedApplication) values ( " + id + ", \'" + Encrypt(registerInformation.Password) + "\'," + "\'" + registerInformation.Agreement + "\'," + "\'" + registerInformation.ApplicationFinished + "\');" +
                    "SET IDENTITY_INSERT ImportantNotice off;";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {

                    using (SqlCommand cmd = new SqlCommand(deleteQueryString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }

            }

            // Important Notice retrieve query here
            string retrieveString = "Use CS4961;" + "Select Id from ImportantNotice where password = \'" + Encrypt(registerInformation.Password) + "\';";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(importantNoticeString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }

                SqlCommand command = new SqlCommand(retrieveString, connection);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    id = (int)reader[0];
                }
                connection.Close();
            }
            //////////////////////////////////////////////////////////////////////////////////////////

            // Applicant Information Action

            // Application Information query all here
            string applicationInformationString = ApplicantInformationQueryString(registerInformation);


            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                using (SqlCommand cmd = new SqlCommand(applicationInformationString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }
            //////////////////////////////////////////////////////////////////////////////////////////

            // Event Information Action

            // Event Information query all here
            string eventInformationString = EventInformationQueryStringString(registerInformation);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(eventInformationString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////

            // Music Types Action

            // Music Types query all here
            string musicTypesString = MusicTypesQueryString(registerInformation);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(musicTypesString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }
            //////////////////////////////////////////////////////////////////////////////////////////

            // FolowingActivities1 Action

            // FolowingActivities1 query all here
            string followingActivities1String = FolowingActivities1QueryString(registerInformation);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(followingActivities1String, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }
            //////////////////////////////////////////////////////////////////////////////////////////

            // FolowingActivities2 Action

            // FolowingActivities2 query all here
            string followingActivities2String = FolowingActivities2QueryString(registerInformation);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(followingActivities2String, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////

            // Event Location Action

            // Event Location query all here

            string eventLocationString = EventLocationQueryString(registerInformation);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(eventLocationString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////

            // Final Section Action

            // Final Section query all here

            string finalSectionString = FinalSectionQueryString(registerInformation);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(finalSectionString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////

            // Final Section Permit Action

            // Final Section Permit query all here

            string permitString = FinalSectionPermitQueryString(registerInformation);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(permitString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////
            // Storing input files !!!

            //Creating folder by id into wwwroot/CustomerProfiles folder
            string pathString1 = System.IO.Path.Combine(hostingEnvironment.WebRootPath + "/CustomerProfiles", id.ToString());
            System.IO.Directory.CreateDirectory(pathString1);


            IFormFile[] inputFileArray = {registerInformation.EventDateFile, registerInformation.ActivitiesDescriptionFile, registerInformation.LiabilityReleaseFile, registerInformation.FollowingActivitiesFile,
                registerInformation.VendorsTableFile, registerInformation.ExhibitorsTableFile, registerInformation.CertificationOfEventLocationFile, registerInformation.LACertificationFile,
                registerInformation.AllVendorsCertificationsFile, registerInformation.AllBrochuresFile, registerInformation.CompleteScheduleOfEventsFile, registerInformation.WaiverReleasesSignedFile,
                registerInformation.DiagramOrSitePlanFile, registerInformation.FiveYearLossHistoryFile, registerInformation.EvacuationParkAndTrafficPlanDiagramFile};

            foreach (IFormFile tempfile in inputFileArray)
            {

                if (tempfile != null)
                {
                    if (Directory.Exists(Path.Combine(hostingEnvironment.WebRootPath + "/CustomerProfiles/" + id.ToString() + "/" + tempfile.Name.ToString(), Path.GetFileName(tempfile.FileName))))
                    {
                        DirectoryInfo directory = new DirectoryInfo(Path.Combine(hostingEnvironment.WebRootPath + "/CustomerProfiles/" + id.ToString() + "/" + tempfile.Name.ToString(), Path.GetFileName(tempfile.FileName)));
                        directory.Delete(true);
                    }


                    string pathString2 = System.IO.Path.Combine(hostingEnvironment.WebRootPath + "/CustomerProfiles" + "/" + id.ToString(), tempfile.Name.ToString());
                    System.IO.Directory.CreateDirectory(pathString2);

                    var tempFileName = Path.Combine(hostingEnvironment.WebRootPath + "/CustomerProfiles/" + id.ToString() + "/" + tempfile.Name.ToString(), Path.GetFileName(tempfile.FileName));
                    tempfile.CopyTo(new FileStream(tempFileName, FileMode.Create));
                }
            }
            //////////////////////////////////////////////////////////////////////////////////////////

            // Event Table Action

            // Event Table query all here
            //if (registerInformation.eventTableRows[0].Hours == null && registerInformation.eventTableRows[0].IsAlcoholServed == null && registerInformation.eventTableRows[0].IsAlcoholSold == null) { }
            if (registerInformation.eventTableRows == null) { }
            else if (registerInformation.eventTableRows[0].Hours != null && registerInformation.eventTableRows[0].IsAlcoholServed != null && registerInformation.eventTableRows[0].IsAlcoholSold != null)
            {
                string eventTableString = EventTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(eventTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }




            //////////////////////////////////////////////////////////////////////////////////////////
            // Activity Table Action

            // Activity Table query all here
            if (registerInformation.activityTableRows == null) { }
            else if (registerInformation.activityTableRows[0].Activity != null && registerInformation.activityTableRows[0].Attendance != null)
            {
                string activityTableString = ActivityTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(activityTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////
            // MusicArtists Table Action

            // MusicArtists Table query all here

            // if (registerInformation.musicArtistsTableRows[0].Name == null && registerInformation.musicArtistsTableRows[0].Address == null) { }
            if (registerInformation.musicArtistsTableRows == null) { }
            else if (registerInformation.musicArtistsTableRows[0].Name != null && registerInformation.musicArtistsTableRows[0].Address != null)
            {
                string musicArtistsTableString = MusicTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(musicArtistsTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////
            // Vendor Table Action

            // Vendor Table query all here

            //if (registerInformation.vendorTableRows[0].TypeOfService == null && registerInformation.vendorTableRows[0].Name == null && registerInformation.vendorTableRows[0].MailAddress == null) { }
            if (registerInformation.vendorTableRows == null) { }
            else if (registerInformation.vendorTableRows[0].TypeOfService != null && registerInformation.vendorTableRows[0].Name != null && registerInformation.vendorTableRows[0].MailAddress != null && registerInformation.vendorTableRows[0].City != null && registerInformation.vendorTableRows[0].State != null)
            {
                string vendorTableString = VendorTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(vendorTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////
            // Exhibitor Table Action

            // Exhibitor Table query all here

            //if (registerInformation.exhibitorTableRows[0].TypeOfService == null && registerInformation.exhibitorTableRows[0].Name == null && registerInformation.exhibitorTableRows[0].MailAddress == null) { }
            if (registerInformation.exhibitorTableRows == null) { }
            else if (registerInformation.exhibitorTableRows[0].TypeOfService != null && registerInformation.exhibitorTableRows[0].Name != null && registerInformation.exhibitorTableRows[0].MailAddress != null && registerInformation.exhibitorTableRows[0].City != null && registerInformation.exhibitorTableRows[0].State != null)
            {
                string exhibitorTableString = ExhibitorTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(exhibitorTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////
            // PastEvent Table Action

            // PastEvent Table query all here

            //if (registerInformation.pastEventTableRows[0].Claimant == null && registerInformation.pastEventTableRows[0].Description == null) { }
            if (registerInformation.pastEventTableRows == null) { }
            else if (registerInformation.pastEventTableRows[0].Claimant != null && registerInformation.pastEventTableRows[0].Description != null)
            {
                string pastEventTableString = PastEventTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(pastEventTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////
            // StreetClosure Table Action

            // StreetClosure Table query all here

            //if (registerInformation.streetClosureRows[0].StreetName == null) { }
            if (registerInformation.streetClosureRows == null) { }
            else if (registerInformation.streetClosureRows[0].StreetName != null)
            {
                string streetClosureTableString = StreetClosureTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(streetClosureTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////


            // Creating objects to hold what we want to return such as ID and Password to FormTurnedIn.cshtml

            RegisterInformation temp = new RegisterInformation(id, registerInformation.Password, registerInformation.ApplicationFinished);
            ArrayOfRegistry array = new ArrayOfRegistry();
            array.AddRegistry(temp);

            ViewBag.temporary = array;
            return View(array);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        ////////////////////////////////////////////////////////////// Table With Rows Query Strings
        public string ApplicantInformationQueryString(RegisterInformation reg)
        {
            string query = "Use CS4961;" +
                "Insert into ApplicationInformation " +
                "( ID," +
                " AInameInsur1Input," +
                " AInameInsur2Input," +
                " AInameInsur3Input," +
                " AInameInsur4Input," +
                " AInameInsur5Input," +
                " AInameInsur6Input," +
                " AInameInsur7Input," +
                " AInameInsur8Input," +
                " AInameInsur9Input," +
                " AInameInsur10Input," +
                " AInameInsur11Input," +
                " AInameInsur12Input," +
                " AInameInsur13Input," +
                " AInameInsur14Input," +
                " AInameInsuredOther," +
                " AInameOnPolicy," +
                " AIbusinessAs," +
                " AImailAddress," +
                " AIcity," +
                " AIstate," +
                " AIzip," +
                " AIcontactPerson," +
                " AIemail," +
                " AIhomeNum," +
                " AIbusinessNum," +
                " AIfax," +
                " AIwebsite) values (" +
                id + "," +
                "\'" + reg.NameIsAIndividual + "\'," +
                "\'" + reg.NameIsACorporation + "\'," +
                "\'" + reg.NameIsATrustOfEstate + "\'," +
                "\'" + reg.NameIsAUnicorpAssoc + "\'," +
                "\'" + reg.NameIsAGeneralPartnership + "\'," +
                "\'" + reg.NameIsALLCorLLP + "\'," +
                "\'" + reg.NameIsAPublicAgency + "\'," +
                "\'" + reg.NameIsALaborUnion + "\'," +
                "\'" + reg.NameIsAInformalGroup + "\'," +
                "\'" + reg.NameIsALimitedPartnership + "\'," +
                "\'" + reg.NameIsANotForProfit + "\'," +
                "\'" + reg.NameIsARegliousGroup + "\'," +
                "\'" + reg.NameIsAJointVenture + "\'," +
                "\'" + reg.NameIsAOther + "\'," +
                "\'" + reg.NameIsAOtherIs + "\'," +
                "\'" + reg.NameAsAppeared + "\'," +
                "\'" + reg.DoingBusinessAs + "\'," +
                "\'" + reg.MailingAddress + "\'," +
                "\'" + reg.ApplicantCity + "\'," +
                "\'" + reg.ApplicantState + "\'," +
                "\'" + reg.ApplicantZip + "\'," +
                "\'" + reg.ApplicantContact + "\'," +
                "\'" + reg.ApplicantEmail + "\'," +
                "\'" + reg.ApplicantHomePhone + "\'," +
                "\'" + reg.ApplicantBusinessPhone + "\'," +
                "\'" + reg.ApplicantFax + "\'," +
                "\'" + reg.ApplicantWebAddress + "\'" +
                ");";

            return query;
        }

        public string EventInformationQueryStringString(RegisterInformation reg)
        {

            string a;
            string b;
            string c;
            string d;

            if (reg.EventDateFileLabel == null)
            {
                a = null;
            }
            else
            {
                a = reg.EventDateFileLabel;
            }

            if (reg.ActivitiesDescriptionFileLabel == null)
            {
                b = null;
            }
            else
            {
                b = reg.ActivitiesDescriptionFileLabel;
            }

            if (reg.LiabilityReleaseFileLabel == null)
            {
                c = null;
            }
            else
            {
                c = reg.LiabilityReleaseFileLabel;
            }

            if (reg.FollowingActivitiesFileLabel == null)
            {
                d = null;
            }
            else
            {
                d = reg.FollowingActivitiesFileLabel;
            }

            string query = "Use CS4961;" +
                "Insert into EventInformation" +
                "( ID," +
                "EINameOfEvent," +
                "EIDateEventHeldFile," +
                "EIActivitiesDescription," +
                "EIActivitiesDescriptionFile," +
                "EIBusOwner," +
                "EIBusManager," +
                "EIThirdParty," +
                "EIEventPrivacy," +
                "EIAdmissionCharge," +
                "EIAdmissionCost," +
                "EISellAdmissionTicket," +
                "EISellHowManyTickets," +
                "EITotalTicketSalesAmount," +
                "EIPricePerTicket," +
                "EIHowTicketsSold," +
                "EIWhoSellTickets," +
                "EIDonationExpected," +
                "EISeatingTypeIsAssignedSeating," +
                "EISeatingTypeIsOpenSeating," +
                "EISeatingTypeIsBringYourOwnSeating," +
                "EISeatingTypeIsBleachersSeating," +
                "EISeatingTypeIsNotApplicable," +
                "EIPrivateSecurityPersons," +
                "EIPoliceOrSheriffPersons," +
                "EIPeerGroupOrUshersPersons," +
                "EIEmployeesPersons," +
                "EIParentChaperonsPersons," +
                "EIVolunteersPersons," +
                "EISecurityArmed," +
                "EIWandingChecking," +
                "EIFirstAid," +
                "EIFirstAidCompany," +
                "EIReceivedInsuranceCert," +
                "EIADAExit," +
                "EIADAParking," +
                "EIEventAdvertising," +
                "EIAdvertiseByWeb," +
                "EIAdvertisementWebsite," +
                "EIEventIsOnTelevision," +
                "EIEventIsOnRadio," +
                "EIEventIsOnNewspaper," +
                "EIEventIsOnBrochure," +
                "EIEventIsOnHandout," +
                "EIEventIsOnBillboard," +
                "EIEventIsOnPoster," +
                "EIEventIsOnOther," +
                "EIIsAlcoholServed," +
                "EIIsAlcoholSold," +
                "EIIsEventCharged," +
                "EIIsEventPayToAttend," +
                "EIIsEventReceiveDonation," +
                "EIIsThereBeer," +
                "EIIsThereWineOrChampagne," +
                "EIIsThereMixedOrBar," +
                "EIIsThereAlcoholVendor," +
                "EIIsThereAlcoholVendingInsurance," +
                "EIEstimatedAlcoholSales," +
                "EINumberOfAlcoholLocations," +
                "EIIsLiquorLicenseRequired," +
                "EIMustLiquorBeDrankInArea," +
                "EINeedIdToRecieveLiquor," +
                "EIOverAgeDrinkerHaveOtherID," +
                "EIIsThereLimitTwoServingLiquor," +
                "EIIsThereLiquorStaffMonitoring," +
                "EIIsLiquorBarClosedTwoHrsEarly," +
                "EIHasAthleticOrRecreationalActivity," +
                "EIWaiverLiabilityProcedure," +
                "EILiabilityReleaseFile," +
                "EIHasMusic," +
                "EIIsThereLiveMusic," +
                "EIIsThereDiskJockey," +
                "EIIsThereStereoCDPlayer," +
                "EIAmplifiedSound," +
                "EIHowManyArtists," +
                "EIOwnElectricity," +
                "EIArrangements," +
                "EIOtherEntertainment," +
                "EIDescribeOtherEntertainment," +
                "EIJumpsTanksTrains," +
                "EICompanyHired," +
                "EIFollowingActivitiesFile," +
                "EIWaiverDescription" +
                ") values (" +
                id + "," +
                "\'" + reg.EventName + "\'," +
                "\'" + a + "\'," +
                "\'" + reg.ActivitiesDescription + "\'," +
                "\'" + b + "\'," +
                "\'" + reg.InsuredIsOwner + "\'," +
                "\'" + reg.InsuredIsManager + "\'," +
                "\'" + reg.InsuredIsThirdParty + "\'," +
                "\'" + reg.EventIsPrivacy + "\'," +
                "\'" + reg.AdmissionCharge + "\'," +
                "\'" + reg.AdmissionCost + "\'," +
                "\'" + reg.SellTicket + "\'," +
                "\'" + reg.SellHowManyTickets + "\'," +
                "\'" + reg.TotalTicketSalesAmount + "\'," +
                "\'" + reg.PricePerTicket + "\'," +
                "\'" + reg.HowToSellTicket + "\'," +
                "\'" + reg.WhoSellTickets + "\'," +
                "\'" + reg.RecieveDonate + "\'," +
                "\'" + reg.SeatType1 + "\'," +
                "\'" + reg.SeatType2 + "\'," +
                "\'" + reg.SeatType3 + "\'," +
                "\'" + reg.SeatType4 + "\'," +
                "\'" + reg.SeatType5 + "\'," +
                "\'" + reg.NumOfPrivateSecurityPersons + "\'," +
                "\'" + reg.NumOfPoliceOrSheriffPersons + "\'," +
                "\'" + reg.NumOfPeerGroupOrUshersPersons + "\'," +
                "\'" + reg.NumOfEmployeesPersons + "\'," +
                "\'" + reg.NumOfParentChaperonsPersons + "\'," +
                "\'" + reg.NumOfVolunteersPersons + "\'," +
                "\'" + reg.Armed + "\'," +
                "\'" + reg.BagCheck + "\'," +
                "\'" + reg.FirstAid + "\'," +
                "\'" + reg.CompanyForFirstAide + "\'," +
                "\'" + reg.RecievedInsurance + "\'," +
                "\'" + reg.EntranceExit + "\'," +
                "\'" + reg.AccessibleParking + "\'," +
                "\'" + reg.EventAdvertise + "\'," +
                "\'" + reg.EventIsOnWebsite + "\'," +
                "\'" + reg.EventWebsite + "\'," +
                "\'" + reg.EventTelevised + "\'," +
                "\'" + reg.EventRadio + "\'," +
                "\'" + reg.EventNewsPaper + "\'," +
                "\'" + reg.EventBrochure + "\'," +
                "\'" + reg.EventHandOut + "\'," +
                "\'" + reg.EventBillBoard + "\'," +
                "\'" + reg.EventPoster + "\'," +
                "\'" + reg.EventOther + "\'," +
                "\'" + reg.AlcoholServe + "\'," +
                "\'" + reg.AlcoholIsSold + "\'," +
                "\'" + reg.AlcoholFee + "\'," +
                "\'" + reg.EventFee + "\'," +
                "\'" + reg.EventDonation + "\'," +
                "\'" + reg.AlcoholType1 + "\'," +
                "\'" + reg.AlcoholType2 + "\'," +
                "\'" + reg.AlcoholType3 + "\'," +
                "\'" + reg.AlcoholVending + "\'," +
                "\'" + reg.AlcoholVendingInsurance + "\'," +
                "\'" + reg.EstimatedAlcoholSales + "\'," +
                "\'" + reg.NumOfAlcoholLocations + "\'," +
                "\'" + reg.LiquorLicense + "\'," +
                "\'" + reg.LiquorDrinkArea + "\'," +
                "\'" + reg.LiquorIdentification + "\'," +
                "\'" + reg.DrinkingAge + "\'," +
                "\'" + reg.LiquorServingLimit + "\'," +
                "\'" + reg.LiquorStaffMonitor + "\'," +
                "\'" + reg.LiquorBarClose + "\'," +
                "\'" + reg.AthleticRecreationalActivity + "\'," +
                "\'" + reg.WaiverAndLiabilityProcedure + "\'," +
                "\'" + c + "\'," +
                "\'" + reg.HaveMusic + "\'," +
                "\'" + reg.TypeOfMusic1 + "\'," +
                "\'" + reg.TypeOfMusic2 + "\'," +
                "\'" + reg.TypeOfMusic3 + "\'," +
                "\'" + reg.AmplifiedMusic + "\'," +
                "\'" + reg.NumOfBandsOrArtists + "\'," +
                "\'" + reg.OwnElectricity + "\'," +
                "\'" + reg.ElectricityArranging + "\'," +
                "\'" + reg.OtherEntertainment + "\'," +
                "\'" + reg.OtherEntertainmentDescription + "\'," +
                "\'" + reg.ActivityStuff + "\'," +
                "\'" + reg.HiredCompanyForActivities + "\'," +
                "\'" + d + "\'," +
                "\'" + reg.ExplainProcedureForWaivers + "\'" +
                ");";
            return query;
        }

        public string MusicTypesQueryString(RegisterInformation reg)
        {
            string query = "Use CS4961;" + "Insert into MusicTypes " +
                "(" +
                "ID, " +
                "IsThereAcidRock," +
                "IsThereAlternative, " +
                "IsThereBigBand," +
                "IsThereBlues, " +
                "IsThereChristian," +
                "IsThereClassical, " +
                "IsThereCountrySoul," +
                "IsThereCountryRock, " +
                "IsThereDeathRock," +
                "IsThereDisco, " +
                "IsThereContemporary," +
                "IsThereEthnicNForeignCultural, " +
                "IsThere1950sN1960s," +
                "IsThereFunk, " +
                "IsThereHardRock," +
                "IsThereHipHop, " +
                "IsThereJazz," +
                "IsTherePop, " +
                "IsThereRap," +
                "IsThereReggae, " +
                "IsThereSoftRock," +
                "IsThereSoul, " +
                "IsThereSymphony," +
                "IsThereSwing, " +
                "IsThereHeavyMetal," +
                "IsThereFolk, " +
                "IsThereGoth," +
                "IsThereGothMetal, " +
                "IsThereGospel," +
                "IsThereIndustrial, " +
                "IsTherePsychedelic," +
                "IsTherePunk, " +
                "IsThereRave," +
                "IsThereSka, " +
                "IsThereTechno," +
                "IsThereBubblegum, " +
                "IsThereRockability, " +
                "IsThereOther," +
                "IsThereOtherDescription" +

                ") values (" +
                id + "," +
                "\'" + reg.MusicType1 + "\'," +
                "\'" + reg.MusicType2 + "\'," +
                "\'" + reg.MusicType3 + "\'," +
                "\'" + reg.MusicType4 + "\'," +
                "\'" + reg.MusicType5 + "\'," +
                "\'" + reg.MusicType6 + "\'," +
                "\'" + reg.MusicType7 + "\'," +
                "\'" + reg.MusicType8 + "\'," +
                "\'" + reg.MusicType9 + "\'," +
                "\'" + reg.MusicType10 + "\'," +
                "\'" + reg.MusicType11 + "\'," +
                "\'" + reg.MusicType12 + "\'," +
                "\'" + reg.MusicType13 + "\'," +
                "\'" + reg.MusicType14 + "\'," +
                "\'" + reg.MusicType15 + "\'," +
                "\'" + reg.MusicType16 + "\'," +
                "\'" + reg.MusicType17 + "\'," +
                "\'" + reg.MusicType18 + "\'," +
                "\'" + reg.MusicType19 + "\'," +
                "\'" + reg.MusicType20 + "\'," +
                "\'" + reg.MusicType21 + "\'," +
                "\'" + reg.MusicType22 + "\'," +
                "\'" + reg.MusicType23 + "\'," +
                "\'" + reg.MusicType24 + "\'," +
                "\'" + reg.MusicType25 + "\'," +
                "\'" + reg.MusicType26 + "\'," +
                "\'" + reg.MusicType27 + "\'," +
                "\'" + reg.MusicType28 + "\'," +
                "\'" + reg.MusicType29 + "\'," +
                "\'" + reg.MusicType30 + "\'," +
                "\'" + reg.MusicType31 + "\'," +
                "\'" + reg.MusicType32 + "\'," +
                "\'" + reg.MusicType33 + "\'," +
                "\'" + reg.MusicType34 + "\'," +
                "\'" + reg.MusicType35 + "\'," +
                "\'" + reg.MusicType36 + "\'," +
                "\'" + reg.MusicType37 + "\'," +
                "\'" + reg.MusicType38 + "\'," +
                "\'" + reg.OtherTypeOfMusic + "\'" +

                ");";
            return query;
        }

        public string FolowingActivities1QueryString(RegisterInformation reg)
        {
            string query = "Use CS4961;" + "Insert into IncludeFollowingActivities1 " +
                "(" +

                "ID, " +
                "IsThereClimbing," +
                "IsThereSkateBoard, " +
                "IsThereRoller," +
                "IsThereCycling, " +
                "IsThereWatercraft," +
                "IsThereGun, " +
                "IsThereFire," +
                "IsThereArmory, " +
                "IsThereChemical," +
                "IsThereMedical, " +
                "IsThereConstructOrDemo," +
                "IsThereScaffoldAbove4Ft " +

                ") values (" +

                id + "," +
                "\'" + reg.ClimbWall + "\'," +
                "\'" + reg.SkateBoard + "\'," +
                "\'" + reg.RollerAct + "\'," +
                "\'" + reg.CycleAct + "\'," +
                "\'" + reg.WaterAct + "\'," +
                "\'" + reg.GunAct + "\'," +
                "\'" + reg.FireAct + "\'," +
                "\'" + reg.ArmoryAct + "\'," +
                "\'" + reg.ChemicalAct + "\'," +
                "\'" + reg.MedicalAct + "\'," +
                "\'" + reg.DemolitionAct + "\'," +
                "\'" + reg.ScaffoldingfAct + "\'" +

                ");";
            return query;
        }

        public string FolowingActivities2QueryString(RegisterInformation reg)
        {
            string query = "Use CS4961;" + "Insert into IncludeFollowingActivities2 " +
                "(" +

                "ID, " +
                "HasAirRides," +
                "HasTerrainBoarding, " +
                "HasBaseJumping," +
                "HasBouldering, " +
                "HasBoxingMartialArts," +
                "HasBungeeJumping, " +
                "HasCircusCarnival," +
                "HasConcertsOver6Hrs, " +
                "HasConcertwithMoshPit," +
                "HasPlatformBoardDiving, " +
                "HasHangGliding," +
                "HasKayakRaftCanoe," +
                "HasMechanicalRide," +
                "HasMotorSport," +
                "HasMountainBiking," +
                "HasPowerBoats," +
                "HasProSportCashPrizeGames," +
                "HasPyroAndFire," +
                "HasRapHeavyMetalConcert," +
                "HasRockClimbing," +
                "HasRodeoAndRoping," +
                "HasSkinDiving," +
                "HasScubaDiving," +
                "HasTractorTruckPull," +
                "HasTrampoline " +

                ") values (" +

                id + "," +
                "\'" + reg.AirRiding + "\'," +
                "\'" + reg.TerrainBoarding + "\'," +
                "\'" + reg.BaseJumping + "\'," +
                "\'" + reg.Bouldering + "\'," +
                "\'" + reg.BoxingMaritalArts + "\'," +
                "\'" + reg.BungeeAct + "\'," +
                "\'" + reg.CircusCarnival + "\'," +
                "\'" + reg.Concert6HrAct + "\'," +
                "\'" + reg.ConcertDanceAct + "\'," +
                "\'" + reg.PlatformBoardDiving + "\'," +
                "\'" + reg.HangGliding + "\'," +
                "\'" + reg.KayalRaftCanoeing + "\'," +
                "\'" + reg.MechanicalRide + "\'," +
                "\'" + reg.MotorSportEquipment + "\'," +
                "\'" + reg.MountainBiking + "\'," +
                "\'" + reg.PowerBoats + "\'," +
                "\'" + reg.ProSportCash + "\'," +
                "\'" + reg.PyroFireAct + "\'," +
                "\'" + reg.RapRockConcert + "\'," +
                "\'" + reg.RockClimbAct + "\'," +
                "\'" + reg.RodeoRopeAct + "\'," +
                "\'" + reg.SkinDiveAct + "\'," +
                "\'" + reg.ScubaDiveAct + "\'," +
                "\'" + reg.TractorTruckPull + "\'," +
                "\'" + reg.Trampoline + "\'" +

                ");";

            return query;
        }

        public string EventLocationQueryString(RegisterInformation reg)
        {
            string a;
            string b;
            string c;
            string d;
            string e;
            string f;
            string g;
            string h;
            string i;
            string j;
            string k;

            if (reg.VendorsTableFileLabel == null)
            {
                a = null;
            }
            else
            {
                a = reg.VendorsTableFileLabel;
            }

            if (reg.ExhibitorsTableFileLabel == null)
            {
                b = null;
            }
            else
            {
                b = reg.ExhibitorsTableFileLabel;
            }

            if (reg.CertificationOfEventLocationFileLabel == null)
            {
                c = null;
            }
            else
            {
                c = reg.CertificationOfEventLocationFileLabel;
            }

            if (reg.LACertificationFileLabel == null)
            {
                d = null;
            }
            else
            {
                d = reg.LACertificationFileLabel;
            }

            if (reg.AllVendorsCertificationsFileLabel == null)
            {
                e = null;
            }
            else
            {
                e = reg.AllVendorsCertificationsFileLabel;
            }

            if (reg.AllBrochuresFileLabel == null)
            {
                f = null;
            }
            else
            {
                f = reg.AllBrochuresFileLabel;
            }

            if (reg.CompleteScheduleOfEventsFileLabel == null)
            {
                g = null;
            }
            else
            {
                g = reg.CompleteScheduleOfEventsFileLabel;
            }

            if (reg.WaiverReleasesSignedFileLabel == null)
            {
                h = null;
            }
            else
            {
                h = reg.WaiverReleasesSignedFileLabel;
            }

            if (reg.DiagramOrSitePlanFileLabel == null)
            {
                i = null;
            }
            else
            {
                i = reg.DiagramOrSitePlanFileLabel;
            }

            if (reg.FiveYearLossHistoryFileLabel == null)
            {
                j = null;
            }
            else
            {
                j = reg.FiveYearLossHistoryFileLabel;
            }

            if (reg.EvacuationParkAndTrafficPlanDiagramFileLabel == null)
            {
                k = null;
            }
            else
            {
                k = reg.EvacuationParkAndTrafficPlanDiagramFileLabel;
            }

            string query = "Use CS4961;" + "Insert into EventLocation " +
                "(" +
                "ID, " +
                "ELNameOfFacility," +
                "ELStreetName, " +
                "ELEventCity," +
                "ELEventState," +
                "ELEventZip," +
                "ELOutdoorSize," +
                "ELOutdoorAreaInsured," +
                "ELAreThereVendorsSellingAlcohol," +
                "ELVendorsFile," +
                "ELExhibitorsFile," +
                "ELAreTherePastEvents," +
                "ELCertificateOfInsuranceFile," +
                "ELIsThereEmergencyEvacPlan," +
                "ELEvacuationPlanDescription," +
                "ELIsThereMedicalPresence," +
                "ELNumOfDoctors," +
                "ELNumOfParamedics," +
                "ELNumOfNurses," +
                "ELNumOfEMTandEMS," +
                "ELNumOfOther," +
                "ELIsThereAmbulance," +
                "ELIsThereStreetClosure," +
                "ELIsThereTrafficMitigation," +
                "ELTrafficMitigationDescription," +
                "ELLACertificationFile," +
                "ELVendorsInsuredFile," +
                "ELBrochuresAdsFile," +
                "ELScheduleOfEventsFile," +
                "ELWaiversAndReleaseFile," +
                "ELSitePlanDiagramFile," +
                "ELFiveYearHistoryFile," +
                "ELEvacuationPlanFile" +

                ") values (" +
                id + "," +
                "\'" + reg.FacilityName + "\'," +
                "\'" + reg.FacilityStreetName + "\'," +
                "\'" + reg.FacilityCity + "\'," +
                "\'" + reg.FacilityState + "\'," +
                "\'" + reg.FacilityZip + "\'," +
                "\'" + reg.OutdoorAreaSize + "\'," +
                "\'" + reg.OutdoorAreaInsured + "\'," +
                "\'" + reg.IsVendorSellingAlcohol + "\'," +
                "\'" + a + "\'," +
                "\'" + b + "\'," +
                "\'" + reg.HeldBefore + "\'," +
                "\'" + c + "\'," +
                "\'" + reg.EvacuationPlan + "\'," +
                "\'" + reg.EvacuationPlanDescription + "\'," +
                "\'" + reg.IsThereMedicalPresence + "\'," +
                "\'" + reg.NumOfDoctors + "\'," +
                "\'" + reg.NumOfParamedics + "\'," +
                "\'" + reg.NumOfNurses + "\'," +
                "\'" + reg.NumOfEMTOrEMS + "\'," +
                "\'" + reg.NumOfOther + "\'," +
                "\'" + reg.AmbulanceOnSite + "\'," +
                "\'" + reg.StreetClosure + "\'," +
                "\'" + reg.TrafficMitigation + "\'," +
                "\'" + reg.TrafficMitigationDescription + "\'," +
                "\'" + d + "\'," +
                "\'" + e + "\'," +
                "\'" + f + "\'," +
                "\'" + g + "\'," +
                "\'" + h + "\'," +
                "\'" + i + "\'," +
                "\'" + j + "\'," +
                "\'" + k + "\'" +

                ");";
            return query;
        }

        public string FinalSectionQueryString(RegisterInformation reg)
        {
            string query = "Use CS4961;" + "Insert into FinalSection " +
                "(" +
                "ID, " +

                "FSApplicantSignature," +
                "FSApplicantTitle," +
                "FSFinishedApplicationDate," +
                "FSSupervisorInitials," +
                "FSAssemblingsPermitDate" +

                ") values (" +
                id + "," +
                "\'" + reg.ApplicantSignature + "\'," +
                "\'" + reg.ApplicantTitle + "\'," +
                "\'" + reg.ApplicationDate + "\'," +
                "\'" + reg.SupervisorInitials + "\'," +
                "\'" + reg.AssemblingsPermitSignedDate + "\'" +
                ");";

            return query;
        }

        public string FinalSectionPermitQueryString(RegisterInformation reg)
        {
            string query =
                "Use CS4961;" + "Insert into Permit " +
                "(" +
                "ID, " +

                "FSPermitName," +
                "FSPermitYesOrNo," +
                "FSPermitApproval," +
                "FSPermitDate" +

                ") values " + //Each row equals one permit with name or type of permit, radiobutton value, approval, and signed date
                "(" + id + "," + "\'" + reg.SecurityDepositRow + "\'," + "\'" + reg.SecurityDepositRadio + "\'," +
                "\'" + reg.SecurityDepositApproval + "\'," + "\'" + reg.SecurityDepositSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.BusinessLicenseRow + "\'," + "\'" + reg.BusinessLicenseRadio + "\'," +
                "\'" + reg.BusinessLicenseApproval + "\'," + "\'" + reg.BusinessLicenseSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.DancePermitRow + "\'," + "\'" + reg.DancePermitRadio + "\'," +
                "\'" + reg.DancePermitApproval + "\'," + "\'" + reg.DancePermitSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.EnvironmentalHealthPermitRow + "\'," + "\'" + reg.EnvironmentalHealthPermitRadio + "\'," +
                "\'" + reg.EnvironmentalHealthPermitApproval + "\'," + "\'" + reg.EnvironmentalHealthPermitSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.ABCLicenseRow + "\'," + "\'" + reg.ABCLicenseRadio + "\'," +
                "\'" + reg.ABCLicenseApproval + "\'," + "\'" + reg.ABCLicenseSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.PoliceServicesRow + "\'," + "\'" + reg.PoliceServicesRadio + "\'," +
                "\'" + reg.PoliceServicesApproval + "\'," + "\'" + reg.PoliceServicesSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.AssemblagePermitRow + "\'," + "\'" + reg.AssemblagePermitRadio + "\'," +
                "\'" + reg.AssemblagePermitApproval + "\'," + "\'" + reg.AssemblagePermitSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.SpecialEventPermitRow + "\'," + "\'" + reg.SpecialEventPermitRadio + "\'," +
                "\'" + reg.SpecialEventPermitApproval + "\'," + "\'" + reg.SpecialEventPermitSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.StreetClosureRow + "\'," + "\'" + reg.StreetClosureRadio + "\'," +
                "\'" + reg.StreetClosureApproval + "\'," + "\'" + reg.StreetClosureSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.TentCanopyApprovalRow + "\'," + "\'" + reg.TentCanopyApprovalRadio + "\'," +
                "\'" + reg.TentCanopyApprovalApproval + "\'," + "\'" + reg.TentCanopyApprovalSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.ElectricianServicesRow + "\'," + "\'" + reg.ElectricianServicesRadio + "\'," +
                "\'" + reg.ElectricianServicesApproval + "\'," + "\'" + reg.ElectricianServicesSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.LiquorLicenseRow + "\'," + "\'" + reg.LiquorLicenseRadio + "\'," +
                "\'" + reg.LiquorLicenseApproval + "\'," + "\'" + reg.LiquorLicenseSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.LiabilityInsuranceRow + "\'," + "\'" + reg.LiabilityInsuranceRadio + "\'," +
                "\'" + reg.LiabilityInsuranceApproval + "\'," + "\'" + reg.LiabilityInsuranceSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.SupplierInsuranceRow + "\'," + "\'" + reg.SupplierInsuranceRadio + "\'," +
                "\'" + reg.SupplierInsuranceApproval + "\'," + "\'" + reg.SupplierInsuranceSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.VendorInsuranceRow + "\'," + "\'" + reg.VendorInsuranceRadio + "\'," +
                "\'" + reg.VendorInsuranceApproval + "\'," + "\'" + reg.VendorInsuranceSignedDate + "\'" + ")" +
                ";";
            return query;
        }


        ////////////////////////////////////////////////////////////// Table With Rows Query Strings
        public string EventTableQueryString(RegisterInformation reg)
        {
            string queryString = "";

            for (int i = 0; i < reg.eventTableRows.Length; i++)
            {
                if (reg.eventTableRows[i].Hours != null && reg.eventTableRows[i].IsAlcoholServed != null && reg.eventTableRows[i].IsAlcoholSold != null)
                {
                    if (i < (reg.eventTableRows.Length))
                    {
                        queryString +=
                        "(" + id + "," + "\'" + reg.eventTableRows[i].Date + "\'," + "\'" + reg.eventTableRows[i].Hours + "\'," +
                        "\'" + reg.eventTableRows[i].Attendance + "\'," + "\'" + reg.eventTableRows[i].IsAlcoholServed + "\'," + "\'" + reg.eventTableRows[i].IsAlcoholSold + "\'" + ")";

                        //if (reg.eventTableRows[i + 1].Hours == null && reg.eventTableRows[i + 1].IsAlcoholServed == null && reg.eventTableRows[i + 1].IsAlcoholSold == null)
                        if (i == reg.eventTableRows.Length - 1)
                        {
                        }
                        else
                        {
                            queryString += ",";
                        }
                    }

                }
            }

            string query = "Use CS4961;" + "Insert into EventTable " +
                "(" +
                "ID, " +
                "EDate," +
                "EHours," +
                "EAttendance," +
                "EIsAlcoholServed," +
                "EIsAlcoholSold" +

                ") values "
                +

                queryString

                +
                ";";

            return query;
        }

        public string ActivityTableQueryString(RegisterInformation reg)
        {
            string queryString = "";

            for (int i = 0; i < reg.activityTableRows.Length; i++)
            {
                if (reg.activityTableRows[i].Activity != null && reg.activityTableRows[i].Attendance != null)
                {
                    if (i < reg.activityTableRows.Length)
                    {
                        queryString +=
                        "(" + id + "," + "\'" + reg.activityTableRows[i].Date + "\'," + "\'" + reg.activityTableRows[i].Activity + "\'," +
                        "\'" + reg.activityTableRows[i].Attendance + "\'" + ")";

                        if (i == (reg.activityTableRows.Length - 1))
                        {
                        }
                        else
                        {
                            queryString += ",";
                        }
                    }

                }
            }

            string query = "Use CS4961;" + "Insert into Activity " +
                "(" +
                "ID, " +
                "ADate," +
                "AActivity," +
                "AAttendance" +

                ") values "
                +

                queryString

                +
                ";";

            return query;
        }

        public string MusicTableQueryString(RegisterInformation reg)
        {
            string queryString = "";

            for (int i = 0; i < reg.musicArtistsTableRows.Length; i++)
            {
                if (reg.musicArtistsTableRows[i].Name != null && reg.musicArtistsTableRows[i].Address != null)
                {
                    if (i < reg.musicArtistsTableRows.Length)
                    {
                        queryString +=
                        "(" + id + "," + "\'" + reg.musicArtistsTableRows[i].Name + "\'," + "\'" + reg.musicArtistsTableRows[i].Address + "\'," +
                        "\'" + reg.musicArtistsTableRows[i].PhoneNumber + "\'," + "\'" + reg.musicArtistsTableRows[i].Contact + "\'" + ")";

                        if (i == (reg.musicArtistsTableRows.Length - 1))
                        {
                        }
                        else
                        {
                            queryString += ",";
                        }
                    }

                }
            }

            string query = "Use CS4961;" + "Insert into MusicArtists " +
                "(" +
                "ID, " +
                "MName," +
                "MAddress," +
                "MPhone," +
                "MContact" +

                ") values "
                +

                queryString

                +
                ";";

            return query;
        }

        public string VendorTableQueryString(RegisterInformation reg)
        {
            string queryString = "";

            for (int i = 0; i < reg.vendorTableRows.Length; i++)
            {
                if (reg.vendorTableRows[i].TypeOfService != null && reg.vendorTableRows[i].Name != null && reg.vendorTableRows[i].MailAddress != null)
                {
                    if (i < (reg.vendorTableRows.Length))
                    {
                        queryString +=
                        "(" + id + "," + "\'" + reg.vendorTableRows[i].TypeOfService + "\'," + "\'" + reg.vendorTableRows[i].Name + "\'," + "\'" + reg.vendorTableRows[i].MailAddress + "\'," +
                        "\'" + reg.vendorTableRows[i].City + "\'," + "\'" + reg.vendorTableRows[i].State + "\'," + "\'" + reg.vendorTableRows[i].ZipCode + "\'," + "\'" + reg.vendorTableRows[i].Phone + "\'" + ")";

                        if (i == (reg.vendorTableRows.Length - 1))
                        {
                        }
                        else
                        {
                            queryString += ",";
                        }
                    }

                }
            }

            string query = "Use CS4961;" + "Insert into Vendor " +
                "(" +
                "ID, " +
                "VTypeOfServ," +
                "VName," +
                "VMailingAddress," +
                "VCity," +
                "VState," +
                "VZip," +
                "VPhone" +

                ") values "
                +

                queryString

                +
                ";";

            return query;
        }

        public string ExhibitorTableQueryString(RegisterInformation reg)
        {
            string queryString = "";

            for (int i = 0; i < reg.exhibitorTableRows.Length; i++)
            {
                if (reg.exhibitorTableRows[i].TypeOfService != null && reg.exhibitorTableRows[i].Name != null && reg.exhibitorTableRows[i].MailAddress != null)
                {
                    if (i < (reg.exhibitorTableRows.Length))
                    {
                        queryString +=
                        "(" + id + "," + "\'" + reg.exhibitorTableRows[i].TypeOfService + "\'," + "\'" + reg.exhibitorTableRows[i].Name + "\'," + "\'" + reg.exhibitorTableRows[i].MailAddress + "\'," +
                        "\'" + reg.exhibitorTableRows[i].City + "\'," + "\'" + reg.exhibitorTableRows[i].State + "\'," + "\'" + reg.exhibitorTableRows[i].ZipCode + "\'," + "\'" + reg.exhibitorTableRows[i].Phone + "\'" + ")";

                        if (i == (reg.exhibitorTableRows.Length - 1))
                        {
                        }
                        else
                        {
                            queryString += ",";
                        }
                    }

                }
            }

            string query = "Use CS4961;" + "Insert into Exhibitor " +
                "(" +
                "ID, " +
                "ExTypeofServvice," +
                "ExName," +
                "ExMailingAddress," +
                "ExCity," +
                "ExState," +
                "ExZip," +
                "ExPhone" +

                ") values "
                +

                queryString

                +
                ";";

            return query;
        }

        public string PastEventTableQueryString(RegisterInformation reg)
        {
            string queryString = "";

            for (int i = 0; i < reg.pastEventTableRows.Length; i++)
            {
                if (reg.pastEventTableRows[i].DateOfClaim != null && reg.pastEventTableRows[i].Claimant != null && reg.pastEventTableRows[i].Description != null)
                {
                    if (i < (reg.pastEventTableRows.Length))
                    {
                        queryString +=
                        "(" + id + "," + "\'" + reg.pastEventTableRows[i].DateOfClaim + "\'," + "\'" + reg.pastEventTableRows[i].Claimant + "\'," + "\'" + reg.pastEventTableRows[i].Description + "\'," +
                        "\'" + reg.pastEventTableRows[i].DateOfPaid + "\'," + "\'" + reg.pastEventTableRows[i].TotalIncurred + "\'" + ")";

                        if (i == (reg.pastEventTableRows.Length - 1))
                        {
                        }
                        else
                        {
                            queryString += ",";
                        }
                    }

                }
            }

            string query = "Use CS4961;" + "Insert into PastEvent " +
                "(" +
                "ID, " +
                "PEDateOfClaim," +
                "PEClaimant," +
                "PEDescription," +
                "PEDateOfPaid," +
                "PETotalIncurred" +

                ") values "
                +

                queryString

                +
                ";";

            return query;
        }

        public string StreetClosureTableQueryString(RegisterInformation reg)
        {
            string queryString = "";

            for (int i = 0; i < reg.streetClosureRows.Length; i++)
            {
                if (reg.streetClosureRows[i].StreetName != null && reg.streetClosureRows[i].ZipCode != null)
                {
                    if (i < (reg.streetClosureRows.Length))
                    {
                        queryString +=
                            "(" + id + "," + "\'" + reg.streetClosureRows[i].StreetName + "\'," + "\'" + reg.streetClosureRows[i].ZipCode + "\'" + ")";

                        if (i == (reg.streetClosureRows.Length - 1))
                        {
                        }
                        else
                        {
                            queryString += ",";
                        }
                    }
                }

            }

            string query = "Use CS4961;" + "Insert into StreetClosure " +
                "(" +
                "ID, " +
                "SCStreetName," +
                "SCZipCode" +

                ") values "
                +

                queryString

                +
                ";";

            return query;
        }

    }
}
