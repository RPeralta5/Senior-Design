﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventsForm04192020.Models
{
    public class FormSectionImportantNotice
    {
        public int ApplicationID { get; set; }
        public string Password { get; set; }
        public string Agreement { get; set; }
        //public string ApplicationFinished { get; set; }
    }
}
