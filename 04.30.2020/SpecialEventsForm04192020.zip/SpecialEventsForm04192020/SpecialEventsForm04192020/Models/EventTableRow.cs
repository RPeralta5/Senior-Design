﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventsForm04192020.Models
{
    public class EventTableRow
    {
        public int ID { get; set; }
        public DateTime Date { get; set; }
        public string Hours { get; set; }
        public string Attendance { get; set; }
        public string IsAlcoholServed { get; set; }
        public string IsAlcoholSold { get; set; }
        
        public EventTableRow (int id, DateTime date, string hours, string attendance, string isAlcoholServed, string isAlcoholSold)
        {
            this.ID = id;
            this.Date = date;
            this.Hours = hours;
            this.Attendance = attendance;
            this.IsAlcoholServed = isAlcoholServed;
            this.IsAlcoholSold = isAlcoholSold;
        }

        public EventTableRow() {}
        
    }
}
