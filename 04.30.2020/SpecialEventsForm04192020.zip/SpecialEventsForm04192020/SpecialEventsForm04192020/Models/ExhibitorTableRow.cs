﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventsForm04192020.Models
{
    public class ExhibitorTableRow
    {
        public int ID { get; set; }
        public string TypeOfService { get; set; }
        public string Name { get; set; }
        public string MailAddress { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        [DataType(DataType.PostalCode)]
        public string ZipCode { get; set; }
        [DataType(DataType.PhoneNumber)]
        public string Phone{ get; set; }

        public ExhibitorTableRow(int id, string typeOfService, string name, string mailAddress,
            string city, string state, string zipCode, string phone)
        {
            this.ID = id;
            this.TypeOfService = typeOfService;
            this.Name = name;
            this.MailAddress = mailAddress;
            this.City = city;
            this.State = state;
            this.ZipCode = zipCode;
            this.Phone = phone;
        }

        public ExhibitorTableRow() { }
    }
}
