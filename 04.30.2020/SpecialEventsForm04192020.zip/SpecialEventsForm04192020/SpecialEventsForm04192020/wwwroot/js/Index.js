﻿// SpecialEventForm CSS

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/************************************************************************************************** Print the HTML page*/
function printPage() {
    document.getElementById("bgVideo").style.display = "none";
    window.print();
    document.getElementById("bgVideo").style.display = "flex";
}

/************************************************************************************************** Add row to EvenTable*/
function addEventTableRow() {
    // Insert new row into last index of table
    var table = document.getElementById("EventTable");
    var newRow = table.insertRow(document.getElementById("EventTable").getElementsByTagName("tr").length);
    //alert(document.getElementById("EventTable").getElementsByTagName("tr").length);

    // Define and instantiate first column
    var newCell00 = newRow.insertCell(0);
    var cellInput00 = document.createElement('label');
    cellInput00.type = "number";
    cellInput00.innerHTML = document.getElementById("EventTable").getElementsByTagName("tr").length - 1;
    newCell00.appendChild(cellInput00);

    // Define and instantiate second column
    var newCell0 = newRow.insertCell(1);
    var cellInput0 = document.createElement('input');
    cellInput0.type = "date";
    cellInput0.id = "EventTableRows" + "[" + (document.getElementById("EventTable").getElementsByTagName("tr").length - 2).toString() + "].Date";
    cellInput0.name = "eventTableRows" + "[" + (document.getElementById("EventTable").getElementsByTagName("tr").length - 2).toString() + "].Date";
    newCell0.appendChild(cellInput0);

    // Define and instantiate third column
    var newCell1 = newRow.insertCell(2);
    var cellInput1 = document.createElement('input');
    cellInput1.type = "text";
    cellInput1.size = 36;
    cellInput1.style.visibility = "visible";
    cellInput1.id = "EventTableRows" + "[" + (document.getElementById("EventTable").getElementsByTagName("tr").length - 2).toString() + "].Hours";
    cellInput1.name = "eventTableRows" + "[" + (document.getElementById("EventTable").getElementsByTagName("tr").length - 2).toString() + "].Hours";
    newCell1.appendChild(cellInput1);

    // Define and instantiate fourth column
    var newCell2 = newRow.insertCell(3);
    var cellInput2 = document.createElement('input');
    cellInput2.type = "number";
    cellInput2.id = "EventTableRows" + "[" + (document.getElementById("EventTable").getElementsByTagName("tr").length - 2).toString() + "].Attendance";
    cellInput2.name = "eventTableRows" + "[" + (document.getElementById("EventTable").getElementsByTagName("tr").length - 2).toString() + "].Attendance";
    cellInput2.pattern = "[0-9]";
    cellInput2.title = "Whole numbers only";
    cellInput2.min = "0";
    cellInput2.step = "1";
    newCell2.appendChild(cellInput2);


    // Insert into column index 4 which is column 5. This is create radiobuttons for served
    var newCell3 = newRow.insertCell(4);

    var cellInput31 = document.createElement('input');
    cellInput31.type = "radio";
    var label31 = document.createElement('label');
    label31.innerHTML = "Yes";
    label31.style.padding = "3px";
    var cellInput32 = document.createElement('input');
    cellInput32.type = "radio";
    var label32 = document.createElement('label');
    label32.innerHTML = "No";
    label32.style.padding = "3px";

    cellInput31.id = "EventTableRows" + "[" + (document.getElementById("EventTable").getElementsByTagName("tr").length - 2).toString() + "].IsAlcoholServed";
    cellInput31.name = "eventTableRows" + "[" + (document.getElementById("EventTable").getElementsByTagName("tr").length - 2).toString() + "].IsAlcoholServed";
    cellInput31.value = "Yes";
    cellInput31.style.visibility = "visible";
    cellInput32.id = "EventTableRows" + "[" + (document.getElementById("EventTable").getElementsByTagName("tr").length - 2).toString() + "].IsAlcoholServed";
    cellInput32.name = "eventTableRows" + "[" + (document.getElementById("EventTable").getElementsByTagName("tr").length - 2).toString() + "].IsAlcoholServed";
    cellInput32.value = "No";
    cellInput32.style.visibility = "visible";

    newCell3.appendChild(cellInput31);
    newCell3.appendChild(label31);
    newCell3.appendChild(cellInput32);
    newCell3.appendChild(label32);



    // Insert into column index 5 which is column 6. This is create radiobuttons for sold
    var newCell4 = newRow.insertCell(5);

    var cellInput41 = document.createElement('input');
    cellInput41.type = "radio";
    var label41 = document.createElement('label');
    label41.innerHTML = "Yes";
    label41.style.padding = "3px";
    var cellInput42 = document.createElement('input');
    cellInput42.type = "radio";
    var label42 = document.createElement('label');
    label42.innerHTML = "No";
    label42.style.padding = "3px";

    cellInput41.id = "EventTableRows" + "[" + (document.getElementById("EventTable").getElementsByTagName("tr").length - 2).toString() + "].IsAlcoholSold";
    cellInput41.name = "eventTableRows" + "[" + (document.getElementById("EventTable").getElementsByTagName("tr").length - 2).toString() + "].IsAlcoholSold";
    cellInput41.value = "Yes";
    cellInput42.id = "EventTableRows" + "[" + (document.getElementById("EventTable").getElementsByTagName("tr").length - 2).toString() + "].IsAlcoholSold";
    cellInput42.name = "eventTableRows" + "[" + (document.getElementById("EventTable").getElementsByTagName("tr").length - 2).toString() + "].IsAlcoholSold";
    cellInput42.value = "No";



    newCell4.appendChild(cellInput41);
    newCell4.appendChild(label41);
    newCell4.appendChild(cellInput42);
    newCell4.appendChild(label42);


    var newHeight = (Math.ceil((Math.sqrt(document.getElementById("EventTable").getElementsByTagName("tr").length))) * 50 + 50).toString() + "px";
    document.getElementById("EventTable").style.height = newHeight;
}

/************************************************************************************************** Add row to ActivityTable*/
function addActivityTableRow() {
    // Insert new row into last index of table
    var table1 = document.getElementById("ActivityTable");
    var newRow1 = table1.insertRow(document.getElementById("ActivityTable").getElementsByTagName("tr").length);
    //alert(document.getElementById("ActivityTable").getElementsByTagName("tr").length);

    // Define and instantiate first column
    var newCell001 = newRow1.insertCell(0);
    var cellInput001 = document.createElement('label');
    cellInput001.type = "number";
    cellInput001.innerHTML = document.getElementById("ActivityTable").getElementsByTagName("tr").length - 1;
    newCell001.appendChild(cellInput001);

    // Define and instantiate second column
    var newCell01 = newRow1.insertCell(1);
    var cellInput01 = document.createElement('input');
    cellInput01.type = "date";
    cellInput01.id = "ActivityTableRows" + "[" + (document.getElementById("ActivityTable").getElementsByTagName("tr").length - 2).toString() + "].Date";
    cellInput01.name = "activityTableRows" + "[" + (document.getElementById("ActivityTable").getElementsByTagName("tr").length - 2).toString() + "].Date";

    newCell01.appendChild(cellInput01);

    // Define and instantiate third column
    var newCell11 = newRow1.insertCell(2);
    var cellInput11 = document.createElement('input');
    cellInput11.type = "text";
    cellInput11.size = 76;
    cellInput11.id = "ActivityTableRows" + "[" + (document.getElementById("ActivityTable").getElementsByTagName("tr").length - 2).toString() + "].Activity";
    cellInput11.name = "activityTableRows" + "[" + (document.getElementById("ActivityTable").getElementsByTagName("tr").length - 2).toString() + "].Activity";

    newCell11.appendChild(cellInput11);

    // Define and instantiate fourth column
    var newCell21 = newRow1.insertCell(3);
    var cellInput21 = document.createElement('input');
    cellInput21.type = "number";
    cellInput21.id = "ActivityTableRows" + "[" + (document.getElementById("ActivityTable").getElementsByTagName("tr").length - 2).toString() + "].Attendance";
    cellInput21.name = "activityTableRows" + "[" + (document.getElementById("ActivityTable").getElementsByTagName("tr").length - 2).toString() + "].Attendance";
    cellInput21.pattern = "[0-9]";
    cellInput21.title = "Whole numbers only";
    cellInput21.min = "0";
    cellInput21.step = "1";

    newCell21.appendChild(cellInput21);


    var newHeight = (Math.ceil((Math.sqrt(document.getElementById("ActivityTable").getElementsByTagName("tr").length))) * 50 + 50).toString() + "px";
    //alert((Math.ceil((document.getElementById("ActivityTable").getElementsByTagName("tr").length / 5)) * 50).toString());
    document.getElementById("ActivityTable").style.height = newHeight;
}

/************************************************************************************************** Add row to MusicTable*/
function addMusicTableRow() {
    // Insert new row into last index of table
    var table1 = document.getElementById("MusicTable");
    var newRow1 = table1.insertRow(document.getElementById("MusicTable").getElementsByTagName("tr").length);
    //alert(document.getElementById("MusicTable").getElementsByTagName("tr").length);

    // Define and instantiate first column
    var newCell001 = newRow1.insertCell(0);
    var cellInput001 = document.createElement('label');
    cellInput001.type = "number";
    cellInput001.innerHTML = document.getElementById("MusicTable").getElementsByTagName("tr").length - 1;
    newCell001.appendChild(cellInput001);

    // Define and instantiate second column
    var newCell01 = newRow1.insertCell(1);
    var cellInput01 = document.createElement('input');
    cellInput01.type = "text";
    cellInput01.id = "MusicArtistsTableRows" + "[" + (document.getElementById("MusicTable").getElementsByTagName("tr").length - 2).toString() + "].Name";
    cellInput01.name = "musicArtistsTableRows" + "[" + (document.getElementById("MusicTable").getElementsByTagName("tr").length - 2).toString() + "].Name";
    cellInput01.size = 22;
    newCell01.appendChild(cellInput01);

    // Define and instantiate third column
    var newCell11 = newRow1.insertCell(2);
    var cellInput11 = document.createElement('input');
    cellInput11.type = "text";
    cellInput11.id = "MusicArtistsTableRows" + "[" + (document.getElementById("MusicTable").getElementsByTagName("tr").length - 2).toString() + "].Address";
    cellInput11.name = "musicArtistsTableRows" + "[" + (document.getElementById("MusicTable").getElementsByTagName("tr").length - 2).toString() + "].Address";
    cellInput11.size = 42;
    newCell11.appendChild(cellInput11);

    // Define and instantiate fourth column
    var newCell21 = newRow1.insertCell(3);
    var cellInput21 = document.createElement('input');
    cellInput21.type = "tel";
    cellInput21.pattern = "[0-9]{3}-[0-9]{3}-[0-9]{4}";
    cellInput21.title = "xxx-xxx-xxxx"
    cellInput21.id = "MusicArtistsTableRows" + "[" + (document.getElementById("MusicTable").getElementsByTagName("tr").length - 2).toString() + "].PhoneNumber";
    cellInput21.name = "musicArtistsTableRows" + "[" + (document.getElementById("MusicTable").getElementsByTagName("tr").length - 2).toString() + "].PhoneNumber";
    cellInput21.setAttribute("class", "Phone");
    newCell21.appendChild(cellInput21);

    // Define and instantiate fifth column
    var newCell31 = newRow1.insertCell(4);
    var cellInput31 = document.createElement('input');
    cellInput31.type = "text";
    cellInput31.id = "MusicArtistsTableRows" + "[" + (document.getElementById("MusicTable").getElementsByTagName("tr").length - 2).toString() + "].Contact";
    cellInput31.name = "musicArtistsTableRows" + "[" + (document.getElementById("MusicTable").getElementsByTagName("tr").length - 2).toString() + "].Contact";
    cellInput31.size = 22;
    newCell31.appendChild(cellInput31);


    var newHeight = (Math.ceil((Math.sqrt(document.getElementById("MusicTable").getElementsByTagName("tr").length))) * 50 + 50).toString() + "px";
    // alert((Math.ceil((document.getElementById("MusicTable").getElementsByTagName("tr").length / 5)) * 50).toString());
    document.getElementById("MusicTable").style.height = newHeight;
}

/************************************************************************************************** Add row to VendorsTable */
function addVendorsTableRow() {
    // Insert new row into last index of table
    var table = document.getElementById("VendorsTable");
    var newRow = table.insertRow(document.getElementById("VendorsTable").getElementsByTagName("tr").length);
    //alert(document.getElementById("VendorsTable").getElementsByTagName("tr").length);

    // Define and instantiate Column 1
    var newCell00 = newRow.insertCell(0);
    var cellInput00 = document.createElement('label');
    cellInput00.type = "number";
    cellInput00.innerHTML = document.getElementById("VendorsTable").getElementsByTagName("tr").length - 1;
    newCell00.appendChild(cellInput00);

    // Define and instantiate Column 2
    var newCell0 = newRow.insertCell(1);
    var cellInput0 = document.createElement('textarea');
    cellInput0.id = "VendorTableRows" + "[" + (document.getElementById("VendorsTable").getElementsByTagName("tr").length - 2).toString() + "].TypeOfService";
    cellInput0.name = "vendorTableRows" + "[" + (document.getElementById("VendorsTable").getElementsByTagName("tr").length - 2).toString() + "].TypeOfService";
    cellInput0.rows = 4;
    newCell0.appendChild(cellInput0);


    //Create Column 3
    var newCell3 = newRow.insertCell(2);

    //Column 3 Row 1
    var Row1Div = document.createElement('div');
    //Row1Div.setAttribute("class", "row");
    var NameLabel = document.createElement('label');
    NameLabel.innerHTML = " Name ";
    var NameInput = document.createElement('input');
    NameInput.type = "text";
    NameInput.id = "VendorTableRows" + "[" + (document.getElementById("VendorsTable").getElementsByTagName("tr").length - 2).toString() + "].Name";
    NameInput.name = "vendorTableRows" + "[" + (document.getElementById("VendorsTable").getElementsByTagName("tr").length - 2).toString() + "].Name";
    NameInput.setAttribute("size", "48");
    Row1Div.appendChild(NameLabel);
    Row1Div.appendChild(NameInput);
    newCell3.appendChild(Row1Div);

    //Column 3 Row 2
    var Row2Div = document.createElement('div');
    //Row2Div.setAttribute("class", "row");
    var AddressLabel = document.createElement('label');
    AddressLabel.innerHTML = " Mailing Address ";
    var AddressInput = document.createElement('input');
    AddressInput.type = "text";
    AddressInput.id = "VendorTableRows" + "[" + (document.getElementById("VendorsTable").getElementsByTagName("tr").length - 2).toString() + "].MailAddress";
    AddressInput.name = "vendorTableRows" + "[" + (document.getElementById("VendorsTable").getElementsByTagName("tr").length - 2).toString() + "].MailAddress";
    AddressInput.setAttribute("size", "45");
    AddressInput.setAttribute("class", "Address");
    Row2Div.appendChild(AddressLabel);
    Row2Div.appendChild(AddressInput);
    newCell3.appendChild(Row2Div);


    //Column 3 Row 3
    var Row3Div = document.createElement('div');
    //Row3Div.setAttribute("class", "row");
    var CityLabel = document.createElement('label');
    CityLabel.innerHTML = " City ";
    var CityInput = document.createElement('input');
    CityInput.type = "text";
    CityInput.id = "VendorTableRows" + "[" + (document.getElementById("VendorsTable").getElementsByTagName("tr").length - 2).toString() + "].City";
    CityInput.name = "vendorTableRows" + "[" + (document.getElementById("VendorsTable").getElementsByTagName("tr").length - 2).toString() + "].City";
    CityInput.setAttribute("class", "City");
    var StateLabel = document.createElement('label');
    StateLabel.innerHTML = " State ";
    var StateInput = document.createElement('input');
    StateInput.type = "text";
    StateInput.id = "VendorTableRows" + "[" + (document.getElementById("VendorsTable").getElementsByTagName("tr").length - 2).toString() + "].State";
    StateInput.name = "vendorTableRows" + "[" + (document.getElementById("VendorsTable").getElementsByTagName("tr").length - 2).toString() + "].State";
    StateInput.pattern = "[A-Z]{2}";
    StateInput.title = "2 Capital letters";
    StateInput.maxLength = "2";
    StateInput.setAttribute("class", "State");
    StateInput.setAttribute("maxlength", "2");
    var ZipLabel = document.createElement('label');
    ZipLabel.innerHTML = " Zip ";
    var ZipInput = document.createElement('input');
    ZipInput.type = "number";
    ZipInput.id = "VendorTableRows" + "[" + (document.getElementById("VendorsTable").getElementsByTagName("tr").length - 2).toString() + "].ZipCode";
    ZipInput.name = "vendorTableRows" + "[" + (document.getElementById("VendorsTable").getElementsByTagName("tr").length - 2).toString() + "].ZipCode";
    ZipInput.setAttribute("class", "Zip");
    ZipInput.pattern = "[0-9]{5}";
    ZipInput.title = "Any USPS Zipcode between 501 - 99950";
    ZipInput.min = "501";
    ZipInput.max = "99950";
    Row3Div.appendChild(CityLabel);
    Row3Div.appendChild(CityInput);
    Row3Div.appendChild(StateLabel);
    Row3Div.appendChild(StateInput);
    Row3Div.appendChild(ZipLabel);
    Row3Div.appendChild(ZipInput);
    newCell3.appendChild(Row3Div);

    //Column 3 Row 4
    var Row4Div = document.createElement('div');
    //Row4Div.setAttribute("class", "row");
    var PhoneLabel = document.createElement('label');
    PhoneLabel.innerHTML = " Phone ";
    var PhoneInput = document.createElement('input');
    PhoneInput.type = "tel";
    PhoneInput.pattern = "[0-9]{3}-[0-9]{3}-[0-9]{4}";
    PhoneInput.title = "xxx-xxx-xxxx";
    PhoneInput.id = "VendorTableRows" + "[" + (document.getElementById("VendorsTable").getElementsByTagName("tr").length - 2).toString() + "].Phone";
    PhoneInput.name = "vendorTableRows" + "[" + (document.getElementById("VendorsTable").getElementsByTagName("tr").length - 2).toString() + "].Phone";
    PhoneInput.size = "10";
    PhoneInput.setAttribute("class", "vendorsPhone");
    Row4Div.appendChild(PhoneLabel);
    Row4Div.appendChild(PhoneInput);
    newCell3.appendChild(Row4Div);


    var newHeight = (Math.ceil((Math.sqrt(document.getElementById("VendorsTable").getElementsByTagName("tr").length))) * 50 + 175).toString() + "px";
    //alert((Math.ceil((document.getElementById("VendorsTable").getElementsByTagName("tr").length / 5)) * 50).toString());
    document.getElementById("VendorsTable").style.height = newHeight;
}

/************************************************************************************************** Add row to ExhibitorsTable */
function addExhibitorsTableRow() {
    // Insert new row into last index of table
    var table = document.getElementById("ExhibitorsTable");
    var newRow = table.insertRow(document.getElementById("ExhibitorsTable").getElementsByTagName("tr").length);
    //alert(document.getElementById("VendorsTable").getElementsByTagName("tr").length);

    // Define and instantiate Column 1
    var newCell00 = newRow.insertCell(0);
    var cellInput00 = document.createElement('label');
    cellInput00.type = "number";
    cellInput00.innerHTML = document.getElementById("ExhibitorsTable").getElementsByTagName("tr").length - 1;
    newCell00.appendChild(cellInput00);

    // Define and instantiate Column 2
    var newCell0 = newRow.insertCell(1);
    var cellInput0 = document.createElement('textarea');
    cellInput0.id = "ExhibitorTableRows" + "[" + (document.getElementById("ExhibitorsTable").getElementsByTagName("tr").length - 2).toString() + "].TypeOfService";
    cellInput0.name = "exhibitorTableRows" + "[" + (document.getElementById("ExhibitorsTable").getElementsByTagName("tr").length - 2).toString() + "].TypeOfService";
    cellInput0.rows = 4;
    newCell0.appendChild(cellInput0);


    //Create Column 3
    var newCell3 = newRow.insertCell(2);

    //Column 3 Row 1
    var Row1Div = document.createElement('div');
    //Row1Div.setAttribute("class", "row");
    var NameLabel = document.createElement('label');
    NameLabel.innerHTML = " Name ";
    var NameInput = document.createElement('input');
    NameInput.type = "text";
    NameInput.id = "ExhibitorTableRows" + "[" + (document.getElementById("ExhibitorsTable").getElementsByTagName("tr").length - 2).toString() + "].Name";
    NameInput.name = "exhibitorTableRows" + "[" + (document.getElementById("ExhibitorsTable").getElementsByTagName("tr").length - 2).toString() + "].Name";
    NameInput.setAttribute("size", "48");
    Row1Div.appendChild(NameLabel);
    Row1Div.appendChild(NameInput);
    newCell3.appendChild(Row1Div);

    //Column 3 Row 2
    var Row2Div = document.createElement('div');
    //Row2Div.setAttribute("class", "row");
    var AddressLabel = document.createElement('label');
    AddressLabel.innerHTML = " Mailing Address ";
    var AddressInput = document.createElement('input');
    AddressInput.type = "text";
    AddressInput.id = "ExhibitorTableRows" + "[" + (document.getElementById("ExhibitorsTable").getElementsByTagName("tr").length - 2).toString() + "].MailAddress";
    AddressInput.name = "exhibitorTableRows" + "[" + (document.getElementById("ExhibitorsTable").getElementsByTagName("tr").length - 2).toString() + "].MailAddress";
    AddressInput.setAttribute("size", "45");
    AddressInput.setAttribute("class", "Address");
    Row2Div.appendChild(AddressLabel);
    Row2Div.appendChild(AddressInput);
    newCell3.appendChild(Row2Div);


    //Column 3 Row 3
    var Row3Div = document.createElement('div');
    //Row3Div.setAttribute("class", "row");
    var CityLabel = document.createElement('label');
    CityLabel.innerHTML = " City ";
    var CityInput = document.createElement('input');
    CityInput.type = "text";
    CityInput.id = "VendorTableRows" + "[" + (document.getElementById("ExhibitorsTable").getElementsByTagName("tr").length - 2).toString() + "].City";
    CityInput.name = "vendorTableRows" + "[" + (document.getElementById("ExhibitorsTable").getElementsByTagName("tr").length - 2).toString() + "].City";
    CityInput.setAttribute("class", "City");
    var StateLabel = document.createElement('label');
    StateLabel.innerHTML = " State ";
    var StateInput = document.createElement('input');
    StateInput.type = "text";
    StateInput.id = "VendorTableRows" + "[" + (document.getElementById("ExhibitorsTable").getElementsByTagName("tr").length - 2).toString() + "].State";
    StateInput.name = "vendorTableRows" + "[" + (document.getElementById("ExhibitorsTable").getElementsByTagName("tr").length - 2).toString() + "].State";
    StateInput.pattern = "[A-Z]{2}";
    StateInput.title = "2 Capital letters";
    StateInput.maxLength = "2";
    StateInput.setAttribute("class", "State");
    StateInput.setAttribute("maxlength", "2");
    var ZipLabel = document.createElement('label');
    ZipLabel.innerHTML = " Zip ";
    var ZipInput = document.createElement('input');
    ZipInput.type = "number";
    ZipInput.id = "VendorTableRows" + "[" + (document.getElementById("ExhibitorsTable").getElementsByTagName("tr").length - 2).toString() + "].ZipCode";
    ZipInput.name = "vendorTableRows" + "[" + (document.getElementById("ExhibitorsTable").getElementsByTagName("tr").length - 2).toString() + "].ZipCode";
    ZipInput.setAttribute("class", "Zip");
    ZipInput.pattern = "[0-9]{5}";
    ZipInput.title = "Any USPS Zipcode between 501 - 99950";
    ZipInput.min = "501";
    ZipInput.max = "99950";
    Row3Div.appendChild(CityLabel);
    Row3Div.appendChild(CityInput);
    Row3Div.appendChild(StateLabel);
    Row3Div.appendChild(StateInput);
    Row3Div.appendChild(ZipLabel);
    Row3Div.appendChild(ZipInput);
    newCell3.appendChild(Row3Div);

    //Column 3 Row 4
    var Row4Div = document.createElement('div');
    //Row4Div.setAttribute("class", "row");
    var PhoneLabel = document.createElement('label');
    PhoneLabel.innerHTML = " Phone ";
    var PhoneInput = document.createElement('input');
    PhoneInput.type = "tel";
    PhoneInput.pattern = "[0-9]{3}-[0-9]{3}-[0-9]{4}";
    PhoneInput.title = "xxx-xxx-xxxx";
    PhoneInput.id = "VendorTableRows" + "[" + (document.getElementById("ExhibitorsTable").getElementsByTagName("tr").length - 2).toString() + "].Phone";
    PhoneInput.name = "vendorTableRows" + "[" + (document.getElementById("ExhibitorsTable").getElementsByTagName("tr").length - 2).toString() + "].Phone";
    PhoneInput.size = "10";
    PhoneInput.setAttribute("class", "vendorsPhone");
    Row4Div.appendChild(PhoneLabel);
    Row4Div.appendChild(PhoneInput);
    newCell3.appendChild(Row4Div);


    var newHeight = (Math.ceil((Math.sqrt(document.getElementById("ExhibitorsTable").getElementsByTagName("tr").length))) * 50 + 175).toString() + "px";
    //alert((Math.ceil((document.getElementById("VendorsTable").getElementsByTagName("tr").length / 5)) * 50).toString());
    document.getElementById("ExhibitorsTable").style.height = newHeight;
}

/************************************************************************************************** Add row to SimilarPastEventTable*/
function AddSimilarPastEventTableRow() {
    // Insert new row into last index of table
    var table = document.getElementById("SimilarPastEventTable");
    var newRow = table.insertRow(document.getElementById("SimilarPastEventTable").getElementsByTagName("tr").length);
    //alert(document.getElementById("SimilarPastEventTable").getElementsByTagName("tr").length);

    // Define and instantiate first column
    var newCell00 = newRow.insertCell(0);
    var cellInput00 = document.createElement('label');
    cellInput00.type = "number";
    cellInput00.innerHTML = document.getElementById("SimilarPastEventTable").getElementsByTagName("tr").length - 1;
    newCell00.appendChild(cellInput00);


    // Define and instantiate second column
    var newCell0 = newRow.insertCell(1);
    var cellInput0 = document.createElement('input');
    cellInput0.type = "date";
    cellInput0.id = "PastEventTableRows" + "[" + (document.getElementById("SimilarPastEventTable").getElementsByTagName("tr").length - 2).toString() + "].DateOfClaim";
    cellInput0.name = "pastEventTableRows" + "[" + (document.getElementById("SimilarPastEventTable").getElementsByTagName("tr").length - 2).toString() + "].DateOfClaim";
    newCell0.appendChild(cellInput0);

    // Define and instantiate third column
    var newCell1 = newRow.insertCell(2);
    var cellInput1 = document.createElement('input');
    cellInput1.type = "text";
    cellInput1.id = "PastEventTableRows" + "[" + (document.getElementById("SimilarPastEventTable").getElementsByTagName("tr").length - 2).toString() + "].Claimant";
    cellInput1.name = "pastEventTableRows" + "[" + (document.getElementById("SimilarPastEventTable").getElementsByTagName("tr").length - 2).toString() + "].Claimant";
    cellInput1.size = 20;
    newCell1.appendChild(cellInput1);

    // Define and instantiate fourth column
    var newCell2 = newRow.insertCell(3);
    var cellInput2 = document.createElement('textarea');
    cellInput2.id = "PastEventTableRows" + "[" + (document.getElementById("SimilarPastEventTable").getElementsByTagName("tr").length - 2).toString() + "].Description";
    cellInput2.name = "pastEventTableRows" + "[" + (document.getElementById("SimilarPastEventTable").getElementsByTagName("tr").length - 2).toString() + "].Description";
    newCell2.appendChild(cellInput2);

    // Define and instantiate fifth column
    var newCell3 = newRow.insertCell(4);
    var cellInput3 = document.createElement('input');
    cellInput3.type = "date";
    cellInput3.id = "PastEventTableRows" + "[" + (document.getElementById("SimilarPastEventTable").getElementsByTagName("tr").length - 2).toString() + "].DateOfPaid";
    cellInput3.name = "pastEventTableRows" + "[" + (document.getElementById("SimilarPastEventTable").getElementsByTagName("tr").length - 2).toString() + "].DateOfPaid";
    newCell3.appendChild(cellInput3);

    // Define and instantiate sixth column
    var newCell4 = newRow.insertCell(5);
    var cellInput4 = document.createElement('input');
    cellInput4.type = "text";
    cellInput4.id = "PastEventTableRows" + "[" + (document.getElementById("SimilarPastEventTable").getElementsByTagName("tr").length - 2).toString() + "].TotalIncurred";
    cellInput4.name = "pastEventTableRows" + "[" + (document.getElementById("SimilarPastEventTable").getElementsByTagName("tr").length - 2).toString() + "].TotalIncurred";
    //callInput4.pattern = "[0-9]";
    var dataType = document.createAttribute("data-type");       // Create a attribute named "data-type"
    dataType.value = "currency";                                // Set the value of the class attribute
    cellInput4.setAttributeNode(dataType);                      // Put the attribute into cellInput4
    newCell4.appendChild(cellInput4);

    var newHeight = (Math.ceil((Math.sqrt(document.getElementById("SimilarPastEventTable").getElementsByTagName("tr").length))) * 50 + 100).toString() + "px";
    //alert((Math.ceil((document.getElementById("SimilarPastEventTable").getElementsByTagName("tr").length / 5)) * 50).toString());
    document.getElementById("SimilarPastEventTable").style.height = newHeight;
}

/************************************************************************************************** Add row to StreetClosureTable */
function AddStreetClosureTableRow() {
    // Insert new row into last index of table
    var table1 = document.getElementById("StreetClosureTable");
    var newRow1 = table1.insertRow(document.getElementById("StreetClosureTable").getElementsByTagName("tr").length);
    //alert(document.getElementById("StreetClosureTable").getElementsByTagName("tr").length);

    // Define and instantiate first column
    var newCell001 = newRow1.insertCell(0);
    var cellInput001 = document.createElement('label');
    cellInput001.type = "number";
    cellInput001.innerHTML = document.getElementById("StreetClosureTable").getElementsByTagName("tr").length - 1;
    newCell001.appendChild(cellInput001);

    // Define and instantiate second column
    var newCell01 = newRow1.insertCell(1);
    var cellInput01 = document.createElement('input');
    cellInput01.type = "text";
    cellInput01.id = "StreetClosureRows" + "[" + (document.getElementById("StreetClosureTable").getElementsByTagName("tr").length - 2).toString() + "].StreetName";
    cellInput01.name = "streetClosureRows" + "[" + (document.getElementById("StreetClosureTable").getElementsByTagName("tr").length - 2).toString() + "].StreetName";
    cellInput01.size = 72;
    newCell01.appendChild(cellInput01);

    // Define and instantiate third column
    var newCell11 = newRow1.insertCell(2);
    var cellInput11 = document.createElement('input');
    cellInput11.type = "number";
    cellInput11.id = "StreetClosureRows" + "[" + (document.getElementById("StreetClosureTable").getElementsByTagName("tr").length - 2).toString() + "].ZipCode";
    cellInput11.name = "streetClosureRows" + "[" + (document.getElementById("StreetClosureTable").getElementsByTagName("tr").length - 2).toString() + "].ZipCode";
    cellInput11.size = 5;
    cellInput11.pattern = "[0-9]{5}";
    cellInput11.title = "Any USPS Zipcode between 501 - 99950";
    cellInput11.min = "501";
    cellInput11.max = "99950";
    newCell11.appendChild(cellInput11);


    var newHeight = (Math.ceil((Math.sqrt(document.getElementById("StreetClosureTable").getElementsByTagName("tr").length))) * 50 + 50).toString() + "px";
    //alert((Math.ceil((document.getElementById("StreetClosureTable").getElementsByTagName("tr").length / 5)) * 50).toString());
    document.getElementById("StreetClosureTable").style.height = newHeight;
}

/************************************************************************************************** Removes last row of any table by table's id put into argument */
function removeLastRowOfTable(tableElementId) {
    //alert(document.getElementById(thisElementId).toString());
    var table = document.getElementById(tableElementId);
    var rowCount = table.rows.length;
    if (rowCount <= 2) {
        alert("Sorry cannot delete a row when there is only one row.");
    }
    else {
        table.deleteRow(rowCount - 1);
    }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/************************************************ For progress bar */
function calculateProgressBar() {
    //alert("This is progresss");

    ///////////////////////////////////////////////////////////// Radio Groups

    var allRadioGroups = [];
    $("input[type=radio]").each(function () {
        if (!$(this).is(':disabled')) {
            if (!allRadioGroups.includes(this.name)) {
                allRadioGroups.push(this.name);
                //alert(this.name);
            }
        }
    });

    var allRadioGroupsChecked = [];
    $("input[type=radio]:checked").each(function () {
        if (!$(this).is(':disabled')) {
            if (!allRadioGroupsChecked.includes(this.name.toString())) {
                allRadioGroupsChecked.push(this.name.toString());
            }
        }
    });
    //alert(allRadioGroupsChecked.length + " RadioGroups have been checked out of " + allRadioGroups.length + " RadioGroups.");

    var namesRadio = [];
    for (var i = 0; i < allRadioGroups.length; i++) {
        if (allRadioGroupsChecked.includes(allRadioGroups[i].toString())) {
        }
        else {
            namesRadio.push(allRadioGroups[i].toString());
        }
    }
    //alert(namesRadio);

    ///////////////////////////////////////////////////////////// TextBoxes

    var allTextBoxes = [];
    $("input[type=text]").each(function () {
        if (!$(this).is(':disabled')) {
            if (!allTextBoxes.includes(this.id)) {
                allTextBoxes.push(this.id);
                //alert(this.name);
            }
        }
    });

    var allTextBoxesChecked = [];
    $("input[type=text]").each(function () {
        if ($(this).val() != "") {
            if (!$(this).is(':disabled')) {
                if (!allTextBoxesChecked.includes(this.id.toString())) {
                    allTextBoxesChecked.push(this.id.toString());
                }
            }
        }
    });
    //alert(allTextBoxesChecked.length + " TextBoxes have been checked out of " + allTextBoxes.length + " Textboxes.");

    var namesTextBox = [];
    for (var i = 0; i < allTextBoxes.length; i++) {
        if (allTextBoxesChecked.includes(allTextBoxes[i].toString())) {
        }
        else {
            namesTextBox.push(allTextBoxes[i].toString());
        }
    }
    //alert(namesTextBox);

    ///////////////////////////////////////////////////////////// TextAreas

    var allTextAreas = [];
    $("textarea").each(function () {
        if (!$(this).is(':disabled')) {
            if (!allTextAreas.includes(this.id)) {
                allTextAreas.push(this.id);
                //alert(this.name);
            }
        }
    });

    var allTextAreasChecked = [];
    $("textarea").each(function () {
        if ($(this).val() != "") {
            if (!$(this).is(':disabled')) {
                if (!allTextAreasChecked.includes(this.id.toString())) {
                    allTextAreasChecked.push(this.id.toString());
                }
            }
        }
    });
    //alert(allTextAreasChecked.length + " TextAreas have been checked out of " + allTextAreas.length + " TextAreas.");

    var namesTextAreas = [];
    for (var i = 0; i < allTextAreas.length; i++) {
        if (allTextAreasChecked.includes(allTextAreas[i].toString())) {
        }
        else {
            namesTextAreas.push(allTextAreas[i].toString());
        }
    }
    //alert(namesTextAreas);

    ///////////////////////////////////////////////////////////// Numbers

    var allNumbers = [];
    $("input[type=number]").each(function () {
        if (!$(this).is(':disabled')) {
            if (!allNumbers.includes(this.name.toString())) {
                allNumbers.push(this.name.toString());
                //alert(this.name);
            }
        }
    });

    var allNumbersChecked = [];
    $("input[type=number]").each(function () {
        if ($(this).val() != "" && $(this).val() != 0) {
            if (!$(this).is(':disabled')) {
                if (!allNumbersChecked.includes(this.name.toString())) {
                    allNumbersChecked.push(this.name.toString());
                }
            }
        }
    });
    //alert(allNumbersChecked.length + " Numbers have been checked out of " + allNumbers.length + " Numbers.");

    var namesNumbers = [];
    for (var i = 0; i < allNumbers.length; i++) {
        if (allNumbersChecked.includes(allNumbers[i].toString())) {
        }
        else {
            namesNumbers.push(allNumbers[i].toString());
        }
    }
    //alert(namesNumbers);

    ///////////////////////////////////////////////////////////// Dates

    var allDates = [];
    $("input[type=date]").each(function () {
        if (!$(this).is(':disabled')) {
            if (!allDates.includes(this.name.toString())) {
                allDates.push(this.name.toString());
                //alert(this.name);
            }
        }
    });

    var allDatesChecked = [];
    $("input[type=date]").each(function () {
        if ($(this).val() != "" && $(this).val() != 0 && $(this).val() != "1900-01-01") {
            if (!$(this).is(':disabled')) {
                if (!allDatesChecked.includes(this.name.toString())) {
                    allDatesChecked.push(this.name.toString());
                }
            }
        }
    });
    //alert(allDatesChecked.length + " Dates have been checked out of " + allDates.length + " Dates.");

    var namesDates = [];
    for (var i = 0; i < allDates.length; i++) {
        if (allDatesChecked.includes(allDates[i].toString())) {
        }
        else {
            namesDates.push(allDates[i].toString());
        }
    }
    //alert(namesDates);

    ///////////////////////////////////////////////////////////// Tels

    var allTels = [];
    $("input[type=tel]").each(function () {
        if (!$(this).is(':disabled')) {
            if (!allTels.includes(this.name.toString())) {
                allTels.push(this.name.toString());
                //alert(this.name);
            }
        }
    });

    var allTelsChecked = [];
    $("input[type=tel]").each(function () {
        if ($(this).val() != "" && $(this).val() != 0 && $(this).val() != "1900-01-01") {
            if (!$(this).is(':disabled')) {
                if (!allTelsChecked.includes(this.name.toString())) {
                    allTelsChecked.push(this.name.toString());
                }
            }
        }
    });
    //alert(allTelsChecked.length + " Dates have been checked out of " + allTels.length + " Dates.");

    var namesTels = [];
    for (var i = 0; i < allTels.length; i++) {
        if (allTelsChecked.includes(allDates[i].toString())) {
        }
        else {
            namesTels.push(allDates[i].toString());
        }
    }
    //alert(namesTels);

    ///////////////////////////////////////////////////////////// Checkboxes
    //alert("This works 1");
    var TotalCheckBoxGroupsNeeded = 0;

    // There are 6 checkbox groups total


    var AgreementCheckBox = 0;
    if (document.getElementById("agreed").checked) {
        AgreementCheckBox = 1;
    }
    TotalCheckBoxGroupsNeeded++;
    //alert("This 1");

    var NameInsuredCheckBox = 0;
    for (var i = 1; i < 15; i++) {
        if (document.getElementById("nameInsured" + [i].toString()).checked) {
            NameInsuredCheckBox = 1;
        }
    }
    TotalCheckBoxGroupsNeeded++;
    //alert("This 2");

    var SeatTypeCheckBox = 0;
    for (var i = 1; i < 6; i++) {
        if (document.getElementById("seatType" + [i].toString()).checked) {
            SeatTypeCheckBox = 1;
        }
    }
    TotalCheckBoxGroupsNeeded++;
    //alert("This 3");

    var AlcoholTypeCheckBox = 0;
    if (document.getElementById("alcoholServeSection").disabled) {
        for (var i = 1; i < 4; i++) {
            if (document.getElementById("alcoholType" + [i].toString()).checked) {
                AlcoholTypeCheckBox = 1;
            }
        }
        TotalCheckBoxGroupsNeeded++;
        //alert("This 4");
    }


    var MusicTypeCheckBox = 0;
    if (document.getElementById("musicSection").disabled) {
        for (var i = 1; i < 4; i++) {
            if (document.getElementById("typeOfMusic" + [i].toString()).checked) {
                MusicTypeCheckBox = 1;
            }
        }
        TotalCheckBoxGroupsNeeded++;
        //alert("This 5");
    }

    var MusicTypePlayedCheckBox = 0;
    if (document.getElementById("musicSection").disabled) {
        for (var i = 1; i < 39; i++) {
            if (document.getElementById("musicTypeCheckBox" + [i].toString()).checked) {
                MusicTypePlayedCheckBox = 1;
            }
        }
        TotalCheckBoxGroupsNeeded++;
        //alert("This 6");
    }
    //alert("This works 2");


    var allCheckBoxGroupsChecked = AgreementCheckBox + NameInsuredCheckBox +
        SeatTypeCheckBox + AlcoholTypeCheckBox + MusicTypeCheckBox + MusicTypePlayedCheckBox;
    //alert("There are " + allCheckBoxGroupsChecked + " Checkbox Groups checked out of " + TotalCheckBoxGroupsNeeded + " Checkbox Groups that need to be checked.");
    //alert(allCheckBoxGroupsChecked + "/" + TotalCheckBoxGroupsNeeded);

    ///////////////////////////////////////////////////////////// Files

    // Only 8 Total Necessary Files excluding 'if,yes' files and 'need more room' files
    var allNecessaryFiles = 8;

    var certificateOfParkFiling = document.getElementById("certificateOfParkFileLabel").value;
    var allCertFiling = document.getElementById("allCertLabel").value;
    var allBrochFiling = document.getElementById("allBrochLabel").value;
    var compSchOfEventFiling = document.getElementById("compSchOfEventLabel").value;
    var waiverReleaseFiling = document.getElementById("waiverReleaseLabel").value;
    var diagramOrSitePlanFiling = document.getElementById("diagramOrSitePlanLabel").value;
    var fiveYearLossHistFiling = document.getElementById("5YearLossHistLabel").value;
    var evacTrafficPlanFiling = document.getElementById("evacTrafficPlanLabel").value;

    var files = [certificateOfParkFiling, allCertFiling, allBrochFiling, compSchOfEventFiling,
        waiverReleaseFiling, diagramOrSitePlanFiling, fiveYearLossHistFiling, evacTrafficPlanFiling];

    var allFilesNotNull = 0;

    for (var i = 0; i < files.length; i++) {
        if (files[i] != null && files[i] != "") {
            allFilesNotNull++;
            //alert("This file is " + files[i].toString());
        }
    }
    //alert(allFilesNotNull + "/" + allNecessaryFiles);
    ////////////////////////////////////////////     //////////////////////////////////////
    //alert("This works 3");

    var userTotalInput =
        allRadioGroupsChecked.length
        +
        allTextBoxesChecked.length
        +
        allNumbersChecked.length
        +
        allDatesChecked.length
        +
        allTelsChecked.length
        +
        allCheckBoxGroupsChecked
        +
        allFilesNotNull
        ;

    var totalInputsAvailable =
        allRadioGroups.length
        +
        allTextBoxes.length
        +
        allNumbers.length
        +
        allTels.length
        +
        allDates.length
        +
        TotalCheckBoxGroupsNeeded
        +
        allNecessaryFiles
        ;

    //alert(userTotalInput + " inputs out of " + totalInputsAvailable + " inputs.");

    $("#progress").attr("value", Math.floor(((userTotalInput / totalInputsAvailable) * 100)));
    $("#percentDone").text(Math.floor(((userTotalInput / totalInputsAvailable) * 100)).toString());    

    if (Math.floor(((userTotalInput / totalInputsAvailable) * 100)) >= 100) {
        document.getElementById("submitButton").disabled = false;
        document.getElementById("submitButton").style.backgroundColor = "white";
    }
    else {
        document.getElementById("submitButton").disabled = true;
        document.getElementById("submitButton").style.backgroundColor = "blue";
    }

}

$(Document).ready(function () {
    $("input").keydown(function (event) {
        //alert(event.keyCode.toString());
        //if (event.keyCode == 189) {
        calculateProgressBar();
        //}
    });
    $("input").keyup(function (event) {
        //alert(event.keyCode.toString());
        //if (event.keyCode == 189) {
        calculateProgressBar();
        //}
    });
    $("input").mousedown(function (event) {
        //alert(event.keyCode.toString());
        //if (event.keyCode == 189) {
        calculateProgressBar();
        //}
    });
    $("input").mouseup(function (event) {
        //alert(event.keyCode.toString());
        //if (event.keyCode == 189) {
        calculateProgressBar();
        //}
    });

    $(this).ready(function () {
        calculateProgressBar();
    });

});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//------------------------------------------------------------------------------------------------------------------
//Notes:
//      $("#MusicTable input").prop('disabled', false);
//      $("#myInputElement").is(":hidden")
//------------------------------------------------------------------------------------------------------------------

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/************************************************ For pause/play video*/
var vid = document.getElementById("bgVideo");
$("#bgVideo").click(function () {
    if (vid.paused) {
        vid.play();
    }
    else {
        vid.pause();
    }
});

function playVid() {
    vid.play();
}

function pauseVid() {
    vid.pause();
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// At start of program making sure everything that is "If yes or no" is displayed as "none"
$(document).ready(function () {
    // Disabled submit button at start
    document.getElementById("submitButton").disabled = true;
    document.getElementById("submitButton").style.backgroundColor = "blue";

    // Make sure eveything that is "If yes or no" is displayed as "none"

    // Application Information Section
    $("#NameInsuredOtherInputText").prop("disabled", true);
    $("#NameInsuredOtherInputText").css("display", "none");

    // Event Information Section
    $("ol[id=admissionChargeSection]").children().each(function () {
        $(this).prop("disabled", true);
        $(this).children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
    });
    $("ol[id=admissionChargeSection]").css("display", "none");

    $("ol[id=firstAideSection]").children().each(function () {
        $(this).prop("disabled", true);
        $(this).children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
    });
    $("ol[id=firstAideSection]").css("display", "none");

    $("ol[id=eventAdvertiseSection]").children().each(function () {
        $(this).prop("disabled", true);
        $(this).children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
    });
    $("ol[id=eventAdvertiseSection]").css("display", "none");

    $("ol[id=alcoholServeSection]").children().each(function () {
        $(this).prop("disabled", true);
        $(this).children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
    });
    $("ol[id=alcoholServeSection]").css("display", "none");

    $("ol[id=athleticRecreationActivitySection]").children().each(function () {
        $(this).prop("disabled", true);
        $(this).children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                            $(this).children().each(function () {
                                $(this).prop("disabled", true);
                            });
                        });
                    });
                });
            });
        });
    });
    $("ol[id=athleticRecreationActivitySection]").css("display", "none");

    $("ol[id=musicSection]").children().each(function () {
        $(this).prop("disabled", true);
        $(this).children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
    });
    $("ol[id=musicSection]").css("display", "none");

    $("#musicOtherType").prop("disabled", true);
    $("#musicOtherType").css("display", "none");

    $("ol[id=activitiesSection]").children().each(function () {
        $(this).prop("disabled", true);
        $(this).children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
    });
    $("ol[id=activitiesSection]").css("display", "none");

    // Event Location Section
    $("ol[id=previousSimilarEvents]").children().each(function () {
        $(this).prop("disabled", true);
        $(this).children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                            $(this).children().each(function () {
                                $(this).prop("disabled", true);
                            });
                        });
                    });
                });
            });
        });
    });
    $("ol[id=previousSimilarEvents]").css("display", "none");

    $("ol[id=emergencyEvacuationExplaination]").children().each(function () {
        $(this).prop("disabled", true);
        $(this).children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
    });
    $("ol[id=emergencyEvacuationExplaination]").css("display", "none");

    $("ol[id=medicalPresent]").children().each(function () {
        $(this).prop("disabled", true);
        $(this).children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
    });
    $("ol[id=medicalPresent]").css("display", "none");

    $("ol[id=streetClosures]").children().each(function () {
        $(this).prop("disabled", true);
        $(this).children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
    });
    $("ol[id=streetClosures]").css("display", "none");

});


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////// All the "If Yes Option" functions are down here

// Enable/Disable ApplicantInformation NameInsured Other text input
function nameInsuredOtherFunction() {
    var checkBox = document.getElementById("nameInsured14");
    var text = document.getElementById("NameInsuredOtherInputText");
    if (checkBox.checked == true) {
        //text.style.display = "block";
        //alert("Now it is unchecked");
        document.getElementById("NameInsuredOtherInputText").disabled = false;
        document.getElementById("NameInsuredOtherInputText").style.display = "block";
        document.getElementById("NameInsuredOtherInputText").value = "";

    } else {
        //text.style.display = "none";
        //alert("Now it is checked");
        document.getElementById("NameInsuredOtherInputText").disabled = true;
        document.getElementById("NameInsuredOtherInputText").value = "";
        document.getElementById("NameInsuredOtherInputText").style.display = "none";
        document.getElementById("NameInsuredOtherInputText").value = "";

    }
}

// Enable/Disable EventInformation AdmissionCharge
function admissionChargeFunction() {
    document.getElementById("admissionChargeSection").style.display = "block";

    admissionOptions = document.getElementsByName("AdmissionCharge"); // Radio Group
    sellTicketOption = document.getElementsByName("SellTicket"); //Radio Group
    howTicketsAreSold = document.getElementsByName("HowToSellTicket"); //Radio Group

    if (admissionOptions[0].checked) {
        $("ol[id=admissionChargeSection]").children().each(function () {
            $(this).prop("disabled", false);
            $(this).children().each(function () {
                $(this).prop("disabled", false);
                $(this).children().each(function () {
                    $(this).prop("disabled", false);
                    $(this).children().each(function () {
                        $(this).prop("disabled", false);
                    });
                });
            });
        });
        $("ol[id=admissionChargeSection").css("display", "block");

        $("li[id=sellTicketsSection]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                    });
                });
            });
        });
        $("li[id=sellTicketsSection]").css("display", "none");


        document.getElementsByName("SellTicket")[0].checked = false;
        document.getElementsByName("SellTicket")[1].checked = false;
        document.getElementById("numberofTicketSales").value = "";
        document.getElementById("totalReceipts").value = "";
        document.getElementById("pricePerTicket").value = "";
        document.getElementsByName("HowToSellTicket")[0].checked = false;
        document.getElementsByName("HowToSellTicket")[1].checked = false;
        document.getElementsByName("HowToSellTicket")[2].checked = false;
        document.getElementById("whoSellsTickets").value = "";
        document.getElementById("admissionChargeCostInput").value = "";
    }
    if (admissionOptions[1].checked) {
        $("ol[id=admissionChargeSection]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                    });
                });
            });
        });
        $("ol[id=admissionChargeSection]").css("display", "none");

        $("li[id=sellTicketsSection]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                    });
                });
            });
        });
        $("li[id=sellTicketsSection]").css("display", "none");


        document.getElementsByName("SellTicket")[0].checked = false;
        document.getElementsByName("SellTicket")[1].checked = false;
        document.getElementById("numberofTicketSales").value = "";
        document.getElementById("totalReceipts").value = "";
        document.getElementById("pricePerTicket").value = "";
        document.getElementsByName("HowToSellTicket")[0].checked = false;
        document.getElementsByName("HowToSellTicket")[1].checked = false;
        document.getElementsByName("HowToSellTicket")[2].checked = false;
        document.getElementById("whoSellsTickets").value = "";
        document.getElementById("admissionChargeCostInput").value = "";

    }

}

// Enable/Disable EventInformation TicketSelling
function sellTickets() {
    sellingTickets = document.getElementsByName("SellTicket");

    if (sellingTickets[0].checked) {

        $("li[id=sellTicketsSection]").children().each(function () {
            $(this).prop("disabled", false);
            $(this).children().each(function () {
                $(this).prop("disabled", false);
                $(this).children().each(function () {
                    $(this).prop("disabled", false);
                    $(this).children().each(function () {
                        $(this).prop("disabled", false);
                    });
                });
            });
        });
        $("li[id=sellTicketsSection]").css("display", "inline-block");


        document.getElementById("numberofTicketSales").value = "";
        document.getElementById("totalReceipts").value = "";
        document.getElementById("pricePerTicket").value = "";
        document.getElementsByName("HowToSellTicket")[0].checked = false;
        document.getElementsByName("HowToSellTicket")[1].checked = false;
        document.getElementsByName("HowToSellTicket")[2].checked = false;
        document.getElementById("whoSellsTickets").value = "";

    }
    if (sellingTickets[1].checked) {

        $("li[id=sellTicketsSection]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                    });
                });
            });
        });
        $("li[id=sellTicketsSection]").css("display", "none");


        document.getElementById("numberofTicketSales").value = "";
        document.getElementById("totalReceipts").value = "";
        document.getElementById("pricePerTicket").value = "";
        document.getElementsByName("HowToSellTicket")[0].checked = false;
        document.getElementsByName("HowToSellTicket")[1].checked = false;
        document.getElementsByName("HowToSellTicket")[2].checked = false;
        document.getElementById("whoSellsTickets").value = "";
    }
}

// Enable/Disable EventInformation FirstAide
function firstAide() {
    firstAideSelection = document.getElementsByName("FirstAid");

    if (firstAideSelection[0].checked) {
        $("ol[id=firstAideSection]").children().each(function () {
            $(this).prop("disabled", false);
            $(this).children().each(function () {
                $(this).prop("disabled", false);
                $(this).children().each(function () {
                    $(this).prop("disabled", false);
                    $(this).children().each(function () {
                        $(this).prop("disabled", false);
                    });
                });
            });
        });
        $("ol[id=firstAideSection]").css("display", "inline-block");


        document.getElementById("firstAideCompany").value = "";
        document.getElementsByName("RecievedInsurance")[0].checked = false;
        document.getElementsByName("RecievedInsurance")[1].checked = false;

    }
    if (firstAideSelection[1].checked) {
        $("ol[id=firstAideSection]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                    });
                });
            });
        });
        $("ol[id=firstAideSection]").css("display", "none");


        document.getElementById("firstAideCompany").value = "";
        document.getElementsByName("RecievedInsurance")[0].checked = false;
        document.getElementsByName("RecievedInsurance")[1].checked = false;
    }

}

// Enable/Disable EventInformation EventAdvertised
function eventAdvertised() {
    eventAdvertisedSelection = document.getElementsByName("EventAdvertise");

    eventWebsite = document.getElementsByName("EventWebsite");
    eventTelevised = document.getElementsByName("EventTelevised");
    eventRadio = document.getElementsByName("EventRadio");
    eventNewsPaper = document.getElementsByName("EventNewsPaper");
    eventBrochure = document.getElementsByName("EventBrochure");
    eventHandOut = document.getElementsByName("EventHandOut");
    eventBillBoard = document.getElementsByName("EventBillBoard");
    eventPoster = document.getElementsByName("EventPoster");
    eventOther = document.getElementsByName("EventOther");

    if (eventAdvertisedSelection[0].checked) {
        $("ol[id=eventAdvertiseSection]").children().each(function () {
            $(this).prop("disabled", false);
            $(this).children().each(function () {
                $(this).prop("disabled", false);
                $(this).children().each(function () {
                    $(this).prop("disabled", false);
                    $(this).children().each(function () {
                        $(this).prop("disabled", false);
                        $(this).children().each(function () {
                            $(this).prop("disabled", false);
                            $(this).children().each(function () {
                                $(this).prop("disabled", false);
                            });
                        });
                    });
                });
            });
        });
        $("ol[id=eventAdvertiseSection]").css("display", "block");

        document.getElementById("advertiseWebsite").style.display = "none";
        document.getElementById("advertiseWebsite").value = "";

        eventWebsite[0].checked = false;
        eventWebsite[1].checked = false;
        eventTelevised[0].checked = false;
        eventTelevised[1].checked = false;
        eventRadio[0].checked = false;
        eventRadio[1].checked = false;
        eventNewsPaper[0].checked = false;
        eventNewsPaper[1].checked = false;
        eventBrochure[0].checked = false;
        eventBrochure[1].checked = false;
        eventHandOut[0].checked = false;
        eventHandOut[1].checked = false;
        eventBillBoard[0].checked = false;
        eventBillBoard[1].checked = false;
        eventPoster[0].checked = false;
        eventPoster[1].checked = false;
        eventOther[0].checked = false;
        eventOther[1].checked = false;
    }
    if (eventAdvertisedSelection[1].checked) {
        $("ol[id=eventAdvertiseSection]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                            $(this).children().each(function () {
                                $(this).prop("disabled", true);
                            });
                        });

                    });
                });
            });
        });
        $("ol[id=eventAdvertiseSection]").css("display", "none");

        document.getElementById("advertiseWebsite").style.display = "none";
        document.getElementById("advertiseWebsite").value = "";

        eventWebsite[0].checked = false;
        eventWebsite[1].checked = false;
        eventTelevised[0].checked = false;
        eventTelevised[1].checked = false;
        eventRadio[0].checked = false;
        eventRadio[1].checked = false;
        eventNewsPaper[0].checked = false;
        eventNewsPaper[1].checked = false;
        eventBrochure[0].checked = false;
        eventBrochure[1].checked = false;
        eventHandOut[0].checked = false;
        eventHandOut[1].checked = false;
        eventBillBoard[0].checked = false;
        eventBillBoard[1].checked = false;
        eventPoster[0].checked = false;
        eventPoster[1].checked = false;
        eventOther[0].checked = false;
        eventOther[1].checked = false;
    }
}

// Enable/Disable advertised main website
function eventMainWebsite() {
    eventWebsiteName = document.getElementsByName("EventWebsite");

    if (eventWebsiteName[0].checked) {
        document.getElementById("advertiseWebsite").style.display = "block";
        document.getElementById("advertiseWebsite").value = "";
    }
    if (eventWebsiteName[1].checked) {
        document.getElementById("advertiseWebsite").style.display = "none";
        document.getElementById("advertiseWebsite").value = "";
    }

}

// Enable/Disable EventInformation AlcoholIsServed
function alcoholServed() {
    alcoholServedSelection = document.getElementsByName("AlcoholServe");

    if (alcoholServedSelection[0].checked) {
        $("ol[id=alcoholServeSection]").children().each(function () {
            $(this).prop("disabled", false);
            $(this).children().each(function () {
                $(this).prop("disabled", false);
                $(this).children().each(function () {
                    $(this).prop("disabled", false);
                    $(this).children().each(function () {
                        $(this).prop("disabled", false);
                        $(this).children().each(function () {
                            $(this).prop("disabled", false);
                        });
                    });
                });
            });
        });
        $("ol[id=alcoholServeSection]").css("display", "block");

        $("li[id=alcoholSoldSection]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
        $("li[id=alcoholSoldSection]").css("display", "none");

        $("li[id=vendorLiquorSellingLiability]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                    });
                });
            });
        });
        $("li[id=vendorLiquorSellingLiability]").css("display", "none");


        document.getElementsByName("AlcoholIsSold")[0].checked = false;
        document.getElementsByName("AlcoholIsSold")[1].checked = false;

        document.getElementsByName("AlcoholFee")[0].checked = false;
        document.getElementsByName("AlcoholFee")[1].checked = false;

        document.getElementsByName("EventFee")[0].checked = false;
        document.getElementsByName("EventFee")[1].checked = false;

        document.getElementsByName("EventDonation")[0].checked = false;
        document.getElementsByName("EventDonation")[1].checked = false;

        $("input[name=AlcoholType1]").checked = false;
        $("input[name=AlcoholType2]").checked = false;
        $("input[name=AlcoholType3]").checked = false;

        document.getElementsByName("AlcoholVending")[0].checked = false;
        document.getElementsByName("AlcoholVending")[1].checked = false;

        document.getElementsByName("AlcoholVendingInsurance")[0].checked = false;
        document.getElementsByName("AlcoholVendingInsurance")[1].checked = false;

        document.getElementById("alcoholEstimatedSales").value = "";

        document.getElementById("howManyDifferentAlcohol").value = "";

        document.getElementsByName("LiquorLicense")[0].checked = false;
        document.getElementsByName("LiquorLicense")[1].checked = false;

        document.getElementsByName("LiquorDrinkArea")[0].checked = false;
        document.getElementsByName("LiquorDrinkArea")[1].checked = false;
        document.getElementsByName("LiquorIdentification")[0].checked = false;
        document.getElementsByName("LiquorIdentification")[1].checked = false;
        document.getElementsByName("DrinkingAge")[0].checked = false;
        document.getElementsByName("DrinkingAge")[1].checked = false;
        document.getElementsByName("LiquorServingLimit")[0].checked = false;
        document.getElementsByName("LiquorServingLimit")[1].checked = false;
        document.getElementsByName("LiquorStaffMonitor")[0].checked = false;
        document.getElementsByName("LiquorStaffMonitor")[1].checked = false;
        document.getElementsByName("LiquorBarClose")[0].checked = false;
        document.getElementsByName("LiquorBarClose")[1].checked = false;

    }
    if (alcoholServedSelection[1].checked) {
        $("ol[id=alcoholServeSection]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
        $("ol[id=alcoholServeSection]").css("display", "none");

        $("li[id=alcoholSoldSection]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                    });
                });
            });
        });
        $("li[id=alcoholSoldSection]").css("display", "none");

        $("li[id=vendorLiquorSellingLiability]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                    });
                });
            });
        });
        $("li[id=vendorLiquorSellingLiability]").css("display", "none");


        document.getElementsByName("AlcoholIsSold")[0].checked = false;
        document.getElementsByName("AlcoholIsSold")[1].checked = false;

        document.getElementsByName("AlcoholFee")[0].checked = false;
        document.getElementsByName("AlcoholFee")[1].checked = false;

        document.getElementsByName("EventFee")[0].checked = false;
        document.getElementsByName("EventFee")[1].checked = false;

        document.getElementsByName("EventDonation")[0].checked = false;
        document.getElementsByName("EventDonation")[1].checked = false;

        $("input[name=AlcoholType1]").checked = false;
        $("input[name=AlcoholType2]").checked = false;
        $("input[name=AlcoholType3]").checked = false;

        document.getElementsByName("AlcoholVending")[0].checked = false;
        document.getElementsByName("AlcoholVending")[1].checked = false;

        document.getElementsByName("AlcoholVendingInsurance")[0].checked = false;
        document.getElementsByName("AlcoholVendingInsurance")[1].checked = false;

        document.getElementById("alcoholEstimatedSales").value = "";

        document.getElementById("howManyDifferentAlcohol").value = "";

        document.getElementsByName("LiquorLicense")[0].checked = false;
        document.getElementsByName("LiquorLicense")[1].checked = false;

        document.getElementsByName("LiquorDrinkArea")[0].checked = false;
        document.getElementsByName("LiquorDrinkArea")[1].checked = false;
        document.getElementsByName("LiquorIdentification")[0].checked = false;
        document.getElementsByName("LiquorIdentification")[1].checked = false;
        document.getElementsByName("DrinkingAge")[0].checked = false;
        document.getElementsByName("DrinkingAge")[1].checked = false;
        document.getElementsByName("LiquorServingLimit")[0].checked = false;
        document.getElementsByName("LiquorServingLimit")[1].checked = false;
        document.getElementsByName("LiquorStaffMonitor")[0].checked = false;
        document.getElementsByName("LiquorStaffMonitor")[1].checked = false;
        document.getElementsByName("LiquorBarClose")[0].checked = false;
        document.getElementsByName("LiquorBarClose")[1].checked = false;

    }

}

// Enable/Disable EventInformation AlcoholIsSold
function alcoholSold() {
    alcoholSoldSelection = document.getElementsByName("AlcoholIsSold");

    if (alcoholSoldSelection[0].checked) {
        $("li[id=alcoholSoldSection]").children().each(function () {
            $(this).prop("disabled", false);
            $(this).children().each(function () {
                $(this).prop("disabled", false);
                $(this).children().each(function () {
                    $(this).prop("disabled", false);
                    $(this).children().each(function () {
                        $(this).prop("disabled", false);
                        $(this).children().each(function () {
                            $(this).prop("disabled", false);
                        });
                    });
                });
            });
        });
        $("li[id=alcoholSoldSection]").css("display", "block");


        alcoholFee = document.getElementsByName("AlcoholFee")[0].checked = false;
        alcoholFee = document.getElementsByName("AlcoholFee")[1].checked = false;
        document.getElementsByName("EventFee")[0].checked = false;
        document.getElementsByName("EventFee")[1].checked = false;
        document.getElementsByName("EventDonation")[0].checked = false;
        document.getElementsByName("EventDonation")[1].checked = false;

    }
    if (alcoholSoldSelection[1].checked) {
        $("li[id=alcoholSoldSection]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
        $("li[id=alcoholSoldSection]").css("display", "none");


        alcoholFee = document.getElementsByName("AlcoholFee")[0].checked = false;
        alcoholFee = document.getElementsByName("AlcoholFee")[1].checked = false;
        document.getElementsByName("EventFee")[0].checked = false;
        document.getElementsByName("EventFee")[1].checked = false;
        document.getElementsByName("EventDonation")[0].checked = false;
        document.getElementsByName("EventDonation")[1].checked = false;
    }

}

// Enable/Disable EventInformation VendorLiquorLiability
function vendorServeOrSellLiquor() {
    vendorSellAlcohol = document.getElementsByName("AlcoholVending");

    if (vendorSellAlcohol[0].checked) {
        $("li[id=vendorLiquorSellingLiability]").children().each(function () {
            $(this).prop("disabled", false);
            $(this).children().each(function () {
                $(this).prop("disabled", false);
                $(this).children().each(function () {
                    $(this).prop("disabled", false);
                    $(this).children().each(function () {
                        $(this).prop("disabled", false);
                        $(this).children().each(function () {
                            $(this).prop("disabled", false);
                        });
                    });
                });
            });
        });
        $("li[id=vendorLiquorSellingLiability]").css("display", "block");


        document.getElementsByName("AlcoholVendingInsurance")[0].checked = false;
        document.getElementsByName("AlcoholVendingInsurance")[1].checked = false;
    }
    if (vendorSellAlcohol[1].checked) {
        $("li[id=vendorLiquorSellingLiability]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
        $("li[id=vendorLiquorSellingLiability]").css("display", "none");


        document.getElementsByName("AlcoholVendingInsurance")[0].checked = false;
        document.getElementsByName("AlcoholVendingInsurance")[1].checked = false;
    }

}

// Enable/Disable EventInformation AthleticOrRecreationalActivities
function athleticOrRecreationalActivity() {
    athleticRecreationalActivity = document.getElementsByName("AthleticRecreationalActivity");
    activityTable = document.getElementById("ActivityTable");

    if (athleticRecreationalActivity[0].checked) {
        $("ol[id=athleticRecreationActivitySection]").children().each(function () {
            $(this).prop("disabled", false);
            $(this).children().each(function () {
                $(this).prop("disabled", false);
                $(this).children().each(function () {
                    $(this).prop("disabled", false);
                    $(this).children().each(function () {
                        $(this).prop("disabled", false);
                        $(this).children().each(function () {
                            $(this).prop("disabled", false);
                        });
                    });
                });
            });
        });
        $("ol[id=athleticRecreationActivitySection]").css("display", "block");


        for (var i = activityTable.rows.length - 1; i > 0; i--) {
            activityTable.deleteRow(i);
        }
        addActivityTableRow();
        document.getElementById("procedureExplaination").value = "";
        document.getElementById("liabilityReleaseFile").value = "";
        document.getElementById("liabilityReleaseFileLabel").innerHTML = "";

    }
    if (athleticRecreationalActivity[1].checked) {
        $("ol[id=athleticRecreationActivitySection]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
        $("ol[id=athleticRecreationActivitySection]").css("display", "none");


        for (var i = activityTable.rows.length - 1; i > 0; i--) {
            activityTable.deleteRow(i);
        }
        //addActivityTableRow();
        document.getElementById("procedureExplaination").value = "";
        document.getElementById("liabilityReleaseFile").value = "";
        document.getElementById("liabilityReleaseFileLabel").innerHTML = "";

    }

}

// Enable/Disable EventInformation HavingMusic
function haveMusic() {
    hasMusic = document.getElementsByName("HaveMusic");

    if (hasMusic[0].checked) {

        $("ol[id=musicSection]").children().each(function () {
            $(this).prop("disabled", false);
            $(this).children().each(function () {
                $(this).prop("disabled", false);
                $(this).children().each(function () {
                    $(this).prop("disabled", false);
                    $(this).children().each(function () {
                        $(this).prop("disabled", false);
                        $(this).children().each(function () {
                            $(this).prop("disabled", false);
                        });
                    });
                });
            });
        });
        $("ol[id=musicSection]").css("display", "block");

        $("li[id=arrangementsMade]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
        $("li[id=arrangementsMade]").css("display", "none");

        $("li[id=otherTypeOfEntertainment]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
        $("li[id=otherTypeOfEntertainment]").css("display", "none");


        //Checkbox
        document.getElementById("typeOfMusic1").checked = false;
        document.getElementById("typeOfMusic2").checked = false;
        document.getElementById("typeOfMusic3").checked = false;

        //Radio
        document.getElementsByName("AmplifiedMusic")[0].checked = false;
        document.getElementsByName("AmplifiedMusic")[1].checked = false;

        //Int
        document.getElementById("howManyBands").value = "";

        //Table
        for (var i = document.getElementById("MusicTable").rows.length - 1; i > 0; i--) {
            document.getElementById("MusicTable").deleteRow(i);
        }
        addMusicTableRow();

        //Checkbox MusicTypes
        $("#musicTypeCheckBox1").prop('checked', false);
        $("#musicTypeCheckBox2").prop('checked', false);
        $("#musicTypeCheckBox3").prop('checked', false);
        $("#musicTypeCheckBox4").prop('checked', false);
        $("#musicTypeCheckBox5").prop('checked', false);
        $("#musicTypeCheckBox6").prop('checked', false);
        $("#musicTypeCheckBox7").prop('checked', false);
        $("#musicTypeCheckBox8").prop('checked', false);
        $("#musicTypeCheckBox9").prop('checked', false);
        $("#musicTypeCheckBox10").prop('checked', false);
        $("#musicTypeCheckBox11").prop('checked', false);
        $("#musicTypeCheckBox12").prop('checked', false);
        $("#musicTypeCheckBox13").prop('checked', false);
        $("#musicTypeCheckBox14").prop('checked', false);
        $("#musicTypeCheckBox15").prop('checked', false);
        $("#musicTypeCheckBox16").prop('checked', false);
        $("#musicTypeCheckBox17").prop('checked', false);
        $("#musicTypeCheckBox18").prop('checked', false);
        $("#musicTypeCheckBox19").prop('checked', false);
        $("#musicTypeCheckBox20").prop('checked', false);
        $("#musicTypeCheckBox21").prop('checked', false);
        $("#musicTypeCheckBox22").prop('checked', false);
        $("#musicTypeCheckBox23").prop('checked', false);
        $("#musicTypeCheckBox24").prop('checked', false);
        $("#musicTypeCheckBox25").prop('checked', false);
        $("#musicTypeCheckBox26").prop('checked', false);
        $("#musicTypeCheckBox27").prop('checked', false);
        $("#musicTypeCheckBox28").prop('checked', false);
        $("#musicTypeCheckBox29").prop('checked', false);
        $("#musicTypeCheckBox30").prop('checked', false);
        $("#musicTypeCheckBox31").prop('checked', false);
        $("#musicTypeCheckBox32").prop('checked', false);
        $("#musicTypeCheckBox33").prop('checked', false);
        $("#musicTypeCheckBox34").prop('checked', false);
        $("#musicTypeCheckBox35").prop('checked', false);
        $("#musicTypeCheckBox36").prop('checked', false);
        $("#musicTypeCheckBox37").prop('checked', false);
        $("#musicTypeCheckBox38").prop('checked', false);

        document.getElementById("musicOtherType").value = "";

        // radiogroup OwnElectricity
        document.getElementsByName("OwnElectricity")[0].checked = false;
        document.getElementsByName("OwnElectricity")[1].checked = false;
        document.getElementById("arrangementsMade").style.display = "none";
        document.getElementById("electricityArrangement").value = "";

        // radiogroup OtherTypeOfEntertainment
        document.getElementsByName("OtherEntertainment")[0].checked = false;
        document.getElementsByName("OtherEntertainment")[1].checked = false;
        document.getElementById("otherTypeOfEntertainment").style.display = "none";
        document.getElementById("otherEntertainmentDescription").value = "";

        // otherMusicType Textbox
        document.getElementById("musicOtherType").style.display = "none";
        $("#musicOtherType").prop("disabled", true);
    }
    if (hasMusic[1].checked) {

        $("ol[id=musicSection]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
        $("ol[id=musicSection]").css("display", "none");

        $("li[id=arrangementsMade]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
        $("ol[id=arrangementsMade]").css("display", "none");

        $("li[id=otherTypeOfEntertainment]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
        $("ol[id=otherTypeOfEntertainment]").css("display", "none");


        //Checkbox
        document.getElementById("typeOfMusic1").checked = false;
        document.getElementById("typeOfMusic2").checked = false;
        document.getElementById("typeOfMusic3").checked = false;

        //Radio
        document.getElementsByName("AmplifiedMusic")[0].checked = false;
        document.getElementsByName("AmplifiedMusic")[1].checked = false;

        //Int
        document.getElementById("howManyBands").value = "";

        //Table
        for (var i = document.getElementById("MusicTable").rows.length - 1; i > 0; i--) {
            document.getElementById("MusicTable").deleteRow(i);
        }

        //Checkbox MusicTypes
        $("#musicTypeCheckBox1").prop('checked', false);
        $("#musicTypeCheckBox2").prop('checked', false);
        $("#musicTypeCheckBox3").prop('checked', false);
        $("#musicTypeCheckBox4").prop('checked', false);
        $("#musicTypeCheckBox5").prop('checked', false);
        $("#musicTypeCheckBox6").prop('checked', false);
        $("#musicTypeCheckBox7").prop('checked', false);
        $("#musicTypeCheckBox8").prop('checked', false);
        $("#musicTypeCheckBox9").prop('checked', false);
        $("#musicTypeCheckBox10").prop('checked', false);
        $("#musicTypeCheckBox11").prop('checked', false);
        $("#musicTypeCheckBox12").prop('checked', false);
        $("#musicTypeCheckBox13").prop('checked', false);
        $("#musicTypeCheckBox14").prop('checked', false);
        $("#musicTypeCheckBox15").prop('checked', false);
        $("#musicTypeCheckBox16").prop('checked', false);
        $("#musicTypeCheckBox17").prop('checked', false);
        $("#musicTypeCheckBox18").prop('checked', false);
        $("#musicTypeCheckBox19").prop('checked', false);
        $("#musicTypeCheckBox20").prop('checked', false);
        $("#musicTypeCheckBox21").prop('checked', false);
        $("#musicTypeCheckBox22").prop('checked', false);
        $("#musicTypeCheckBox23").prop('checked', false);
        $("#musicTypeCheckBox24").prop('checked', false);
        $("#musicTypeCheckBox25").prop('checked', false);
        $("#musicTypeCheckBox26").prop('checked', false);
        $("#musicTypeCheckBox27").prop('checked', false);
        $("#musicTypeCheckBox28").prop('checked', false);
        $("#musicTypeCheckBox29").prop('checked', false);
        $("#musicTypeCheckBox30").prop('checked', false);
        $("#musicTypeCheckBox31").prop('checked', false);
        $("#musicTypeCheckBox32").prop('checked', false);
        $("#musicTypeCheckBox33").prop('checked', false);
        $("#musicTypeCheckBox34").prop('checked', false);
        $("#musicTypeCheckBox35").prop('checked', false);
        $("#musicTypeCheckBox36").prop('checked', false);
        $("#musicTypeCheckBox37").prop('checked', false);
        $("#musicTypeCheckBox38").prop('checked', false);

        document.getElementById("musicOtherType").value = "";

        // radiogroup OwnElectricity
        document.getElementsByName("OwnElectricity")[0].checked = false;
        document.getElementsByName("OwnElectricity")[1].checked = false;
        document.getElementById("arrangementsMade").style.display = "none";
        document.getElementById("electricityArrangement").value = "";

        // radiogroup OtherTypeOfEntertainment
        document.getElementsByName("OtherEntertainment")[0].checked = false;
        document.getElementsByName("OtherEntertainment")[1].checked = false;
        document.getElementById("otherTypeOfEntertainment").style.display = "none";
        document.getElementById("otherEntertainmentDescription").value = "";

        // otherMusicType Textbox
        document.getElementById("musicOtherType").style.display = "none";
        $("#musicOtherType").prop("disabled", true);
    }

}

// Enable/Disable EventInformation OtheMusicType
function otherMusicTypeDiscriptionFunction() {
    var checkBox = document.getElementById("musicTypeCheckBox38");
    var text = document.getElementById("NameInsuredOtherInputText");
    if (checkBox.checked == true) {
        document.getElementById("musicOtherType").disabled = false;
        document.getElementById("musicOtherType").style.display = "block";
        document.getElementById("musicOtherType").value = "";

    } else {
        document.getElementById("musicOtherType").disabled = true;
        document.getElementById("musicOtherType").value = "";
        document.getElementById("musicOtherType").style.display = "none";
    }
}

// Enable/Disable EventInformation OwnElectricity
function haveOwnElectricity() {
    ownElectricitySelection = document.getElementsByName("OwnElectricity");

    if (ownElectricitySelection[0].checked) {
        $("li[id=arrangementsMade]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
        $("li[id=arrangementsMade]").css("display", "none");

        document.getElementById("electricityArrangement").value = "";
    }
    if (ownElectricitySelection[1].checked) {
        $("li[id=arrangementsMade]").children().each(function () {
            $(this).prop("disabled", false);
            $(this).children().each(function () {
                $(this).prop("disabled", false);
                $(this).children().each(function () {
                    $(this).prop("disabled", false);
                    $(this).children().each(function () {
                        $(this).prop("disabled", false);
                        $(this).children().each(function () {
                            $(this).prop("disabled", false);
                        });
                    });
                });
            });
        });
        $("li[id=arrangementsMade]").css("display", "block");

        document.getElementById("electricityArrangement").value = "";


    }

}

// Enable/Disable EventInformation OtherEntertainment
function typeOfOtherEntertainment() {
    otherEntertainmentSelection = document.getElementsByName("OtherEntertainment");

    if (otherEntertainmentSelection[0].checked) {
        $("li[id=otherTypeOfEntertainment]").children().each(function () {
            $(this).prop("disabled", false);
            $(this).children().each(function () {
                $(this).prop("disabled", false);
                $(this).children().each(function () {
                    $(this).prop("disabled", false);
                    $(this).children().each(function () {
                        $(this).prop("disabled", false);
                        $(this).children().each(function () {
                            $(this).prop("disabled", false);
                        });
                    });
                });
            });
        });
        $("li[id=otherTypeOfEntertainment]").css("display", "block");

        document.getElementById("otherEntertainmentDescription").value = "";
    }

    if (otherEntertainmentSelection[1].checked) {
        $("li[id=otherTypeOfEntertainment]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
        $("li[id=otherTypeOfEntertainment]").css("display", "none");

        document.getElementById("otherEntertainmentDescription").value = "";
    }
}

// Enable/Disable EventInformation OtherActivities 
function activitiesAndOthers() {
    activitiesStuffSelection = document.getElementsByName("ActivityStuff");

    if (activitiesStuffSelection[0].checked) {
        $("ol[id=activitiesSection]").children().each(function () {
            $(this).prop("disabled", false);
            $(this).children().each(function () {
                $(this).prop("disabled", false);
                $(this).children().each(function () {
                    $(this).prop("disabled", false);
                    $(this).children().each(function () {
                        $(this).prop("disabled", false);
                        $(this).children().each(function () {
                            $(this).prop("disabled", false);
                            $(this).children().each(function () {
                                $(this).prop("disabled", false);
                            });
                        });
                    });
                });
            });
        });
        $("ol[id=activitiesSection]").css("display", "block");


        document.getElementById("explainForWaivers").value = "";

        document.getElementById("followingActivitesFile").value = "";
        document.getElementById("followingActivitesFileLabel").innerHTML = "";
        document.getElementById("hiredCompany").value = "";

        document.getElementsByName("ClimbWall")[0].checked = false;
        document.getElementsByName("ClimbWall")[1].checked = false;
        document.getElementsByName("SkateBoard")[0].checked = false;
        document.getElementsByName("SkateBoard")[1].checked = false;
        document.getElementsByName("RollerAct")[0].checked = false;
        document.getElementsByName("RollerAct")[1].checked = false;
        document.getElementsByName("CycleAct")[0].checked = false;
        document.getElementsByName("CycleAct")[1].checked = false;
        document.getElementsByName("WaterAct")[0].checked = false;
        document.getElementsByName("WaterAct")[1].checked = false;
        document.getElementsByName("GunAct")[0].checked = false;
        document.getElementsByName("GunAct")[1].checked = false;
        document.getElementsByName("FireAct")[0].checked = false;
        document.getElementsByName("FireAct")[1].checked = false;
        document.getElementsByName("ArmoryAct")[0].checked = false;
        document.getElementsByName("ArmoryAct")[1].checked = false;
        document.getElementsByName("ChemicalAct")[0].checked = false;
        document.getElementsByName("ChemicalAct")[1].checked = false;
        document.getElementsByName("MedicalAct")[0].checked = false;
        document.getElementsByName("MedicalAct")[1].checked = false;
        document.getElementsByName("DemolitionAct")[0].checked = false;
        document.getElementsByName("DemolitionAct")[1].checked = false;
        document.getElementsByName("ScaffoldingfAct")[0].checked = false;
        document.getElementsByName("ScaffoldingfAct")[1].checked = false;
    }
    if (activitiesStuffSelection[1].checked) {
        $("ol[id=activitiesSection]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                            $(this).children().each(function () {
                                $(this).prop("disabled", true);
                            });
                        });
                    });
                });
            });
        });
        $("ol[id=activitiesSection]").css("display", "none");


        document.getElementById("explainForWaivers").value = "";

        document.getElementById("followingActivitesFile").value = "";
        document.getElementById("followingActivitesFileLabel").innerHTML = "";
        document.getElementById("hiredCompany").value = "";

        document.getElementsByName("ClimbWall")[0].checked = false;
        document.getElementsByName("ClimbWall")[1].checked = false;
        document.getElementsByName("SkateBoard")[0].checked = false;
        document.getElementsByName("SkateBoard")[1].checked = false;
        document.getElementsByName("RollerAct")[0].checked = false;
        document.getElementsByName("RollerAct")[1].checked = false;
        document.getElementsByName("CycleAct")[0].checked = false;
        document.getElementsByName("CycleAct")[1].checked = false;
        document.getElementsByName("WaterAct")[0].checked = false;
        document.getElementsByName("WaterAct")[1].checked = false;
        document.getElementsByName("GunAct")[0].checked = false;
        document.getElementsByName("GunAct")[1].checked = false;
        document.getElementsByName("FireAct")[0].checked = false;
        document.getElementsByName("FireAct")[1].checked = false;
        document.getElementsByName("ArmoryAct")[0].checked = false;
        document.getElementsByName("ArmoryAct")[1].checked = false;
        document.getElementsByName("ChemicalAct")[0].checked = false;
        document.getElementsByName("ChemicalAct")[1].checked = false;
        document.getElementsByName("MedicalAct")[0].checked = false;
        document.getElementsByName("MedicalAct")[1].checked = false;
        document.getElementsByName("DemolitionAct")[0].checked = false;
        document.getElementsByName("DemolitionAct")[1].checked = false;
        document.getElementsByName("ScaffoldingfAct")[0].checked = false;
        document.getElementsByName("ScaffoldingfAct")[1].checked = false;
    }

}

// Enable/Disable EventLoaction PastEvents
function pastEvents() {
    pastEventHeld = document.getElementsByName("HeldBefore");

    similarPastEventTable = document.getElementById("SimilarPastEventTable");

    if (pastEventHeld[0].checked) {
        $("ol[id=previousSimilarEvents]").children().each(function () {
            $(this).prop("disabled", false);
            $(this).children().each(function () {
                $(this).prop("disabled", false);
                $(this).children().each(function () {
                    $(this).prop("disabled", false);
                    $(this).children().each(function () {
                        $(this).prop("disabled", false);
                        $(this).children().each(function () {
                            $(this).prop("disabled", false);
                        });
                    });
                });
            });
        });
        $("ol[id=previousSimilarEvents]").css("display", "inline-block");

        for (var i = similarPastEventTable.rows.length - 1; i > 0; i--) {
            similarPastEventTable.deleteRow(i);
        }
        AddSimilarPastEventTableRow();
    }
    if (pastEventHeld[1].checked) {
        $("ol[id=previousSimilarEvents]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
        $("ol[id=previousSimilarEvents]").css("display", "none");

        for (var i = similarPastEventTable.rows.length - 1; i > 0; i--) {
            similarPastEventTable.deleteRow(i);
        }
        //AddSimilarPastEventTableRow();
    }
}

// Enable/Disable EventLoaction EmergencyEvacuationPlan
function emergencyEvacuationPlan() {

    evacPlan = document.getElementsByName("EvacuationPlan");

    if (evacPlan[0].checked) {
        $("ol[id=emergencyEvacuationExplaination]").children().each(function () {
            $(this).prop("disabled", false);
            $(this).children().each(function () {
                $(this).prop("disabled", false);
                $(this).children().each(function () {
                    $(this).prop("disabled", false);
                    $(this).children().each(function () {
                        $(this).prop("disabled", false);
                        $(this).children().each(function () {
                            $(this).prop("disabled", false);
                        });
                    });
                });
            });
        });
        $("ol[id=emergencyEvacuationExplaination]").css("display", "block");


        document.getElementById("howAttendeesNotifiedEvacuation").value = "";
    }
    if (evacPlan[1].checked) {
        $("ol[id=emergencyEvacuationExplaination]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
        $("ol[id=emergencyEvacuationExplaination]").css("display", "none");


        document.getElementById("howAttendeesNotifiedEvacuation").value = "";
    }
}

// Enable/Disable EventLoaction MedicalPresentAtEvent
function medicalServicePresent() {
    medicalPresence = document.getElementsByName("IsThereMedicalPresence");

    if (medicalPresence[0].checked) {
        $("ol[id=medicalPresent]").children().each(function () {
            $(this).prop("disabled", false);
            $(this).children().each(function () {
                $(this).prop("disabled", false);
                $(this).children().each(function () {
                    $(this).prop("disabled", false);
                    $(this).children().each(function () {
                        $(this).prop("disabled", false);
                        $(this).children().each(function () {
                            $(this).prop("disabled", false);
                            $(this).children().each(function () {
                                $(this).prop("disabled", false);
                            });
                        });
                    });
                });
            });
        });
        $("ol[id=medicalPresent]").css("display", "block");

        $("#MedicTable").css("display", "table-row");

        document.getElementById("numberOfDoctors").value = "";
        document.getElementById("numberOfParamedics").value = "";
        document.getElementById("numberOfNurses").value = "";
        document.getElementById("numberOfEMT/EMS").value = "";
        document.getElementById("numberOfOther").value = "";

        document.getElementsByName("AmbulanceOnSite")[0].checked = false;
        document.getElementsByName("AmbulanceOnSite")[1].checked = false;

    }
    if (medicalPresence[1].checked) {
        $("ol[id=medicalPresent]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                            $(this).children().each(function () {
                                $(this).prop("disabled", true);
                            });
                        });
                    });
                });
            });
        });
        $("ol[id=medicalPresent]").css("display", "none");

        $("#MedicTable").css("display", "table-row");

        document.getElementById("numberOfDoctors").value = "";
        document.getElementById("numberOfParamedics").value = "";
        document.getElementById("numberOfNurses").value = "";
        document.getElementById("numberOfEMT/EMS").value = "";
        document.getElementById("numberOfOther").value = "";

        document.getElementsByName("AmbulanceOnSite")[0].checked = false;
        document.getElementsByName("AmbulanceOnSite")[1].checked = false;
    }
}

// Enable/Disable EventLoaction StreetClosure
function streetClosureNeed() {
    streetClosing = document.getElementsByName("StreetClosure");
    trafficMitigating = document.getElementsByName("TrafficMitigation");

    streetClosureTable = document.getElementById("StreetClosureTable");

    if (streetClosing[0].checked) {

        $("ol[id=streetClosures]").children().each(function () {
            $(this).prop("disabled", false);
            $(this).children().each(function () {
                $(this).prop("disabled", false);
                $(this).children().each(function () {
                    $(this).prop("disabled", false);
                    $(this).children().each(function () {
                        $(this).prop("disabled", false);
                        $(this).children().each(function () {
                            $(this).prop("disabled", false);
                        });
                    });
                });
            });
        });
        $("ol[id=streetClosures]").css("display", "block");

        $("div[id=trafficMitigationOptions]").children().each(function () {
            $(this).css("display", "none");
        });
        $("div[id=trafficMitigationOptions]").css("display", "none");


        for (var i = streetClosureTable.rows.length - 1; i > 0; i--) {
            streetClosureTable.deleteRow(i);
        }
        AddStreetClosureTableRow();

        document.getElementsByName("TrafficMitigation")[0].checked = false;
        document.getElementsByName("TrafficMitigation")[1].checked = false;

        document.getElementById("trafficMitigationDescription").value = "";
        document.getElementById("30DaysPriorInsure").value = "";
    }
    if (streetClosing[1].checked) {

        $("ol[id=streetClosures]").children().each(function () {
            $(this).prop("disabled", true);
            $(this).children().each(function () {
                $(this).prop("disabled", true);
                $(this).children().each(function () {
                    $(this).prop("disabled", true);
                    $(this).children().each(function () {
                        $(this).prop("disabled", true);
                        $(this).children().each(function () {
                            $(this).prop("disabled", true);
                        });
                    });
                });
            });
        });
        $("ol[id=streetClosures]").css("display", "none");

        $("div[id=trafficMitigationOptions]").children().each(function () {
            $(this).css("display", "none");
        });
        $("div[id=trafficMitigationOptions]").css("display", "none");



        for (var i = streetClosureTable.rows.length - 1; i > 0; i--) {
            streetClosureTable.deleteRow(i);
        }

        document.getElementsByName("TrafficMitigation")[0].checked = false;
        document.getElementsByName("TrafficMitigation")[1].checked = false;

        document.getElementById("trafficMitigationDescription").value = "";
        document.getElementById("30DaysPriorInsure").value = "";
    }

}

// Enable/Disable EventLocation TrafficMitigation
function trafficMitigations() {
    trafficMitigating = document.getElementsByName("TrafficMitigation");

    if (trafficMitigating[0].checked) {
        $("div[id=trafficMitigationOptions]").children().each(function () {
            $(this).prop("disabled", false);
        });

        $("div[id=trafficMitigationOptions]").children().each(function () {
            $(this).css("display", "block");
            $(this).children().each(function () {
                $(this).css("display", "block");
                $(this).children().each(function () {
                    $(this).css("display", "block");
                    $(this).children().each(function () {
                    });
                });
            });
        });
        $("div[id=trafficMitigationOptions]").css("display", "block");

        document.getElementById("trafficMitigationDescription").value = "";
    }
    if (trafficMitigating[1].checked) {
        $("div[id=trafficMitigationOptions]").children().each(function () {
            $(this).prop("disabled", true);
        });


        $("div[id=trafficMitigationOptions]").children().each(function () {
            $(this).css("display", "none");
            $(this).children().each(function () {
                $(this).css("display", "none");
                $(this).children().each(function () {
                    $(this).css("display", "none");
                    $(this).children().each(function () {
                    });
                });
            });
        });
        $("div[id=trafficMitigationOptions]").css("display", "none");

        document.getElementById("trafficMitigationDescription").value = "";
    }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// pageToPage functions
function nextPage() {

    var page1 = document.getElementById("form1");
    var page2 = document.getElementById("form2");
    var page3 = document.getElementById("form3");
    var page4 = document.getElementById("form4");
    var page5 = document.getElementById("form5");


    if (page1.style.display == "block") {
        page1.style.display = "none";
        page2.style.display = "block";
        page3.style.display = "none";
        page4.style.display = "none";
        page5.style.display = "none";
    }

    else if (page2.style.display == "block") {
        page1.style.display = "none";
        page2.style.display = "none";
        page3.style.display = "block";
        page4.style.display = "none";
        page5.style.display = "none";
    }

    else if (page3.style.display == "block") {
        page1.style.display = "none";
        page2.style.display = "none";
        page3.style.display = "none";
        page4.style.display = "block";
        page5.style.display = "none";
    }

    else if (page4.style.display == "block") {
        page1.style.display = "none";
        page2.style.display = "none";
        page3.style.display = "none";
        page4.style.display = "none";
        page5.style.display = "block";
    }

}

function previousPage() {
    var page1 = document.getElementById("form1");
    var page2 = document.getElementById("form2");
    var page3 = document.getElementById("form3");
    var page4 = document.getElementById("form4");
    var page5 = document.getElementById("form5");

    if (page2.style.display == "block") {
        page1.style.display = "block";
        page2.style.display = "none";
        page3.style.display = "none";
        page4.style.display = "none";
        page5.style.display = "none";
    }

    else if (page3.style.display == "block") {
        page1.style.display = "none";
        page2.style.display = "block";
        page3.style.display = "none";
        page4.style.display = "none";
        page5.style.display = "none";
    }

    else if (page4.style.display == "block") {
        page1.style.display = "none";
        page2.style.display = "none";
        page3.style.display = "block";
        page4.style.display = "none";
        page5.style.display = "none";
    }

    else if (page5.style.display == "block") {
        page1.style.display = "none";
        page2.style.display = "none";
        page3.style.display = "none";
        page4.style.display = "block";
        page5.style.display = "none";
    }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// validaton
function returnToday() {
    var today = new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    var yyyy = today.getFullYear();

    var todayDate = mm + "/" + dd + "/" + yyyy;

    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var currentTime = time;

    return today;
}

$(Document).ready(function () {
    $("#saveAndExitButton").click(function () {
        var invalidity = "false";
        $("input").each(function () {
            if ($(this).is(":invalid")) {
                invalidity = "true";
            }
        });
        if (invalidity == "true") {
            alert("Check if there are any red highlighted red boxes in any of the sections and check the Important Notice agreement is checked.");
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// functions for currency validation
$(Document).ready(function () {
    $("form").click(function () {
        $("input[data-type='currency']").on({
            keyup: function () {
                formatCurrency($(this));
                $(this).attr("pattern", "^\\$\\d{1,3}(,\\d{3})*(\\.\\d+)?$");
            },
            blur: function () {
                formatCurrency($(this), "blur");
            }
        });
    });
});

function formatNumber(n) {
    // format number 1000000 to 1,234,567
    return n.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")
}

function formatCurrency(input, blur) {
    // appends $ to value, validates decimal side
    // and puts cursor back in right position.

    // get input value
    var input_val = input.val();

    // don't validate empty input
    if (input_val === "") { return; }

    // original length
    var original_len = input_val.length;

    // initial caret position 
    var caret_pos = input.prop("selectionStart");

    // check for decimal
    if (input_val.indexOf(".") >= 0) {

        // get position of first decimal
        // this prevents multiple decimals from
        // being entered
        var decimal_pos = input_val.indexOf(".");

        // split number by decimal point
        var left_side = input_val.substring(0, decimal_pos);
        var right_side = input_val.substring(decimal_pos);

        // add commas to left side of number
        left_side = formatNumber(left_side);

        // validate right side
        right_side = formatNumber(right_side);

        // On blur make sure 2 numbers after decimal
        if (blur === "blur") {
            right_side += "00";
        }

        // Limit decimal to only 2 digits
        right_side = right_side.substring(0, 2);

        // join number by .
        input_val = "$" + left_side + "." + right_side;

    } else {
        // no decimal entered
        // add commas to number
        // remove all non-digits
        input_val = formatNumber(input_val);
        input_val = "$" + input_val;

        // final formatting
        if (blur === "blur") {
            input_val += ".00";
        }
    }

    // send updated string to input
    input.val(input_val);

    // put caret back in the right position
    var updated_len = input_val.length;
    caret_pos = updated_len - original_len + caret_pos;
    input[0].setSelectionRange(caret_pos, caret_pos);
}
