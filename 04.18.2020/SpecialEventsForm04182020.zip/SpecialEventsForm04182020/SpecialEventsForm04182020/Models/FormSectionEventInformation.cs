﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventsForm04182020.Models
{
    public class FormSectionEventInformation
    {
        // Event Information Form Variables
        public string EventName { get; set; }
        public string eventDateFile { get; set; }
        public string ActivitiesDescription { get; set; }
        public string activitiesDescriptionFile { get; set; }

        // insured name or company
        public string InsuredIsOwner { get; set; }
        public string InsuredIsManager { get; set; }
        public string InsuredIsThirdParty { get; set; }
        public string EventIsPrivacy { get; set; }

        // admission and ticket
        public string AdmissionCharge { get; set; }
        public decimal AdmissionCost { get; set; }
        public string SellTicket { get; set; }
        public int SellHowManyTickets { get; set; }
        public decimal TotalTicketSalesAmount { get; set; }
        public decimal PricePerTicket { get; set; }
        public string HowToSellTicket { get; set; }
        public string WhoSellTickets { get; set; }
        public string RecieveDonate { get; set; }

        // type of seating
        public string SeatType1 { get; set; }
        public string SeatType2 { get; set; }
        public string SeatType3 { get; set; }
        public string SeatType4 { get; set; }
        public string SeatType5 { get; set; }

        // security
        public int NumOfPrivateSecurityPersons { get; set; }
        public int NumOfPoliceOrSheriffPersons { get; set; }
        public int NumOfPeerGroupOrUshersPersons { get; set; }
        public int NumOfEmployeesPersons { get; set; }
        public int NumOfParentChaperonsPersons { get; set; }
        public int NumOfVolunteersPersons { get; set; }

        // safety and insurance
        public string Armed { get; set; }
        public string BagCheck { get; set; }
        public string FirstAid { get; set; }
        public string CompanyForFirstAide { get; set; }
        public string RecievedInsurance { get; set; }

        // parking
        public string EntranceExit { get; set; }
        public string AccessibleParking { get; set; }

        // event
        public string EventAdvertise { get; set; }
        public string EventIsOnWebsite { get; set; }
        public string EventWebsite { get; set; }
        public string EventTelevised { get; set; }
        public string EventRadio { get; set; }
        public string EventNewsPaper { get; set; }
        public string EventBrochure { get; set; }
        public string EventHandOut { get; set; }
        public string EventBillBoard { get; set; }
        public string EventPoster { get; set; }
        public string EventOther { get; set; }

        // alcohol information
        public string AlcoholServe { get; set; }
        public string AlcoholIsSold { get; set; }
        public string AlcoholFee { get; set; }

        // event finance
        public string EventFee { get; set; }
        public string EventDonation { get; set; }

        // alcohol type
        public string AlcoholType1 { get; set; }
        public string AlcoholType2 { get; set; }
        public string AlcoholType3 { get; set; }

        // alcohol vending
        public string AlcoholVending { get; set; }
        public string AlcoholVendingInsurance { get; set; }
        public decimal EstimatedAlcoholSales { get; set; }
        public int NumOfAlcoholLocations { get; set; }
        public string LiquorLicense { get; set; }
        public string LiquorDrinkArea { get; set; }
        public string LiquorIdentification { get; set; }
        public string DrinkingAge { get; set; }
        public string LiquorServingLimit { get; set; }
        public string LiquorStaffMonitor { get; set; }
        public string LiquorBarClose { get; set; }

        // activity and liability
        public string AthleticRecreationalActivity { get; set; }
        public string WaiverAndLiabilityProcedure { get; set; }
        public string liabilityReleaseFile { get; set; }

        //  music
        public string HaveMusic { get; set; }
        public string TypeOfMusic1 { get; set; } //Under Testing
        public string TypeOfMusic2 { get; set; } //Under Testing
        public string TypeOfMusic3 { get; set; } //Under Testing
        public string AmplifiedMusic { get; set; }
        public int NumOfBandsOrArtists { get; set; }

        // power and electricity
        public string OwnElectricity { get; set; }
        public string ElectricityArranging { get; set; }

        // entertainment
        public string OtherEntertainment { get; set; }
        public string OtherEntertainmentDescription { get; set; }

        // activities options
        public string ActivityStuff { get; set; }
        public string HiredCompanyForActivities { get; set; }
        public string followingActivitiesFile { get; set; }
        public string ExplainProcedureForWaivers { get; set; }
    }
}
