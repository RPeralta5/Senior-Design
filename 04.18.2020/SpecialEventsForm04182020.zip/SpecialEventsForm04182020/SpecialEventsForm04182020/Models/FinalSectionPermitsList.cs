﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventsForm04182020.Models
{
    public class FinalSectionPermitsList
    {
        public FinalSectionPermit SecurityDepositOrFee = new FinalSectionPermit("Security Deposit/Fee");
        public FinalSectionPermit BusinessLicense = new FinalSectionPermit("Business License");
        public FinalSectionPermit DancePermitRequired = new FinalSectionPermit("Dance Permit Required");
        public FinalSectionPermit EnvironmentHealthPermit = new FinalSectionPermit("Environmental Health Permit");
        public FinalSectionPermit ABCLicense = new FinalSectionPermit("ABC License");
        public FinalSectionPermit PoliceServices = new FinalSectionPermit("Police Services");
        public FinalSectionPermit AssemlagePermit = new FinalSectionPermit("Assemblage Permit");
        public FinalSectionPermit SpecificEventPermit = new FinalSectionPermit("Specific Event Permit");
        public FinalSectionPermit StreetClosure = new FinalSectionPermit("Street Closure");
        public FinalSectionPermit TentOrCanopyApproval = new FinalSectionPermit("Tent/Canopy Approval");
        public FinalSectionPermit ElectricianServices = new FinalSectionPermit("Electrician Services");
        public FinalSectionPermit LiquorLiabilityInsurance = new FinalSectionPermit("Liquor Liqability Insurance");
        public FinalSectionPermit EventLiabilityInsurance = new FinalSectionPermit("Event Liability Insurance");
        public FinalSectionPermit SuppliersInsurance = new FinalSectionPermit("Suppliers Insurance");
        public FinalSectionPermit VendorsInsurance = new FinalSectionPermit("Vendors Insurance");

    }
}
