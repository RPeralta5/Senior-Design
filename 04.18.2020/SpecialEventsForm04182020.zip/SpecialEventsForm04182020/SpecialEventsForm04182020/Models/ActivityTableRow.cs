﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventsForm04182020.Models
{
    public class ActivityTableRow
    {
        public int ID { get; set; }
        [DataType(DataType.Date)]
        public DateTime Date { get; set; }
        public string Activity { get; set; }
        public int Attendance { get; set; }

        public ActivityTableRow( int id, DateTime date, string activity, int attendance)
        {
            this.ID = id;
            this.Date = date;
            this.Activity = activity;
            this.Attendance = attendance;
        }

        public ActivityTableRow() { }
    }

}
