﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SpecialEventsForm03202020.Models;

namespace SpecialEventsForm03202020.Controllers
{
    public class HomeController : Controller
    {
        //private readonly ILogger<HomeController> _logger;

        public IActionResult Privacy()
        {
            return View();
        }

        public int id = 0;
        public String password = "";

        public IActionResult Index()
        {

            //RegisterInformation temp = new RegisterInformation(id, password);

            //ViewBag.Message = string.Format("Your ID # is {0}. Your password is {1}.", id, password);
            //ViewBag.Message = "Your form has been saved." + Environment.NewLine + "Your ID is: " + id + Environment.NewLine + "Your password is: " + password;

            //return FormTurnedIn();
            return View();
        }

        ///////////

        private readonly IWebHostEnvironment hostingEnvironment;
        public HomeController(IWebHostEnvironment e)
        {
            hostingEnvironment = e;
        }

        ///////////

        [HttpPost]
        public IActionResult FormTurnedIn(RegisterInformation registerInformation,
            //variables for holding file inputs
            IFormFile eventDateFile, IFormFile activitiesDescriptionFile, IFormFile liabilityReleaseFile, IFormFile followingActivitiesFile,
            IFormFile vendorsTableFile, IFormFile exhibitorsTableFile, IFormFile certificationOfEventLocationFile, IFormFile lACertificationFile,
            IFormFile allVendorsCertificationsFile, IFormFile allBrochuresFile, IFormFile completeScheduleOfEventsFile, IFormFile waiverReleasesSignedFile,
            IFormFile diagramOrSitePlanFile, IFormFile fiveYearLossHistoryFile, IFormFile evacuationParkAndTrafficPlanDiagramFile,

            ////////////////// Parameters are mostly of radio buttons or checkboxes (yes or no) or more than 2 options

            // Important Notice Parameters
            bool Notice

            // Application Information Parameters
            // none

            // Event Information Parameters
            // none

            // Event Location Parameters
            // none

            // Final Section Parameters
            // none
            )
        {
            //////////////////////////////////////////////////////////////////////////////////////////

            // Important Notice Action
            int agree;

            if (Notice)
            {
                agree = 1;
            }
            else
            {
                agree = 0;
            }

            if (registerInformation.Password == null && registerInformation.ApplicationID.ToString() == "0")
            {
                var length = 16;
                string charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789`~!@#$%^&*()-_=+[{]}|;:,<.>/?";


                Random rand = new Random();
                for (int i = 0, n = charset.Length; i < length; ++i)
                {
                    password += charset[rand.Next(0, charset.Length - 1)];
                }

            }
            else
            {
                password = registerInformation.Password;
            }

            // SQL Connection String
            string connectionString = @"Data Source=DESKTOP-FSJF92K\JWSQL;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            // Important Notice query all here
            string importantNoticeString = "Use CS4961;" + "Insert into ImportantNotice (Password, Agreement) values (\'" + password + "\'," + agree + ");";
            string retrieveString = "Use CS4961;" + "Select Id from ImportantNotice  where password = \'" + password + "\';";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(importantNoticeString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }

                SqlCommand command = new SqlCommand(retrieveString, connection);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    id = (int)reader[0];
                }
                connection.Close();
            }
            //////////////////////////////////////////////////////////////////////////////////////////

            // Applicant Information Action

            // Application Information query all here
            string applicationInformationString = ApplicantInformationQueryString(registerInformation, eventDateFile, activitiesDescriptionFile, liabilityReleaseFile, followingActivitiesFile,
            vendorsTableFile, exhibitorsTableFile, certificationOfEventLocationFile, lACertificationFile,
            allVendorsCertificationsFile, allBrochuresFile, completeScheduleOfEventsFile, waiverReleasesSignedFile,
            diagramOrSitePlanFile, fiveYearLossHistoryFile, evacuationParkAndTrafficPlanDiagramFile);


            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                using (SqlCommand cmd = new SqlCommand(applicationInformationString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }
            //////////////////////////////////////////////////////////////////////////////////////////

            // Event Information Action

            // Event Information query all here
            string eventInformationString = EventInformationQueryStringString(registerInformation, eventDateFile, activitiesDescriptionFile, liabilityReleaseFile, followingActivitiesFile,
            vendorsTableFile, exhibitorsTableFile, certificationOfEventLocationFile, lACertificationFile,
            allVendorsCertificationsFile, allBrochuresFile, completeScheduleOfEventsFile, waiverReleasesSignedFile,
            diagramOrSitePlanFile, fiveYearLossHistoryFile, evacuationParkAndTrafficPlanDiagramFile);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(eventInformationString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////

            // Music Types Action

            // Music Types query all here
            string musicTypesString = MusicTypesQueryString(registerInformation, eventDateFile, activitiesDescriptionFile, liabilityReleaseFile, followingActivitiesFile,
            vendorsTableFile, exhibitorsTableFile, certificationOfEventLocationFile, lACertificationFile,
            allVendorsCertificationsFile, allBrochuresFile, completeScheduleOfEventsFile, waiverReleasesSignedFile,
            diagramOrSitePlanFile, fiveYearLossHistoryFile, evacuationParkAndTrafficPlanDiagramFile);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(musicTypesString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }
            //////////////////////////////////////////////////////////////////////////////////////////

            // FolowingActivities1 Action

            // FolowingActivities1 query all here
            string followingActivities1String = FolowingActivities1QueryString(registerInformation, eventDateFile, activitiesDescriptionFile, liabilityReleaseFile, followingActivitiesFile,
            vendorsTableFile, exhibitorsTableFile, certificationOfEventLocationFile, lACertificationFile,
            allVendorsCertificationsFile, allBrochuresFile, completeScheduleOfEventsFile, waiverReleasesSignedFile,
            diagramOrSitePlanFile, fiveYearLossHistoryFile, evacuationParkAndTrafficPlanDiagramFile);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(followingActivities1String, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }
            //////////////////////////////////////////////////////////////////////////////////////////

            // FolowingActivities2 Action

            // FolowingActivities2 query all here
            string followingActivities2String = FolowingActivities2QueryString(registerInformation, eventDateFile, activitiesDescriptionFile, liabilityReleaseFile, followingActivitiesFile,
            vendorsTableFile, exhibitorsTableFile, certificationOfEventLocationFile, lACertificationFile,
            allVendorsCertificationsFile, allBrochuresFile, completeScheduleOfEventsFile, waiverReleasesSignedFile,
            diagramOrSitePlanFile, fiveYearLossHistoryFile, evacuationParkAndTrafficPlanDiagramFile);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(followingActivities2String, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////

            // Event Location Action

            // Event Location query all here

            string eventLocationString = EventLocationQueryString(registerInformation, eventDateFile, activitiesDescriptionFile, liabilityReleaseFile, followingActivitiesFile,
            vendorsTableFile, exhibitorsTableFile, certificationOfEventLocationFile, lACertificationFile,
            allVendorsCertificationsFile, allBrochuresFile, completeScheduleOfEventsFile, waiverReleasesSignedFile,
            diagramOrSitePlanFile, fiveYearLossHistoryFile, evacuationParkAndTrafficPlanDiagramFile);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(eventLocationString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////

            // Final Section Action

            // Final Section query all here

            string finalSectionString = FinalSectionQueryString(registerInformation, eventDateFile, activitiesDescriptionFile, liabilityReleaseFile, followingActivitiesFile,
            vendorsTableFile, exhibitorsTableFile, certificationOfEventLocationFile, lACertificationFile,
            allVendorsCertificationsFile, allBrochuresFile, completeScheduleOfEventsFile, waiverReleasesSignedFile,
            diagramOrSitePlanFile, fiveYearLossHistoryFile, evacuationParkAndTrafficPlanDiagramFile);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(finalSectionString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////

            // Final Section Permit Action

            // Final Section Permit query all here

            string permitString = FinalSectionPermitQueryString(registerInformation, eventDateFile, activitiesDescriptionFile, liabilityReleaseFile, followingActivitiesFile,
            vendorsTableFile, exhibitorsTableFile, certificationOfEventLocationFile, lACertificationFile,
            allVendorsCertificationsFile, allBrochuresFile, completeScheduleOfEventsFile, waiverReleasesSignedFile,
            diagramOrSitePlanFile, fiveYearLossHistoryFile, evacuationParkAndTrafficPlanDiagramFile);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(permitString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////
            // Storing input files !!!

            //Creating folder by id into wwwroot/CustomerProfiles folder
            string pathString = System.IO.Path.Combine(hostingEnvironment.WebRootPath + "/CustomerProfiles", id.ToString());
            System.IO.Directory.CreateDirectory(pathString);


            // Startin file testin // change name Eventfile1
            /*
            if (eventDateFile != null)
            {
                var eventDateFileName = Path.Combine(hostingEnvironment.WebRootPath + "/CustomerProfiles/" + id.ToString(), Path.GetFileName(eventDateFile.FileName));
                eventDateFile.CopyTo(new FileStream(eventDateFileName, FileMode.Create));
                //ViewData["eventFileLocation"] = eventDateFileName;
            }
            */


            IFormFile[] inputFileArray = {eventDateFile, activitiesDescriptionFile, liabilityReleaseFile, followingActivitiesFile,
                vendorsTableFile, exhibitorsTableFile, certificationOfEventLocationFile, lACertificationFile,
                allVendorsCertificationsFile, allBrochuresFile, completeScheduleOfEventsFile, waiverReleasesSignedFile,
                diagramOrSitePlanFile, fiveYearLossHistoryFile, evacuationParkAndTrafficPlanDiagramFile};

            foreach (IFormFile tempfile in inputFileArray)
            {
                if (tempfile != null)
                {
                    var tempFileName = Path.Combine(hostingEnvironment.WebRootPath + "/CustomerProfiles/" + id.ToString(), Path.GetFileName(tempfile.FileName));
                    tempfile.CopyTo(new FileStream(tempFileName, FileMode.Create));
                }
            }
            //////////////////////////////////////////////////////////////////////////////////////////

            // Event Table Action

            // Event Table query all here
            //if (registerInformation.eventTableRows[0].Hours == null && registerInformation.eventTableRows[0].IsAlcoholServed == null && registerInformation.eventTableRows[0].IsAlcoholSold == null) { }
            if (registerInformation.eventTableRows == null) { }
            else if (registerInformation.eventTableRows[0].Hours != null && registerInformation.eventTableRows[0].IsAlcoholServed != null && registerInformation.eventTableRows[0].IsAlcoholSold != null)
            {
                string eventTableString = EventTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(eventTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }




            //////////////////////////////////////////////////////////////////////////////////////////
            // Activity Table Action

            // Activity Table query all here
            if (registerInformation.activityTableRows == null) { }
            else if (registerInformation.activityTableRows[0].Activity != null && registerInformation.activityTableRows[0].Attendance != 0)
            {
                string activityTableString = ActivityTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(activityTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////
            // MusicArtists Table Action

            // MusicArtists Table query all here

            // if (registerInformation.musicArtistsTableRows[0].Name == null && registerInformation.musicArtistsTableRows[0].Address == null) { }
            if (registerInformation.musicArtistsTableRows == null) { }
            else if (registerInformation.musicArtistsTableRows[0].Name != null && registerInformation.musicArtistsTableRows[0].Address != null)
            {
                string musicArtistsTableString = MusicTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(musicArtistsTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////
            // Vendor Table Action

            // Vendor Table query all here

            //if (registerInformation.vendorTableRows[0].TypeOfService == null && registerInformation.vendorTableRows[0].Name == null && registerInformation.vendorTableRows[0].MailAddress == null) { }
            if (registerInformation.vendorTableRows == null) { }
            else if (registerInformation.vendorTableRows[0].TypeOfService != null && registerInformation.vendorTableRows[0].Name != null && registerInformation.vendorTableRows[0].MailAddress != null && registerInformation.vendorTableRows[0].City != null && registerInformation.vendorTableRows[0].State != null)
            {
                string vendorTableString = VendorTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(vendorTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////
            // Exhibitor Table Action

            // Exhibitor Table query all here

            //if (registerInformation.exhibitorTableRows[0].TypeOfService == null && registerInformation.exhibitorTableRows[0].Name == null && registerInformation.exhibitorTableRows[0].MailAddress == null) { }
            if (registerInformation.exhibitorTableRows == null) { }
            else if (registerInformation.exhibitorTableRows[0].TypeOfService != null && registerInformation.exhibitorTableRows[0].Name != null && registerInformation.exhibitorTableRows[0].MailAddress != null && registerInformation.exhibitorTableRows[0].City != null && registerInformation.exhibitorTableRows[0].State != null)
            {
                string exhibitorTableString = ExhibitorTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(exhibitorTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////
            // PastEvent Table Action

            // PastEvent Table query all here

            //if (registerInformation.pastEventTableRows[0].Claimant == null && registerInformation.pastEventTableRows[0].Description == null) { }
            if (registerInformation.pastEventTableRows == null) { }
            else if (registerInformation.pastEventTableRows[0].Claimant != null && registerInformation.pastEventTableRows[0].Description != null)
            {
                string pastEventTableString = PastEventTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(pastEventTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////
            // StreetClosure Table Action

            // StreetClosure Table query all here

            //if (registerInformation.streetClosureRows[0].StreetName == null) { }
            if (registerInformation.streetClosureRows == null) { }
            else if (registerInformation.streetClosureRows[0].StreetName != null)
            {
                string streetClosureTableString = StreetClosureTableQueryString(registerInformation);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(streetClosureTableString, connection))
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////


            // Creating objects to hold what we want to return such as ID and Password to FormTurnedIn.cshtml

            RegisterInformation temp = new RegisterInformation(id, password);
            ArrayOfRegistry array = new ArrayOfRegistry();
            array.AddRegistry(temp);

            ViewBag.temporary = array;
            return View(array);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public string ApplicantInformationQueryString(RegisterInformation reg, IFormFile eventDateFile, IFormFile activitiesDescriptionFile, IFormFile liabilityReleaseFile, IFormFile followingActivitiesFile,
            IFormFile vendorsTableFile, IFormFile exhibitorsTableFile, IFormFile certificationOfEventLocationFile, IFormFile lACertificationFile,
            IFormFile allVendorsCertificationsFile, IFormFile allBrochuresFile, IFormFile completeScheduleOfEventsFile, IFormFile waiverReleasesSignedFile,
            IFormFile diagramOrSitePlanFile, IFormFile fiveYearLossHistoryFile, IFormFile evacuationParkAndTrafficPlanDiagramFile)
        {
            string query = "Use CS4961;" +
                "Insert into ApplicationInformation " +
                "( ID," +
                " AInameInsur1Input," +
                " AInameInsur2Input," +
                " AInameInsur3Input," +
                " AInameInsur4Input," +
                " AInameInsur5Input," +
                " AInameInsur6Input," +
                " AInameInsur7Input," +
                " AInameInsur8Input," +
                " AInameInsur9Input," +
                " AInameInsur10Input," +
                " AInameInsur11Input," +
                " AInameInsur12Input," +
                " AInameInsur13Input," +
                " AInameInsur14Input," +
                " AInameInsuredOther," +
                " AInameOnPolicy," +
                " AIbusinessAs," +
                " AImailAddress," +
                " AIcity," +
                " AIstate," +
                " AIzip," +
                " AIcontactPerson," +
                " AIemail," +
                " AIhomeNum," +
                " AIbusinessNum," +
                " AIfax," +
                " AIwebsite) values (" +
                id + "," +
                "\'" + reg.NameIsAIndividual + "\'," +
                "\'" + reg.NameIsACorporation + "\'," +
                "\'" + reg.NameIsATrustOfEstate + "\'," +
                "\'" + reg.NameIsAUnicorpAssoc + "\'," +
                "\'" + reg.NameIsAGeneralPartnership + "\'," +
                "\'" + reg.NameIsALLCorLLP + "\'," +
                "\'" + reg.NameIsAPublicAgency + "\'," +
                "\'" + reg.NameIsALaborUnion + "\'," +
                "\'" + reg.NameIsAInformalGroup + "\'," +
                "\'" + reg.NameIsALimitedPartnership + "\'," +
                "\'" + reg.NameIsANotForProfit + "\'," +
                "\'" + reg.NameIsARegliousGroup + "\'," +
                "\'" + reg.NameIsAJointVenture + "\'," +
                "\'" + reg.NameIsAOther + "\'," +
                "\'" + reg.NameIsAOtherIs + "\'," +
                "\'" + reg.NameAsAppeared + "\'," +
                "\'" + reg.DoingBusinessAs + "\'," +
                "\'" + reg.MailingAddress + "\'," +
                "\'" + reg.ApplicantCity + "\'," +
                "\'" + reg.ApplicantState + "\'," +
                "\'" + reg.ApplicantZip + "\'," +
                "\'" + reg.ApplicantContact + "\'," +
                "\'" + reg.ApplicantEmail + "\'," +
                "\'" + reg.ApplicantHomePhone + "\'," +
                "\'" + reg.ApplicantBusinessPhone + "\'," +
                "\'" + reg.ApplicantFax + "\'," +
                "\'" + reg.ApplicantWebAddress + "\'" +
                ");";

            return query;
        }

        public string EventInformationQueryStringString(RegisterInformation reg, IFormFile eventDateFile, IFormFile activitiesDescriptionFile, IFormFile liabilityReleaseFile, IFormFile followingActivitiesFile,
            IFormFile vendorsTableFile, IFormFile exhibitorsTableFile, IFormFile certificationOfEventLocationFile, IFormFile lACertificationFile,
            IFormFile allVendorsCertificationsFile, IFormFile allBrochuresFile, IFormFile completeScheduleOfEventsFile, IFormFile waiverReleasesSignedFile,
            IFormFile diagramOrSitePlanFile, IFormFile fiveYearLossHistoryFile, IFormFile evacuationParkAndTrafficPlanDiagramFile)
        {
            string a;
            string b;
            string c;
            string d;

            if (eventDateFile == null)
            {
                a = null;
            }
            else
            {
                a = eventDateFile.FileName.ToString();
            }

            if (activitiesDescriptionFile == null)
            {
                b = null;
            }
            else
            {
                b = activitiesDescriptionFile.FileName.ToString();
            }

            if (liabilityReleaseFile == null)
            {
                c = null;
            }
            else
            {
                c = liabilityReleaseFile.FileName.ToString();
            }

            if (followingActivitiesFile == null)
            {
                d = null;
            }
            else
            {
                d = followingActivitiesFile.FileName.ToString();
            }

            string query = "Use CS4961;" +
                "Insert into EventInformation" +
                "( ID," +
                "EINameOfEvent," +
                "EIDateEventHeldFile," +
                "EIActivitiesDescription," +
                "EIActivitiesDescriptionFile," +
                "EIBusOwner," +
                "EIBusManager," +
                "EIThirdParty," +
                "EIEventPrivacy," +
                "EIAdmissionCharge," +
                "EIAdmissionCost," +
                "EISellAdmissionTicket," +
                "EISellHowManyTickets," +
                "EITotalTicketSalesAmount," +
                "EIPricePerTicket," +
                "EIHowTicketsSold," +
                "EIWhoSellTickets," +
                "EIDonationExpected," +
                "EIAssignedSeating," +
                "EIOpenSeating," +
                "EIBringYourOwnSeating," +
                "EIBleachersSeating," +
                "EISeatingNotApplicable," +
                "EIPrivateSecurityPersons," +
                "EIPoliceOrSheriffPersons," +
                "EIPeerGroupOrUshersPersons," +
                "EIEmployeesPersons," +
                "EIParentChaperonsPersons," +
                "EIVolunteersPersons," +
                "EISecurityArmed," +
                "EIWandingChecking," +
                "EIFirstAid," +
                "EIFirstAidCompany," +
                "EIReceivedInsuranceCert," +
                "EIADAExit," +
                "EIADAParking," +
                "EIEventAdvertising," +
                "EIAdvertiseByWeb," +
                "EIAdvertisementWebsite," +
                "EIEventIsOnTelevision," +
                "EIEventIsOnRadio," +
                "EIEventIsOnNewspaper," +
                "EIEventIsOnBrochure," +
                "EIEventIsOnHandout," +
                "EIEventIsOnBillboard," +
                "EIEventIsOnPoster," +
                "EIEventIsOnOther," +
                "EIIsAlcoholServed," +
                "EIIsAlcoholSold," +
                "EIIsEventCharged," +
                "EIIsEventPayToAttend," +
                "EIIsEventReceiveDonation," +
                "EIIsThereBeer," +
                "EIIsThereWineOrChampagne," +
                "EIIsThereMixedOrBar," +
                "EIIsThereAlcoholVendor," +
                "EIIsThereAlcoholVendingInsurance," +
                "EIEstimatedAlcoholSales," +
                "EINumberOfAlcoholLocations," +
                "EIIsLiquorLicenseRequired," +
                "EIMustLiquorBeDrankInArea," +
                "EINeedIdToRecieveLiquor," +
                "EIOverAgeDrinkerHaveOtherID," +
                "EIIsThereLimitTwoServingLiquor," +
                "EIIsThereLiquorStaffMonitoring," +
                "EIIsLiquorBarClosedTwoHrsEarly," +
                "EIHasAthleticOrRecreationalActivity," +
                "EIWaiverLiabilityProcedure," +
                "EILiabilityReleaseFile," +
                "EIHasMusic," +
                "EIIsThereLiveMusic," +
                "EIIsThereDiskJockey," +
                "EIIsThereStereoCDPlayer," +
                "EIAmplifiedSound," +
                "EIHowManyArtists," +
                "EIOwnElectricity," +
                "EIArrangements," +
                "EIOtherEntertainment," +
                "EIDescribeOtherEntertainment," +
                "EIJumpsTanksTrains," +
                "EICompanyHired," +
                "EIFollowingActivitiesFile," +
                "EIWaiverDescription" +
                ") values (" +
                id + "," +
                "\'" + reg.EventName + "\'," +
                "\'" + a + "\'," +
                "\'" + reg.ActivitiesDescription + "\'," +
                "\'" + b + "\'," +
                "\'" + reg.InsuredIsOwner + "\'," +
                "\'" + reg.InsuredIsManager + "\'," +
                "\'" + reg.InsuredIsThirdParty + "\'," +
                "\'" + reg.EventIsPrivacy + "\'," +
                "\'" + reg.AdmissionCharge + "\'," +
                "\'" + reg.AdmissionCost + "\'," +
                "\'" + reg.SellTicket + "\'," +
                "\'" + reg.SellHowManyTickets + "\'," +
                "\'" + reg.TotalTicketSalesAmount + "\'," +
                "\'" + reg.PricePerTicket + "\'," +
                "\'" + reg.HowToSellTicket + "\'," +
                "\'" + reg.WhoSellTickets + "\'," +
                "\'" + reg.RecieveDonate + "\'," +
                "\'" + reg.SeatType1 + "\'," +
                "\'" + reg.SeatType2 + "\'," +
                "\'" + reg.SeatType3 + "\'," +
                "\'" + reg.SeatType4 + "\'," +
                "\'" + reg.SeatType5 + "\'," +
                "\'" + reg.NumOfPrivateSecurityPersons + "\'," +
                "\'" + reg.NumOfPoliceOrSheriffPersons + "\'," +
                "\'" + reg.NumOfPeerGroupOrUshersPersons + "\'," +
                "\'" + reg.NumOfEmployeesPersons + "\'," +
                "\'" + reg.NumOfParentChaperonsPersons + "\'," +
                "\'" + reg.NumOfVolunteersPersons + "\'," +
                "\'" + reg.Armed + "\'," +
                "\'" + reg.BagCheck + "\'," +
                "\'" + reg.FirstAid + "\'," +
                "\'" + reg.CompanyForFirstAide + "\'," +
                "\'" + reg.RecievedInsurance + "\'," +
                "\'" + reg.EntranceExit + "\'," +
                "\'" + reg.AccessibleParking + "\'," +
                "\'" + reg.EventAdvertise + "\'," +
                "\'" + reg.EventIsOnWebsite + "\'," +
                "\'" + reg.EventWebsite + "\'," +
                "\'" + reg.EventTelevised + "\'," +
                "\'" + reg.EventRadio + "\'," +
                "\'" + reg.EventNewsPaper + "\'," +
                "\'" + reg.EventBrochure + "\'," +
                "\'" + reg.EventHandOut + "\'," +
                "\'" + reg.EventBillBoard + "\'," +
                "\'" + reg.EventPoster + "\'," +
                "\'" + reg.EventOther + "\'," +
                "\'" + reg.AlcoholServe + "\'," +
                "\'" + reg.AlcoholIsSold + "\'," +
                "\'" + reg.AlcoholFee + "\'," +
                "\'" + reg.EventFee + "\'," +
                "\'" + reg.EventDonation + "\'," +
                "\'" + reg.AlcoholType1 + "\'," +
                "\'" + reg.AlcoholType2 + "\'," +
                "\'" + reg.AlcoholType3 + "\'," +
                "\'" + reg.AlcoholVending + "\'," +
                "\'" + reg.AlcoholVendingInsurance + "\'," +
                "\'" + reg.EstimatedAlcoholSales + "\'," +
                "\'" + reg.NumOfAlcoholLocations + "\'," +
                "\'" + reg.LiquorLicense + "\'," +
                "\'" + reg.LiquorDrinkArea + "\'," +
                "\'" + reg.LiquorIdentification + "\'," +
                "\'" + reg.DrinkingAge + "\'," +
                "\'" + reg.LiquorServingLimit + "\'," +
                "\'" + reg.LiquorStaffMonitor + "\'," +
                "\'" + reg.LiquorBarClose + "\'," +
                "\'" + reg.AthleticRecreationalActivity + "\'," +
                "\'" + reg.WaiverAndLiabilityProcedure + "\'," +
                "\'" + c + "\'," +
                "\'" + reg.HaveMusic + "\'," +
                "\'" + reg.TypeOfMusic1 + "\'," +
                "\'" + reg.TypeOfMusic2 + "\'," +
                "\'" + reg.TypeOfMusic3 + "\'," +
                "\'" + reg.AmplifiedMusic + "\'," +
                "\'" + reg.NumOfBandsOrArtists + "\'," +
                "\'" + reg.OwnElectricity + "\'," +
                "\'" + reg.ElectricityArranging + "\'," +
                "\'" + reg.OtherEntertainment + "\'," +
                "\'" + reg.OtherEntertainmentDescription + "\'," +
                "\'" + reg.ActivityStuff + "\'," +
                "\'" + reg.HiredCompanyForActivities + "\'," +
                "\'" + d + "\'," +
                "\'" + reg.ExplainProcedureForWaivers + "\'" +
                ");";
            return query;
        }

        public string MusicTypesQueryString(RegisterInformation reg, IFormFile eventDateFile, IFormFile activitiesDescriptionFile, IFormFile liabilityReleaseFile, IFormFile followingActivitiesFile,
            IFormFile vendorsTableFile, IFormFile exhibitorsTableFile, IFormFile certificationOfEventLocationFile, IFormFile lACertificationFile,
            IFormFile allVendorsCertificationsFile, IFormFile allBrochuresFile, IFormFile completeScheduleOfEventsFile, IFormFile waiverReleasesSignedFile,
            IFormFile diagramOrSitePlanFile, IFormFile fiveYearLossHistoryFile, IFormFile evacuationParkAndTrafficPlanDiagramFile)
        {
            string query = "Use CS4961;" + "Insert into MusicTypes " +
                "(" +
                "ID, " +
                "IsThereAcidRock," +
                "IsThereAlternative, " +
                "IsThereBigBand," +
                "IsThereBlues, " +
                "IsThereChristian," +
                "IsThereClassical, " +
                "IsThereCountrySoul," +
                "IsThereCountryRock, " +
                "IsThereDeathRock," +
                "IsThereDisco, " +
                "IsThereContemporary," +
                "IsThereEthnicNForeignCultural, " +
                "IsThere1950sN1960s," +
                "IsThereFunk, " +
                "IsThereHardRock," +
                "IsThereHipHop, " +
                "IsThereJazz," +
                "IsTherePop, " +
                "IsThereRap," +
                "IsThereReggae, " +
                "IsThereSoftRock," +
                "IsThereSoul, " +
                "IsThereSymphony," +
                "IsThereSwing, " +
                "IsThereHeavyMetal," +
                "IsThereFolk, " +
                "IsThereGoth," +
                "IsThereGothMetal, " +
                "IsThereGospel," +
                "IsThereIndustrial, " +
                "IsTherePsychedelic," +
                "IsTherePunk, " +
                "IsThereRave," +
                "IsThereSka, " +
                "IsThereTechno," +
                "IsThereBubblegum, " +
                "IsThereRockability, " +
                "IsThereOther," +
                "IsThereOtherDescription" +

                ") values (" +
                id + "," +
                "\'" + reg.MusicType1 + "\'," +
                "\'" + reg.MusicType2 + "\'," +
                "\'" + reg.MusicType3 + "\'," +
                "\'" + reg.MusicType4 + "\'," +
                "\'" + reg.MusicType5 + "\'," +
                "\'" + reg.MusicType6 + "\'," +
                "\'" + reg.MusicType7 + "\'," +
                "\'" + reg.MusicType8 + "\'," +
                "\'" + reg.MusicType9 + "\'," +
                "\'" + reg.MusicType10 + "\'," +
                "\'" + reg.MusicType11 + "\'," +
                "\'" + reg.MusicType12 + "\'," +
                "\'" + reg.MusicType13 + "\'," +
                "\'" + reg.MusicType14 + "\'," +
                "\'" + reg.MusicType15 + "\'," +
                "\'" + reg.MusicType16 + "\'," +
                "\'" + reg.MusicType17 + "\'," +
                "\'" + reg.MusicType18 + "\'," +
                "\'" + reg.MusicType19 + "\'," +
                "\'" + reg.MusicType20 + "\'," +
                "\'" + reg.MusicType21 + "\'," +
                "\'" + reg.MusicType22 + "\'," +
                "\'" + reg.MusicType23 + "\'," +
                "\'" + reg.MusicType24 + "\'," +
                "\'" + reg.MusicType25 + "\'," +
                "\'" + reg.MusicType26 + "\'," +
                "\'" + reg.MusicType27 + "\'," +
                "\'" + reg.MusicType28 + "\'," +
                "\'" + reg.MusicType29 + "\'," +
                "\'" + reg.MusicType30 + "\'," +
                "\'" + reg.MusicType31 + "\'," +
                "\'" + reg.MusicType32 + "\'," +
                "\'" + reg.MusicType33 + "\'," +
                "\'" + reg.MusicType34 + "\'," +
                "\'" + reg.MusicType35 + "\'," +
                "\'" + reg.MusicType36 + "\'," +
                "\'" + reg.MusicType37 + "\'," +
                "\'" + reg.MusicType38 + "\'," +
                "\'" + reg.OtherTypeOfMusic + "\'" +

                ");";
            return query;
        }

        public string FolowingActivities1QueryString(RegisterInformation reg, IFormFile eventDateFile, IFormFile activitiesDescriptionFile, IFormFile liabilityReleaseFile, IFormFile followingActivitiesFile,
            IFormFile vendorsTableFile, IFormFile exhibitorsTableFile, IFormFile certificationOfEventLocationFile, IFormFile lACertificationFile,
            IFormFile allVendorsCertificationsFile, IFormFile allBrochuresFile, IFormFile completeScheduleOfEventsFile, IFormFile waiverReleasesSignedFile,
            IFormFile diagramOrSitePlanFile, IFormFile fiveYearLossHistoryFile, IFormFile evacuationParkAndTrafficPlanDiagramFile)
        {
            string query = "Use CS4961;" + "Insert into IncludeFollowingActivities1 " +
                "(" +

                "ID, " +
                "IsThereClimbing," +
                "IsThereSkateBoard, " +
                "IsThereRoller," +
                "IsThereCycling, " +
                "IsThereWatercraft," +
                "IsThereGun, " +
                "IsThereFire," +
                "IsThereArmory, " +
                "IsThereChemical," +
                "IsThereMedical, " +
                "IsThereConstructOrDemo," +
                "IsThereScaffoldAbove4Ft " +

                ") values (" +

                id + "," +
                "\'" + reg.ClimbWall + "\'," +
                "\'" + reg.SkateBoard + "\'," +
                "\'" + reg.RollerAct + "\'," +
                "\'" + reg.CycleAct + "\'," +
                "\'" + reg.WaterAct + "\'," +
                "\'" + reg.GunAct + "\'," +
                "\'" + reg.FireAct + "\'," +
                "\'" + reg.ArmoryAct + "\'," +
                "\'" + reg.ChemicalAct + "\'," +
                "\'" + reg.MedicalAct + "\'," +
                "\'" + reg.DemolitionAct + "\'," +
                "\'" + reg.ScaffoldingfAct + "\'" +

                ");";
            return query;
        }

        public string FolowingActivities2QueryString(RegisterInformation reg, IFormFile eventDateFile, IFormFile activitiesDescriptionFile, IFormFile liabilityReleaseFile, IFormFile followingActivitiesFile,
            IFormFile vendorsTableFile, IFormFile exhibitorsTableFile, IFormFile certificationOfEventLocationFile, IFormFile lACertificationFile,
            IFormFile allVendorsCertificationsFile, IFormFile allBrochuresFile, IFormFile completeScheduleOfEventsFile, IFormFile waiverReleasesSignedFile,
            IFormFile diagramOrSitePlanFile, IFormFile fiveYearLossHistoryFile, IFormFile evacuationParkAndTrafficPlanDiagramFile)
        {
            string query = "Use CS4961;" + "Insert into IncludeFollowingActivities2 " +
                "(" +

                "ID, " +
                "HasAirRides," +
                "HasTerrainBoarding, " +
                "HasBaseJumping," +
                "HasBouldering, " +
                "HasBoxingMartialArts," +
                "HasBungeeJumping, " +
                "HasCircusCarnival," +
                "HasConcertsOver6Hrs, " +
                "HasConcertwithMoshPit," +
                "HasPlatformBoardDiving, " +
                "HasHangGliding," +
                "HasKayakRaftCanoe," +
                "HasMechanicalRide," +
                "HasMotorSport," +
                "HasMountainBiking," +
                "HasPowerBoats," +
                "HasProSportCashPrizeGames," +
                "HasPyroAndFire," +
                "HasRapHeavyMetalConcert," +
                "HasRockClimbing," +
                "HasRodeoAndRoping," +
                "HasSkinDiving," +
                "HasScubaDiving," +
                "HasTractorTruckPull," +
                "HasTrampoline " +

                ") values (" +

                id + "," +
                "\'" + reg.AirRiding + "\'," +
                "\'" + reg.TerrainBoarding + "\'," +
                "\'" + reg.BaseJumping + "\'," +
                "\'" + reg.Bouldering + "\'," +
                "\'" + reg.BoxingMaritalArts + "\'," +
                "\'" + reg.BungeeAct + "\'," +
                "\'" + reg.CircusCarnival + "\'," +
                "\'" + reg.Concert6HrAct + "\'," +
                "\'" + reg.ConcertDanceAct + "\'," +
                "\'" + reg.PlatformBoardDiving + "\'," +
                "\'" + reg.HangGliding + "\'," +
                "\'" + reg.KayalRaftCanoeing + "\'," +
                "\'" + reg.MechanicalRide + "\'," +
                "\'" + reg.MotorSportEquipment + "\'," +
                "\'" + reg.MountainBiking + "\'," +
                "\'" + reg.PowerBoats + "\'," +
                "\'" + reg.ProSportCash + "\'," +
                "\'" + reg.PyroFireAct + "\'," +
                "\'" + reg.RapRockConcert + "\'," +
                "\'" + reg.RockClimbAct + "\'," +
                "\'" + reg.RodeoRopeAct + "\'," +
                "\'" + reg.SkinDiveAct + "\'," +
                "\'" + reg.ScubaDiveAct + "\'," +
                "\'" + reg.TractorTruckPull + "\'," +
                "\'" + reg.Trampoline + "\'" +

                ");";

            return query;
        }

        public string EventLocationQueryString(RegisterInformation reg, IFormFile eventDateFile, IFormFile activitiesDescriptionFile, IFormFile liabilityReleaseFile, IFormFile followingActivitiesFile,
            IFormFile vendorsTableFile, IFormFile exhibitorsTableFile, IFormFile certificationOfEventLocationFile, IFormFile lACertificationFile,
            IFormFile allVendorsCertificationsFile, IFormFile allBrochuresFile, IFormFile completeScheduleOfEventsFile, IFormFile waiverReleasesSignedFile,
            IFormFile diagramOrSitePlanFile, IFormFile fiveYearLossHistoryFile, IFormFile evacuationParkAndTrafficPlanDiagramFile)
        {
            string a;
            string b;
            string c;
            string d;
            string e;
            string f;
            string g;
            string h;
            string i;
            string j;
            string k;

            if (vendorsTableFile == null)
            {
                a = null;
            }
            else
            {
                a = vendorsTableFile.FileName.ToString();
            }

            if (exhibitorsTableFile == null)
            {
                b = null;
            }
            else
            {
                b = exhibitorsTableFile.FileName.ToString();
            }

            if (certificationOfEventLocationFile == null)
            {
                c = null;
            }
            else
            {
                c = certificationOfEventLocationFile.FileName.ToString();
            }

            if (lACertificationFile == null)
            {
                d = null;
            }
            else
            {
                d = lACertificationFile.FileName.ToString();
            }

            if (allVendorsCertificationsFile == null)
            {
                e = null;
            }
            else
            {
                e = allVendorsCertificationsFile.FileName.ToString();
            }

            if (allBrochuresFile == null)
            {
                f = null;
            }
            else
            {
                f = allBrochuresFile.FileName.ToString();
            }

            if (completeScheduleOfEventsFile == null)
            {
                g = null;
            }
            else
            {
                g = completeScheduleOfEventsFile.FileName.ToString();
            }

            if (waiverReleasesSignedFile == null)
            {
                h = null;
            }
            else
            {
                h = waiverReleasesSignedFile.FileName.ToString();
            }

            if (diagramOrSitePlanFile == null)
            {
                i = null;
            }
            else
            {
                i = diagramOrSitePlanFile.FileName.ToString();
            }

            if (fiveYearLossHistoryFile == null)
            {
                j = null;
            }
            else
            {
                j = fiveYearLossHistoryFile.FileName.ToString();
            }

            if (evacuationParkAndTrafficPlanDiagramFile == null)
            {
                k = null;
            }
            else
            {
                k = evacuationParkAndTrafficPlanDiagramFile.FileName.ToString();
            }

            string query = "Use CS4961;" + "Insert into EventLocation " +
                "(" +
                "ID, " +
                "ELNameOfFacility," +
                "ELStreetName, " +
                "ELEventCity," +
                "ELEventState," +
                "ELEventZip," +
                "ELOutdoorSize," +
                "ELOutdoorAreaInsured," +
                "ELAreThereVendorsSellingAlcohol," +
                "ELVendorsFile," +
                "ELExhibitorsFile," +
                "ELAreTherePastEvents," +
                "ELCertificateOfInsuranceFile," +
                "ELIsThereEmergencyEvacPlan," +
                "ELEvacuationPlanDescription," +
                "ELIsThereMedicalPresence," +
                "ELNumOfDoctors," +
                "ELNumOfParamedics," +
                "ELNumOfNurses," +
                "ELNumOfEMTandEMS," +
                "ELNumOfOther," +
                "ELIsThereAmbulance," +
                "ELIsThereStreetClosure," +
                "ELIsThereTrafficMitigation," +
                "ELTrafficMitigationDescription," +
                "ELLACertificationFile," +
                "ELVendorsInsuredFile," +
                "ELBrochuresAdsFile," +
                "ELScheduleOfEventsFile," +
                "ELWaiversAndReleaseFile," +
                "ELSitePlanDiagramFile," +
                "ELFiveYearHistoryFile," +
                "ELEvacuationPlanFile" +

                ") values (" +
                id + "," +
                "\'" + reg.FacilityName + "\'," +
                "\'" + reg.FacilityStreetName + "\'," +
                "\'" + reg.FacilityCity + "\'," +
                "\'" + reg.FacilityState + "\'," +
                "\'" + reg.FacilityZip + "\'," +
                "\'" + reg.OutdoorAreaSize + "\'," +
                "\'" + reg.OutdoorAreaInsured + "\'," +
                "\'" + reg.IsVendorSellingAlcohol + "\'," +
                "\'" + a + "\'," +
                "\'" + b + "\'," +
                "\'" + reg.HeldBefore + "\'," +
                "\'" + c + "\'," +
                "\'" + reg.EvacuationPlan + "\'," +
                "\'" + reg.EvacuationPlanDescription + "\'," +
                "\'" + reg.IsThereMedicalPresence + "\'," +
                "\'" + reg.NumOfDoctors + "\'," +
                "\'" + reg.NumOfParamedics + "\'," +
                "\'" + reg.NumOfNurses + "\'," +
                "\'" + reg.NumOfEMTOrEMS + "\'," +
                "\'" + reg.NumOfOther + "\'," +
                "\'" + reg.AmbulanceOnSite + "\'," +
                "\'" + reg.StreetClosure + "\'," +
                "\'" + reg.TrafficMitigation + "\'," +
                "\'" + reg.TrafficMitigationDescription + "\'," +
                "\'" + d + "\'," +
                "\'" + e + "\'," +
                "\'" + f + "\'," +
                "\'" + g + "\'," +
                "\'" + h + "\'," +
                "\'" + i + "\'," +
                "\'" + j + "\'," +
                "\'" + k + "\'" +

                ");";
            return query;
        }

        public string FinalSectionQueryString(RegisterInformation reg, IFormFile eventDateFile, IFormFile activitiesDescriptionFile, IFormFile liabilityReleaseFile, IFormFile followingActivitiesFile,
            IFormFile vendorsTableFile, IFormFile exhibitorsTableFile, IFormFile certificationOfEventLocationFile, IFormFile lACertificationFile,
            IFormFile allVendorsCertificationsFile, IFormFile allBrochuresFile, IFormFile completeScheduleOfEventsFile, IFormFile waiverReleasesSignedFile,
            IFormFile diagramOrSitePlanFile, IFormFile fiveYearLossHistoryFile, IFormFile evacuationParkAndTrafficPlanDiagramFile)
        {
            string query = "Use CS4961;" + "Insert into FinalSection " +
                "(" +
                "ID, " +

                "FSApplicantSignature," +
                "FSApplicantTitle," +
                "FSFinishedApplicationDate," +
                "FSSupervisorInitials," +
                "FSAssemblingsPermitDate" +

                ") values (" +
                id + "," +
                "\'" + reg.ApplicantSignature + "\'," +
                "\'" + reg.ApplicantTitle + "\'," +
                "\'" + reg.ApplicationDate + "\'," +
                "\'" + reg.SupervisorInitials + "\'," +
                "\'" + reg.AssemblingsPermitSignedDate + "\'" +
                ");";

            return query;
        }

        public string FinalSectionPermitQueryString(RegisterInformation reg, IFormFile eventDateFile, IFormFile activitiesDescriptionFile, IFormFile liabilityReleaseFile, IFormFile followingActivitiesFile,
            IFormFile vendorsTableFile, IFormFile exhibitorsTableFile, IFormFile certificationOfEventLocationFile, IFormFile lACertificationFile,
            IFormFile allVendorsCertificationsFile, IFormFile allBrochuresFile, IFormFile completeScheduleOfEventsFile, IFormFile waiverReleasesSignedFile,
            IFormFile diagramOrSitePlanFile, IFormFile fiveYearLossHistoryFile, IFormFile evacuationParkAndTrafficPlanDiagramFile)
        {
            string query =
                "Use CS4961;" + "Insert into Permit " +
                "(" +
                "ID, " +

                "FSPermitName," +
                "FSPermitYesOrNo," +
                "FSPermitApproval," +
                "FSPermitDate" +

                ") values " + //Each row equals one permit with name or type of permit, radiobutton value, approval, and signed date
                "(" + id + "," + "\'" + reg.SecurityDepositRow + "\'," + "\'" + reg.SecurityDepositRadio + "\'," +
                "\'" + reg.SecurityDepositApproval + "\'," + "\'" + reg.SecurityDepositSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.BusinessLicenseRow + "\'," + "\'" + reg.BusinessLicenseRadio + "\'," +
                "\'" + reg.BusinessLicenseApproval + "\'," + "\'" + reg.BusinessLicenseSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.DancePermitRow + "\'," + "\'" + reg.DancePermitRadio + "\'," +
                "\'" + reg.DancePermitApproval + "\'," + "\'" + reg.DancePermitSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.EnvironmentalHealthPermitRow + "\'," + "\'" + reg.EnvironmentalHealthPermitRadio + "\'," +
                "\'" + reg.EnvironmentalHealthPermitApproval + "\'," + "\'" + reg.EnvironmentalHealthPermitSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.ABCLicenseRow + "\'," + "\'" + reg.ABCLicenseRadio + "\'," +
                "\'" + reg.ABCLicenseApproval + "\'," + "\'" + reg.ABCLicenseSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.PoliceServicesRow + "\'," + "\'" + reg.PoliceServicesRadio + "\'," +
                "\'" + reg.PoliceServicesApproval + "\'," + "\'" + reg.PoliceServicesSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.AssemblagePermitRow + "\'," + "\'" + reg.AssemblagePermitRadio + "\'," +
                "\'" + reg.AssemblagePermitApproval + "\'," + "\'" + reg.AssemblagePermitSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.SpecialEventPermitRow + "\'," + "\'" + reg.SpecialEventPermitRadio + "\'," +
                "\'" + reg.SpecialEventPermitApproval + "\'," + "\'" + reg.SpecialEventPermitSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.StreetClosureRow + "\'," + "\'" + reg.StreetClosureRadio + "\'," +
                "\'" + reg.StreetClosureApproval + "\'," + "\'" + reg.StreetClosureSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.TentCanopyApprovalRow + "\'," + "\'" + reg.TentCanopyApprovalRadio + "\'," +
                "\'" + reg.TentCanopyApprovalApproval + "\'," + "\'" + reg.TentCanopyApprovalSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.ElectricianServicesRow + "\'," + "\'" + reg.ElectricianServicesRadio + "\'," +
                "\'" + reg.ElectricianServicesApproval + "\'," + "\'" + reg.ElectricianServicesSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.LiquorLicenseRow + "\'," + "\'" + reg.LiquorLicenseRadio + "\'," +
                "\'" + reg.LiquorLicenseApproval + "\'," + "\'" + reg.LiquorLicenseSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.LiabilityInsuranceRow + "\'," + "\'" + reg.LiabilityInsuranceRadio + "\'," +
                "\'" + reg.LiabilityInsuranceApproval + "\'," + "\'" + reg.LiabilityInsuranceSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.SupplierInsuranceRow + "\'," + "\'" + reg.SupplierInsuranceRadio + "\'," +
                "\'" + reg.SupplierInsuranceApproval + "\'," + "\'" + reg.SupplierInsuranceSignedDate + "\'" + ")," +

                "(" + id + "," + "\'" + reg.VendorInsuranceRow + "\'," + "\'" + reg.VendorInsuranceRadio + "\'," +
                "\'" + reg.VendorInsuranceApproval + "\'," + "\'" + reg.VendorInsuranceSignedDate + "\'" + ")" +
                ";";
            return query;
        }

        public string EventTableQueryString(RegisterInformation reg)
        {
            string queryString = "";

            for (int i = 0; i < reg.eventTableRows.Length; i++)
            {
                if (reg.eventTableRows[i].Hours != null && reg.eventTableRows[i].IsAlcoholServed != null && reg.eventTableRows[i].IsAlcoholSold != null)
                {
                    if (i < (reg.eventTableRows.Length))
                    {
                        queryString +=
                        "(" + id + "," + "\'" + reg.eventTableRows[i].Date + "\'," + "\'" + reg.eventTableRows[i].Hours + "\'," +
                        "\'" + reg.eventTableRows[i].Attendance + "\'," + "\'" + reg.eventTableRows[i].IsAlcoholServed + "\'," + "\'" + reg.eventTableRows[i].IsAlcoholSold + "\'" + ")";

                        //if (reg.eventTableRows[i + 1].Hours == null && reg.eventTableRows[i + 1].IsAlcoholServed == null && reg.eventTableRows[i + 1].IsAlcoholSold == null)
                        if(i == reg.eventTableRows.Length - 1)
                        {
                        }
                        else
                        {
                            queryString += ",";
                        }
                    }

                }
            }

            string query = "Use CS4961;" + "Insert into Event " +
                "(" +
                "ID, " +
                "EDate," +
                "EHours," +
                "EAttendance," +
                "EIsAlcoholServed," +
                "EIsAlcoholSold" +

                ") values "
                +

                queryString

                +
                ";";

            return query;
        }

        public string ActivityTableQueryString(RegisterInformation reg)
        {
            string queryString = "";

            for (int i = 0; i < reg.activityTableRows.Length; i++)
            {
                if (reg.activityTableRows[i].Activity != null && reg.activityTableRows[i].Attendance != 0)
                {
                    if (i < reg.activityTableRows.Length)
                    {
                        queryString +=
                        "(" + id + "," + "\'" + reg.activityTableRows[i].Date + "\'," + "\'" + reg.activityTableRows[i].Activity + "\'," +
                        "\'" + reg.activityTableRows[i].Attendance + "\'" + ")";

                        if (i == (reg.activityTableRows.Length - 1))
                        {
                        }
                        else
                        {
                            queryString += ",";
                        }
                    }

                }
            }

            string query = "Use CS4961;" + "Insert into Activity " +
                "(" +
                "ID, " +
                "ADate," +
                "AActivity," +
                "AAttendance" +

                ") values "
                +

                queryString

                +
                ";";

            return query;
        }

        public string MusicTableQueryString(RegisterInformation reg)
        {
            string queryString = "";

            for (int i = 0; i < reg.musicArtistsTableRows.Length; i++)
            {
                if (reg.musicArtistsTableRows[i].Name != null && reg.musicArtistsTableRows[i].Address != null)
                {
                    if (i < reg.musicArtistsTableRows.Length)
                    {
                        queryString +=
                        "(" + id + "," + "\'" + reg.musicArtistsTableRows[i].Name + "\'," + "\'" + reg.musicArtistsTableRows[i].Address + "\'," +
                        "\'" + reg.musicArtistsTableRows[i].PhoneNumber + "\'," + "\'" + reg.musicArtistsTableRows[i].Contact + "\'" + ")";

                        if (i == (reg.musicArtistsTableRows.Length - 1))
                        {
                        }
                        else
                        {
                            queryString += ",";
                        }
                    }

                }
            }

            string query = "Use CS4961;" + "Insert into MusicArtists " +
                "(" +
                "ID, " +
                "MName," +
                "MAddress," +
                "MPhone," +
                "MContact" +

                ") values "
                +

                queryString

                +
                ";";

            return query;
        }

        public string VendorTableQueryString(RegisterInformation reg)
        {
            string queryString = "";

            for (int i = 0; i < reg.vendorTableRows.Length; i++)
            {
                if (reg.vendorTableRows[i].TypeOfService != null && reg.vendorTableRows[i].Name != null && reg.vendorTableRows[i].MailAddress != null)
                {
                    if (i < (reg.vendorTableRows.Length))
                    {
                        queryString +=
                        "(" + id + "," + "\'" + reg.vendorTableRows[i].TypeOfService + "\'," + "\'" + reg.vendorTableRows[i].Name + "\'," + "\'" + reg.vendorTableRows[i].MailAddress + "\'," +
                        "\'" + reg.vendorTableRows[i].City + "\'," + "\'" + reg.vendorTableRows[i].State + "\'," + "\'" + reg.vendorTableRows[i].ZipCode + "\'," + "\'" + reg.vendorTableRows[i].Phone + "\'" + ")";

                        if (i == (reg.vendorTableRows.Length - 1))
                        {
                        }
                        else
                        {
                            queryString += ",";
                        }
                    }

                }
            }

            string query = "Use CS4961;" + "Insert into Vendor " +
                "(" +
                "ID, " +
                "VTypeOfServ," +
                "VName," +
                "VMailingAddress," +
                "VCity," +
                "VState," +
                "VZip," +
                "VPhone" +

                ") values "
                +

                queryString

                +
                ";";

            return query;
        }

        public string ExhibitorTableQueryString(RegisterInformation reg)
        {
            string queryString = "";

            for (int i = 0; i < reg.exhibitorTableRows.Length; i++)
            {
                if (reg.exhibitorTableRows[i].TypeOfService != null && reg.exhibitorTableRows[i].Name != null && reg.exhibitorTableRows[i].MailAddress != null)
                {
                    if (i < (reg.exhibitorTableRows.Length))
                    {
                        queryString +=
                        "(" + id + "," + "\'" + reg.exhibitorTableRows[i].TypeOfService + "\'," + "\'" + reg.exhibitorTableRows[i].Name + "\'," + "\'" + reg.exhibitorTableRows[i].MailAddress + "\'," +
                        "\'" + reg.exhibitorTableRows[i].City + "\'," + "\'" + reg.exhibitorTableRows[i].State + "\'," + "\'" + reg.exhibitorTableRows[i].ZipCode + "\'," + "\'" + reg.exhibitorTableRows[i].Phone + "\'" + ")";

                        if (i == (reg.exhibitorTableRows.Length - 1))
                        {
                        }
                        else
                        {
                            queryString += ",";
                        }
                    }

                }
            }

            string query = "Use CS4961;" + "Insert into Exhibitor " +
                "(" +
                "ID, " +
                "ExTypeofServvice," +
                "ExName," +
                "ExMailingAddress," +
                "ExCity," +
                "ExState," +
                "ExZip," +
                "ExPhone" +

                ") values "
                +

                queryString

                +
                ";";

            return query;
        }

        public string PastEventTableQueryString(RegisterInformation reg)
        {
            string queryString = "";

            for (int i = 0;i < reg.pastEventTableRows.Length; i++)
            {
                if (reg.pastEventTableRows[i].DateOfClaim != null && reg.pastEventTableRows[i].Claimant != null && reg.pastEventTableRows[i].Description != null)
                {
                    if (i < (reg.pastEventTableRows.Length))
                    {
                        queryString +=
                        "(" + id + "," + "\'" + reg.pastEventTableRows[i].DateOfClaim + "\'," + "\'" + reg.pastEventTableRows[i].Claimant + "\'," + "\'" + reg.pastEventTableRows[i].Description + "\'," +
                        "\'" + reg.pastEventTableRows[i].DateOfPaid + "\'," + "\'" + reg.pastEventTableRows[i].TotalIncurred + "\'" + ")";

                        if (i == (reg.pastEventTableRows.Length - 1))
                        {
                        }
                        else
                        {
                            queryString += ",";
                        }
                    }

                }
            }

            string query = "Use CS4961;" + "Insert into PastEvent " +
                "(" +
                "ID, " +
                "PEDateOfClaim," +
                "PEClaimant," +
                "PEDescription," +
                "PEDateOfPaid," +
                "PETotalIncurred" +

                ") values "
                +

                queryString

                +
                ";";

            return query;
        }

        public string StreetClosureTableQueryString(RegisterInformation reg)
        {
            string queryString = "";

            for (int i = 0; i < reg.streetClosureRows.Length; i++)
            {
                if (reg.streetClosureRows[i].StreetName != null && reg.streetClosureRows[i].ZipCode != 0)
                {
                    if (i < (reg.streetClosureRows.Length))
                    {
                        queryString +=
                            "(" + id + "," + "\'" + reg.streetClosureRows[i].StreetName + "\'," + "\'" + reg.streetClosureRows[i].ZipCode + "\'" + ")";

                        if (i == (reg.streetClosureRows.Length - 1))
                        {
                        }
                        else
                        {
                            queryString += ",";
                        }
                    }
                }

            }

            string query = "Use CS4961;" + "Insert into StreetClosure " +
                "(" +
                "ID, " +
                "SCStreetName," +
                "SCZipCode" +

                ") values "
                +

                queryString

                +
                ";";

            return query;
        }
    }
}
