//JS prep complete

/*Notes:

var foo = 'bar';
console.log(`Let's meet at the ${foo}`);
// Let's meet at the bar

*/