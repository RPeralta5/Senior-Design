const fs = require('fs');
fs.writeFileSync("Hello.txt","Hello from Node.js");
// Writes a text document named Hell.txt with "Hellow from Node.js" in it at current location.