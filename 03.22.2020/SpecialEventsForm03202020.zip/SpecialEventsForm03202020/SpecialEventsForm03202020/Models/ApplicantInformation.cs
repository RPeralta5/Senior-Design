﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventsForm03202020.Models
{
    public interface ApplicantInformation
    {
        // ApplicantInformation Form Variables
        public string NameIsAIndividual { get; set; }
        public string NameIsACorporation { get; set; }
        public string NameIsATrustOfEstate { get; set; }
        public string NameIsAUnicorpAssoc { get; set; }
        public string NameIsAGeneralPartnership { get; set; }
        public string NameIsALLCorLLP { get; set; }
        public string NameIsAPublicAgency { get; set; }
        public string NameIsALaborUnion { get; set; }
        public string NameIsAInformalGroup { get; set; }
        public string NameIsALimitedPartnership { get; set; }
        public string NameIsANotForProfit { get; set; }
        public string NameIsARegliousGroup { get; set; }
        public string NameIsAJointVenture { get; set; }

        public string NameIsAOther { get; set; }
        public string NameIsAOtherIs { get; set; }

        public string NameAsAppeared { get; set; }
        public string DoingBusinessAs { get; set; }
        public string MailingAddress { get; set; }
        public string ApplicantCity { get; set; }
        public string ApplicantState { get; set; }
        public int ApplicantZip { get; set; }
        public string ApplicantContact { get; set; }
        public string ApplicantEmail { get; set; }
        public int ApplicantHomePhone { get; set; }
        public int ApplicantBusinessPhone { get; set; }
        public int ApplicantFax { get; set; }
        public string ApplicantWebAddress { get; set; }

    }
}
