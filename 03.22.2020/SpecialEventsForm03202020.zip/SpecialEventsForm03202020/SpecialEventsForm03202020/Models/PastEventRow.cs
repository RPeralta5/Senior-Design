﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventsForm03202020.Models
{
    public class PastEventRow
    {
        public int ID { get; set; }
        public DateTime DateOfClaim { get; set; }
        public string Claimant { get; set; }
        public string Description { get; set; }
        public DateTime DateOfPaid { get; set; }
        public int TotalIncurred { get; set; }
    }
}
