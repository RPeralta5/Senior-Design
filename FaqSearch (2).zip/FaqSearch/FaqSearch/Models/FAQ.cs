﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FaqSearch.Models
{
    public class FAQ
    {
        public string Q { get; set; }
        public string A { get; set; }

        public FAQ(string Question, string Answer)
        {
            this.Q = Question;
            this.A = Answer;
        }
    }


}
