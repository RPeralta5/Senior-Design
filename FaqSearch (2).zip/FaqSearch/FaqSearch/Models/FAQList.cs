﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FaqSearch.Models
{
    public class FAQList
    {
        public List<FAQ> ListArray = new List<FAQ>();
        public static IEnumerable<FAQ> FAQs
        {
            get
            {
                return FAQs;
            }
        }

        public void AddFAQ(FAQ QA)
        {
            ListArray.Add(QA);
        }
    }
}
