﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventFormReviseusingSP01.Models
{
    public class IDandPassword
    {
        public int IDnumber { get; set; }
        public string Passwordstring { get; set; }

        public IDandPassword(string password, int ID)
        {
            this.IDnumber = ID;
            this.Passwordstring = password;
        }
    }
}
