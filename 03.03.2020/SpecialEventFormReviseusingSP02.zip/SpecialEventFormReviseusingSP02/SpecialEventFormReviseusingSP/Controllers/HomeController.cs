﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SpecialEventFormReviseusingSP01.Models;

using System.Data.SqlClient;

namespace SpecialEventFormReviseusingSP01.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public int id = 0;
        public String password = "";
        
        public IActionResult Index()
        {

            //RegisterInformation temp = new RegisterInformation(id, password);

            //ViewBag.Message = string.Format("Your ID # is {0}. Your password is {1}.", id, password);
            //ViewBag.Message = "Your form has been saved." + Environment.NewLine + "Your ID is: " + id + Environment.NewLine + "Your password is: " + password;

            //return FormTurnedIn();
            return View();
        }

        [HttpPost]
        public IActionResult FormTurnedIn( RegisterInformation registerInformation,
            // Parameters are mostly of radio buttons or checkboxes (yes or no) or more than 2 options

            // Important Notice Parameters
            bool Notice

            // Application Information Parameters
            // none

            // Event Information Parameters
            // none

            )
        {
            //////////////////////////////////////////////////////////////////////////////////////////

            // Important Notice Action
            int agree;
            //bool agreee = registerInformation.Agreement;

            if (Notice)
            {
                agree = 1;
            }
            else
            {
                agree = 0;
            }

            if (registerInformation.Password == null && registerInformation.ApplicationID.ToString() == "0")
            {
                var length = 16;
                string charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789`~!@#$%^&*()-_=+[{]}|;:,<.>/?";


                Random rand = new Random();
                for (int i = 0, n = charset.Length; i < length; ++i)
                {
                    password += charset[rand.Next(0, charset.Length - 1)];
                }

            }
            else
            {
                password = registerInformation.Password;
            }

            // SQL Connection String
            string connectionString = @"Data Source=DESKTOP-FSJF92K\JWSQL;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            
            // Important Notice query all here
            string importantNoticeString = "Use CS4961;" + "Insert into ImportantNotice (Password, Agreement) values (\'" + password + "\'," + agree + ");";
            string retrieveString = "Use CS4961;" + "Select Id from ImportantNotice  where password = \'" + password + "\';";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(importantNoticeString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }

                SqlCommand command = new SqlCommand(retrieveString, connection);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    id = (int)reader[0];
                }
                connection.Close();
            }
            //////////////////////////////////////////////////////////////////////////////////////////

            // Applicant Information Action

            // Application Information query all here
            string applicationInformationString = "Use CS4961;" +
                "Insert into ApplicationInformation " +
                "( ID," +
                " AInameInsur1Input," +
                " AInameInsur2Input," +
                " AInameInsur3Input," +
                " AInameInsur4Input," +
                " AInameInsur5Input," +
                " AInameInsur6Input," +
                " AInameInsur7Input," +
                " AInameInsur8Input," +
                " AInameInsur9Input," +
                " AInameInsur10Input," +
                " AInameInsur11Input," +
                " AInameInsur12Input," +
                " AInameInsur13Input," +
                " AInameInsur14Input," +
                " AInameInsuredOther," +
                " AInameOnPolicy," +
                " AIbusinessAs," +
                " AImailAddress," +
                " AIcity," +
                " AIstate," +
                " AIzip," +
                " AIcontactPerson," +
                " AIemail," +
                " AIhomeNum," +
                " AIbusinessNum," +
                " AIfax," +
                " AIwebsite) values (" +
                id + "," +
                "\'" + registerInformation.NameIsAIndividual + "\'," +
                "\'" + registerInformation.NameIsACorporation + "\'," +
                "\'" + registerInformation.NameIsATrustOfEstate + "\'," +
                "\'" + registerInformation.NameIsAUnicorpAssoc + "\'," +
                "\'" + registerInformation.NameIsAGeneralPartnership + "\'," +
                "\'" + registerInformation.NameIsALLCorLLP + "\'," +
                "\'" + registerInformation.NameIsAPublicAgency + "\'," +
                "\'" + registerInformation.NameIsALaborUnion + "\'," +
                "\'" + registerInformation.NameIsAInformalGroup + "\'," +
                "\'" + registerInformation.NameIsALimitedPartnership + "\'," +
                "\'" + registerInformation.NameIsANotForProfit + "\'," +
                "\'" + registerInformation.NameIsARegliousGroup + "\'," +
                "\'" + registerInformation.NameIsAJointVenture + "\'," +
                "\'" + registerInformation.NameIsAOther + "\'," +
                "\'" + registerInformation.NameIsAOtherIs + "\'," +
                "\'" + registerInformation.NameAsAppeared + "\'," +
                "\'" + registerInformation.DoingBusinessAs + "\'," +
                "\'" + registerInformation.MailingAddress + "\'," +
                "\'" + registerInformation.ApplicantCity + "\'," +
                "\'" + registerInformation.ApplicantState + "\'," +
                "\'" + registerInformation.ApplicantZip + "\'," +
                "\'" + registerInformation.ApplicantContact + "\'," +
                "\'" + registerInformation.ApplicantEmail + "\'," +
                "\'" + registerInformation.ApplicantHomePhone + "\'," +
                "\'" + registerInformation.ApplicantBusinessPhone + "\'," +
                "\'" + registerInformation.ApplicantFax + "\'," +
                "\'" + registerInformation.ApplicantWebAddress + "\'" +
                ");";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                using (SqlCommand cmd = new SqlCommand(applicationInformationString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }
            //////////////////////////////////////////////////////////////////////////////////////////

            // Event Information Action


            // Event Information query all here
            string eventInformationString = "Use CS4961;" +
                "Insert into EventInformation" +
                "( ID," +
                "EINameOfEvent," +
                "EIDateEventHeldFile," +
                "EIActivitiesDescription," +
                "EIActivitiesDescriptionFile," +
                "EIBusOwner," +
                "EIBusManager," +
                "EIThirdParty," +
                "EIEventPrivacy," +
                "EIAdmissionCharge," +
                "EIAdmissionCost," +
                "EISellAdmissionTicket," +
                "EISellHowManyTickets," +
                "EITotalTicketSalesAmount," +
                "EIPricePerTicket," +
                "EIHowTicketsSold," +
                "EIWhoSellTickets," +
                "EIDonationExpected," +
                "EIAssignedSeating," +
                "EIOpenSeating," +
                "EIBringYourOwnSeating," +
                "EIBleachersSeating," +
                "EISeatingNotApplicable," +
                "EIPrivateSecurityPersons," +
                "EIPoliceOrSheriffPersons," +
                "EIPeerGroupOrUshersPersons," +
                "EIEmployeesPersons," +
                "EIParentChaperonsPersons," +
                "EIVolunteersPersons," +
                "EISecurityArmed," +
                "EIWandingChecking," +
                "EIFirstAid," +
                "EIFirstAidCompany," +
                "EIReceivedInsuranceCert," +
                "EIADAExit," +
                "EIADAParking," +
                "EIEventAdvertising," +
                "EIAdvertiseByWeb," +
                "EIAdvertisementWebsite," +
                "EIEventIsOnTelevision," +
                "EIEventIsOnRadio," +
                "EIEventIsOnNewspaper," +
                "EIEventIsOnBrochure," +
                "EIEventIsOnHandout," +
                "EIEventIsOnBillboard," +
                "EIEventIsOnPoster," +
                "EIEventIsOnOther," +
                "EIIsAlcoholServed," +
                "EIIsAlcoholSold," +
                "EIIsEventCharged," +
                "EIIsEventPayToAttend," +
                "EIIsEventReceiveDonation," +
                "EIIsThereBeer," +
                "EIIsThereWineOrChampagne," +
                "EIIsThereMixedOrBar," +
                "EIIsThereAlcoholVendor," +
                "EIIsThereAlcoholVendingInsurance," +
                "EIEstimatedAlcoholSales," +
                "EINumberOfAlcoholLocations," +
                "EIIsLiquorLicenseRequired," +
                "EIMustLiquorBeDrankInArea," +
                "EINeedIdToRecieveLiquor," +
                "EIOverAgeDrinkerHaveOtherID," +
                "EIIsThereLimitTwoServingLiquor," +
                "EIIsThereLiquorStaffMonitoring," +
                "EIIsLiquorBarClosedTwoHrsEarly," +
                "EIHasAthleticOrRecreationalActivity," +
                "EIWaiverLiabilityProcedure," +
                "EILiabilityReleaseFile," +
                "EIHasMusic," +
                "EIIsThereLiveMusic," +
                "EIIsThereDiskJockey," +
                "EIIsThereStereoCDPlayer," +
                "EIAmplifiedSound," +
                "EIHowManyArtists," +
                "EIOwnElectricity," +
                "EIArrangements," +
                "EIOtherEntertainment," +
                "EIDescribeOtherEntertainment," +
                "EIJumpsTanksTrains," +
                "EICompanyHired," +
                "EIFollowingActivitiesFile," +
                "EIWaiverDescription" +
                ") values (" +
                id + "," +
                "\'" + registerInformation.EventName + "\'," +
                "\'" + registerInformation.EventFile + "\'," +
                "\'" + registerInformation.ActivitiesDescription + "\'," +
                "\'" + registerInformation.ActivitiesDescriptionFile + "\'," +
                "\'" + registerInformation.InsuredIsOwner + "\'," +
                "\'" + registerInformation.InsuredIsManager + "\'," +
                "\'" + registerInformation.InsuredIsThirdParty + "\'," +
                "\'" + registerInformation.EventIsPrivacy + "\'," +
                "\'" + registerInformation.AdmissionCharge + "\'," +
                "\'" + registerInformation.AdmissionCost + "\'," +
                "\'" + registerInformation.SellTicket + "\'," +
                "\'" + registerInformation.SellHowManyTickets + "\'," +
                "\'" + registerInformation.TotalTicketSalesAmount + "\'," +
                "\'" + registerInformation.PricePerTicket + "\'," +
                "\'" + registerInformation.HowToSellTicket + "\'," +
                "\'" + registerInformation.WhoSellTickets + "\'," +
                "\'" + registerInformation.RecieveDonate + "\'," +
                "\'" + registerInformation.SeatType1 + "\'," +
                "\'" + registerInformation.SeatType2 + "\'," +
                "\'" + registerInformation.SeatType3 + "\'," +
                "\'" + registerInformation.SeatType4 + "\'," +
                "\'" + registerInformation.SeatType5 + "\'," +
                "\'" + registerInformation.NumOfPrivateSecurityPersons + "\'," +
                "\'" + registerInformation.NumOfPoliceOrSheriffPersons + "\'," +
                "\'" + registerInformation.NumOfPeerGroupOrUshersPersons + "\'," +
                "\'" + registerInformation.NumOfEmployeesPersons + "\'," +
                "\'" + registerInformation.NumOfParentChaperonsPersons + "\'," +
                "\'" + registerInformation.NumOfVolunteersPersons + "\'," +
                "\'" + registerInformation.Armed + "\'," +
                "\'" + registerInformation.BagCheck + "\'," +
                "\'" + registerInformation.FirstAid + "\'," +
                "\'" + registerInformation.CompanyForFirstAide + "\'," +
                "\'" + registerInformation.RecievedInsurance + "\'," +
                "\'" + registerInformation.EntranceExit + "\'," +
                "\'" + registerInformation.AccessibleParking + "\'," +
                "\'" + registerInformation.EventAdvertise + "\'," +
                "\'" + registerInformation.EventIsOnWebsite + "\'," +
                "\'" + registerInformation.EventWebsite + "\'," +
                "\'" + registerInformation.EventTelevised + "\'," +
                "\'" + registerInformation.EventRadio + "\'," +
                "\'" + registerInformation.EventNewsPaper + "\'," +
                "\'" + registerInformation.EventBrochure + "\'," +
                "\'" + registerInformation.EventHandOut + "\'," +
                "\'" + registerInformation.EventBillBoard + "\'," +
                "\'" + registerInformation.EventPoster + "\'," +
                "\'" + registerInformation.EventOther + "\'," +
                "\'" + registerInformation.AlcoholServe + "\'," +
                "\'" + registerInformation.AlcoholIsSold + "\'," +
                "\'" + registerInformation.AlcoholFee + "\'," +
                "\'" + registerInformation.EventFee + "\'," +
                "\'" + registerInformation.EventDonation + "\'," +
                "\'" + registerInformation.AlcoholType1 + "\'," +
                "\'" + registerInformation.AlcoholType2 + "\'," +
                "\'" + registerInformation.AlcoholType3 + "\'," +
                "\'" + registerInformation.AlcoholVending + "\'," +
                "\'" + registerInformation.AlcoholVendingInsurance + "\'," +
                "\'" + registerInformation.EstimatedAlcoholSales + "\'," +
                "\'" + registerInformation.NumOfAlcoholLocations + "\'," +
                "\'" + registerInformation.LiquorLicense + "\'," +
                "\'" + registerInformation.LiquorDrinkArea + "\'," +
                "\'" + registerInformation.LiquorIdentification + "\'," +
                "\'" + registerInformation.DrinkingAge + "\'," +
                "\'" + registerInformation.LiquorServingLimit + "\'," +
                "\'" + registerInformation.LiquorStaffMonitor + "\'," +
                "\'" + registerInformation.LiquorBarClose + "\'," +
                "\'" + registerInformation.AthleticRecreationalActivity + "\'," +
                "\'" + registerInformation.WaiverAndLiabilityProcedure + "\'," +
                "\'" + registerInformation.LiabilityReleaseFile + "\'," +
                "\'" + registerInformation.HaveMusic + "\'," +
                "\'" + registerInformation.TypeOfMusic1 + "\'," +
                "\'" + registerInformation.TypeOfMusic2 + "\'," +
                "\'" + registerInformation.TypeOfMusic3 + "\'," +
                "\'" + registerInformation.AmplifiedMusic + "\'," +
                "\'" + registerInformation.NumOfBandsOrArtists + "\'," +
                "\'" + registerInformation.OwnElectricity + "\'," +
                "\'" + registerInformation.ElectricityArranging + "\'," +
                "\'" + registerInformation.OtherEntertainment + "\'," +
                "\'" + registerInformation.OtherEntertainmentDescription + "\'," +
                "\'" + registerInformation.ActivityStuff + "\'," +
                "\'" + registerInformation.HiredCompanyForActivities + "\'," +
                "\'" + registerInformation.FollowingActivitiesFile + "\'," +
                "\'" + registerInformation.ExplainProcedureForWaivers + "\'" +
                ");";
            




            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(eventInformationString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////////

            // Music Types Action


            // Music Types query all here
            string musicTypesString = "Use CS4961;" + "Insert into MusicTypes " +
                "(" +
                "ID, " +
                "IsThereAcidRock," +
                "IsThereAlternative, " +
                "IsThereBigBand," +
                "IsThereBlues, " +
                "IsThereChristian," +
                "IsThereClassical, " +
                "IsThereCountrySoul," +
                "IsThereCountryRock, " +
                "IsThereDeathRock," +
                "IsThereDisco, " +
                "IsThereContemporary," +
                "IsThereEthnicNForeignCultural, " +
                "IsThere1950sN1960s," +
                "IsThereFunk, " +
                "IsThereHardRock," +
                "IsThereHipHop, " +
                "IsThereJazz," +
                "IsTherePop, " +
                "IsThereRap," +
                "IsThereReggae, " +
                "IsThereSoftRock," +
                "IsThereSoul, " +
                "IsThereSymphony," +
                "IsThereSwing, " +
                "IsThereHeavyMetal," +
                "IsThereFolk, " +
                "IsThereGoth," +
                "IsThereGothMetal, " +
                "IsThereGospel," +
                "IsThereIndustrial, " +
                "IsTherePsychedelic," +
                "IsTherePunk, " +
                "IsThereRave," +
                "IsThereSka, " +
                "IsThereTechno," +
                "IsThereBubblegum, " +
                "IsThereRockability, " +
                "IsThereOther," +
                "IsThereOtherDescription" +

                ") values (" +
                id + "," +
                "\'" + registerInformation.MusicType1 + "\'," +
                "\'" + registerInformation.MusicType2 + "\'," +
                "\'" + registerInformation.MusicType3 + "\'," +
                "\'" + registerInformation.MusicType4 + "\'," +
                "\'" + registerInformation.MusicType5 + "\'," +
                "\'" + registerInformation.MusicType6 + "\'," +
                "\'" + registerInformation.MusicType7 + "\'," +
                "\'" + registerInformation.MusicType8 + "\'," +
                "\'" + registerInformation.MusicType9 + "\'," +
                "\'" + registerInformation.MusicType10 + "\'," +
                "\'" + registerInformation.MusicType11 + "\'," +
                "\'" + registerInformation.MusicType12 + "\'," +
                "\'" + registerInformation.MusicType13 + "\'," +
                "\'" + registerInformation.MusicType14 + "\'," +
                "\'" + registerInformation.MusicType15 + "\'," +
                "\'" + registerInformation.MusicType16 + "\'," +
                "\'" + registerInformation.MusicType17 + "\'," +
                "\'" + registerInformation.MusicType18 + "\'," +
                "\'" + registerInformation.MusicType19 + "\'," +
                "\'" + registerInformation.MusicType20 + "\'," +
                "\'" + registerInformation.MusicType21 + "\'," +
                "\'" + registerInformation.MusicType22 + "\'," +
                "\'" + registerInformation.MusicType23 + "\'," +
                "\'" + registerInformation.MusicType24 + "\'," +
                "\'" + registerInformation.MusicType25 + "\'," +
                "\'" + registerInformation.MusicType26 + "\'," +
                "\'" + registerInformation.MusicType27 + "\'," +
                "\'" + registerInformation.MusicType28 + "\'," +
                "\'" + registerInformation.MusicType29 + "\'," +
                "\'" + registerInformation.MusicType30 + "\'," +
                "\'" + registerInformation.MusicType31 + "\'," +
                "\'" + registerInformation.MusicType32 + "\'," +
                "\'" + registerInformation.MusicType33 + "\'," +
                "\'" + registerInformation.MusicType34 + "\'," +
                "\'" + registerInformation.MusicType35 + "\'," +
                "\'" + registerInformation.MusicType36 + "\'," +
                "\'" + registerInformation.MusicType37 + "\'," +
                "\'" + registerInformation.MusicType38 + "\'," +
                "\'" + registerInformation.OtherTypeOfMusic + "\'" +

                ");";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(musicTypesString, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }
            //////////////////////////////////////////////////////////////////////////////////////////

            // FolowingActivities1 Action


            // FolowingActivities1 query all here
            string followingActivities1String = "Use CS4961;" + "Insert into IncludeFollowingActivities1 " +
                "(" +

                "ID, " +
                "IsThereClimbing," +
                "IsThereSkateBoard, " +
                "IsThereRoller," +
                "IsThereCycling, " +
                "IsThereWatercraft," +
                "IsThereGun, " +
                "IsThereFire," +
                "IsThereArmory, " +
                "IsThereChemical," +
                "IsThereMedical, " +
                "IsThereConstructOrDemo," +
                "IsThereScaffoldAbove4Ft " +

                ") values (" +

                id + "," +
                "\'" + registerInformation.ClimbWall + "\'," +
                "\'" + registerInformation.SkateBoard + "\'," +
                "\'" + registerInformation.RollerAct + "\'," +
                "\'" + registerInformation.CycleAct + "\'," +
                "\'" + registerInformation.WaterAct + "\'," +
                "\'" + registerInformation.GunAct + "\'," +
                "\'" + registerInformation.FireAct + "\'," +
                "\'" + registerInformation.ArmoryAct + "\'," +
                "\'" + registerInformation.ChemicalAct + "\'," +
                "\'" + registerInformation.MedicalAct + "\'," +
                "\'" + registerInformation.DemolitionAct + "\'," +
                "\'" + registerInformation.ScaffoldingfAct + "\'" +

                ");";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(followingActivities1String, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }
            //////////////////////////////////////////////////////////////////////////////////////////
            // FolowingActivities2 Action

            // FolowingActivities2 query all here
            string followingActivities2String = "Use CS4961;" + "Insert into IncludeFollowingActivities2 " +
                "(" +

                "ID, " +
                "HasAirRides," +
                "HasTerrainBoarding, " +
                "HasBaseJumping," +
                "HasBouldering, " +
                "HasBoxingMartialArts," +
                "HasBungeeJumping, " +
                "HasCircusCarnival," +
                "HasConcertsOver6Hrs, " +
                "HasConcertwithMoshPit," +
                "HasPlatformBoardDiving, " +
                "HasHangGliding," +
                "HasKayakRaftCanoe," +
                "HasMechanicalRide," +
                "HasMotorSport," +
                "HasMountainBiking," +
                "HasPowerBoats," +
                "HasProSportCashPrizeGames," +
                "HasPyroAndFire," +
                "HasRapHeavyMetalConcert," +
                "HasRockClimbing," +
                "HasRodeoAndRoping," +
                "HasSkinDiving," +
                "HasScubaDiving," +
                "HasTractorTruckPull," +
                "HasTrampoline " +

                ") values (" +

                id + "," +
                "\'" + registerInformation.AirRiding + "\'," +
                "\'" + registerInformation.TerrainBoarding + "\'," +
                "\'" + registerInformation.BaseJumping + "\'," +
                "\'" + registerInformation.Bouldering + "\'," +
                "\'" + registerInformation.BoxingMaritalArts + "\'," +
                "\'" + registerInformation.BungeeAct + "\'," +
                "\'" + registerInformation.CircusCarnival + "\'," +
                "\'" + registerInformation.Concert6HrAct + "\'," +
                "\'" + registerInformation.ConcertDanceAct + "\'," +
                "\'" + registerInformation.PlatformBoardDiving + "\'," +
                "\'" + registerInformation.HangGliding + "\'," +
                "\'" + registerInformation.KayalRaftCanoeing + "\'," +
                "\'" + registerInformation.MechanicalRide + "\'," +
                "\'" + registerInformation.MotorSportEquipment + "\'," +
                "\'" + registerInformation.MountainBiking + "\'," +
                "\'" + registerInformation.PowerBoats + "\'," +
                "\'" + registerInformation.ProSportCash + "\'," +
                "\'" + registerInformation.PyroFireAct + "\'," +
                "\'" + registerInformation.RapRockConcert + "\'," +
                "\'" + registerInformation.RockClimbAct + "\'," +
                "\'" + registerInformation.RodeoRopeAct + "\'," +
                "\'" + registerInformation.SkinDiveAct + "\'," +
                "\'" + registerInformation.ScubaDiveAct + "\'," +
                "\'" + registerInformation.TractorTruckPull + "\'," +
                "\'" + registerInformation.Trampoline + "\'" +

                ");";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(followingActivities2String, connection))
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }
            //////////////////////////////////////////////////////////////////////////////////////////

            RegisterInformation temp = new RegisterInformation(id, password);
            ArrayOfRegistry array = new ArrayOfRegistry();
            array.AddRegistry(temp);

            ViewBag.temporary = array;
            return View(array);
        }
        



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }



    }
}
