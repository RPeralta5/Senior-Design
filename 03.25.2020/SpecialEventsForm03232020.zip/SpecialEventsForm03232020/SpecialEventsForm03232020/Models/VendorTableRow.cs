﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventsForm03232020.Models
{
    public class VendorTableRow
    {
        public int ID { get; set; }
        public string TypeOfService { get; set; }
        public string Name { get; set; }
        public string MailAddress { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        [DataType(DataType.PostalCode)]
        public int ZipCode { get; set; }
        [DataType(DataType.PhoneNumber)]
        public int Phone { get; set; }
    }
}
