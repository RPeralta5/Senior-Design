﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LAParks2.Models
{
    public class FAQTable
    {
        public static List<FAQ> FAQlist = new List<FAQ>();
        public static IEnumerable<FAQ> FAQs
        {
            get
            {
                return FAQs;
            }
        }

        public void AddFAQ(FAQ QA)
        {
            FAQlist.Add(QA);
        }
    }
}
