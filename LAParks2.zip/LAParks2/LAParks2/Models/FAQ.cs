﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LAParks2.Models
{
    public class FAQ
    {
        public string Question { get; set; }
        public string Answer { get; set; }
        public int ID{get; set; }

        public FAQ( int id, string q, string a)
        {
            this.Question = q;
            this.Answer = a;
            this.ID = id;
        }
        public FAQ() { }
    }


}
