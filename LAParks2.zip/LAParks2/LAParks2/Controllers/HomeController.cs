﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using LAParks2.Models;
using System.Data.SqlClient;

namespace LAParks2.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }




        //Get and Set for FAQ Form
        /*[HttpGet] 
        public ViewResult FAQ()
        {
            return View();
        }
        [HttpPost]
        */
        
        public ViewResult FAQ(Models.FAQ faq)
        {
            string connectionString = @"Data Source=DESKTOP-FSJF92K\JWSQL;Initial Catalog=cs4961;Integrated Security=True";
            string queryString = "select * from FAQ;";

            FAQTable store = new FAQTable();
            using (SqlConnection connection = new SqlConnection(
            connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(queryString, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    store.AddFAQ(new FAQ((int)reader[0], (string)reader[1],(string)reader[2]));
                }
            }

            ViewBag.listing = store;
  
            return View("FAQ");
        }




        /*


        public IActionResult FAQ()
        {
            return View();
        }
        */

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }
        public IActionResult Privacy()
        {
            return View();
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
