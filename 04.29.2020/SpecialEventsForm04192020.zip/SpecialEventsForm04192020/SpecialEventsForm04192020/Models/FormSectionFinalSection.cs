﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventsForm04192020.Models
{
    public class FormSectionFinalSection
    {
        // Final Section Form Variables
        public string ApplicantSignature { get; set; }
        public string ApplicantTitle { get; set; }
        public string ApplicationDate { get; set; }
        public string SupervisorInitials { get; set; }
        public string AssemblingsPermitSignedDate { get; set; }

        // Separate Table: Permit //Variables with "Row" already have a value given at construction time
        public string SecurityDepositRow { get; set; }
        public string SecurityDepositRadio { get; set; }
        public string SecurityDepositApproval { get; set; }
        public string SecurityDepositSignedDate { get; set; }

        public string BusinessLicenseRow { get; set; }
        public string BusinessLicenseRadio { get; set; }
        public string BusinessLicenseApproval { get; set; }
        public string BusinessLicenseSignedDate { get; set; }

        public string DancePermitRow { get; set; }
        public string DancePermitRadio { get; set; }
        public string DancePermitApproval { get; set; }
        public string DancePermitSignedDate { get; set; }

        public string EnvironmentalHealthPermitRow { get; set; }
        public string EnvironmentalHealthPermitRadio { get; set; }
        public string EnvironmentalHealthPermitApproval { get; set; }
        public string EnvironmentalHealthPermitSignedDate { get; set; }

        public string ABCLicenseRow { get; set; }
        public string ABCLicenseRadio { get; set; }
        public string ABCLicenseApproval { get; set; }
        public string ABCLicenseSignedDate { get; set; }

        public string PoliceServicesRow { get; set; }
        public string PoliceServicesRadio { get; set; }
        public string PoliceServicesApproval { get; set; }
        public string PoliceServicesSignedDate { get; set; }

        public string AssemblagePermitRow { get; set; }
        public string AssemblagePermitRadio { get; set; }
        public string AssemblagePermitApproval { get; set; }
        public string AssemblagePermitSignedDate { get; set; }

        public string SpecialEventPermitRow { get; set; }
        public string SpecialEventPermitRadio { get; set; }
        public string SpecialEventPermitApproval { get; set; }
        public string SpecialEventPermitSignedDate { get; set; }

        public string StreetClosureRow { get; set; }
        public string StreetClosureRadio { get; set; }
        public string StreetClosureApproval { get; set; }
        public string StreetClosureSignedDate { get; set; }

        public string TentCanopyApprovalRow { get; set; }
        public string TentCanopyApprovalRadio { get; set; }
        public string TentCanopyApprovalApproval { get; set; }
        public string TentCanopyApprovalSignedDate { get; set; }

        public string ElectricianServicesRow { get; set; }
        public string ElectricianServicesRadio { get; set; }
        public string ElectricianServicesApproval { get; set; }
        public string ElectricianServicesSignedDate { get; set; }

        public string LiquorLicenseRow { get; set; }
        public string LiquorLicenseRadio { get; set; }
        public string LiquorLicenseApproval { get; set; }
        public string LiquorLicenseSignedDate { get; set; }

        public string LiabilityInsuranceRow { get; set; }
        public string LiabilityInsuranceRadio { get; set; }
        public string LiabilityInsuranceApproval { get; set; }
        public string LiabilityInsuranceSignedDate { get; set; }

        public string SupplierInsuranceRow { get; set; }
        public string SupplierInsuranceRadio { get; set; }
        public string SupplierInsuranceApproval { get; set; }
        public string SupplierInsuranceSignedDate { get; set; }

        public string VendorInsuranceRow { get; set; }
        public string VendorInsuranceRadio { get; set; }
        public string VendorInsuranceApproval { get; set; }
        public string VendorInsuranceSignedDate { get; set; }
    }
}
