﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventsForm04192020.Models
{
    public class RegisterInformation
    {
        public RegisterInformation()
        {
            //Permit row labels

            SecurityDepositRow = "Security Deposit/Fee";
            BusinessLicenseRow = "Business License";
            DancePermitRow = "Dance Permit Required";
            EnvironmentalHealthPermitRow = "Environmental Health Permit";
            ABCLicenseRow = "ABC License";
            PoliceServicesRow = "Police Services";
            AssemblagePermitRow = "Assemblage Permit";
            SpecialEventPermitRow = "Specific Event Permit";
            StreetClosureRow = "Street Closure";
            TentCanopyApprovalRow = "Tent/Canopy Approval";
            ElectricianServicesRow = "Electrician Services";
            LiquorLicenseRow = "Liquor Liability Insurance";
            LiabilityInsuranceRow = "Event Liability Insurance";
            SupplierInsuranceRow = "Suppliers Insurance";
            VendorInsuranceRow = "Vendors Insurance";

        }
        public RegisterInformation(int id, string pw)
        {
            this.ApplicationID = id;
            this.Password = pw;

            //Permit row labels

            SecurityDepositRow = "Security Deposit/Fee";
            BusinessLicenseRow = "Business License";
            DancePermitRow = "Dance Permit Required";
            EnvironmentalHealthPermitRow = "Environmental Health Permit";
            ABCLicenseRow = "ABC License";
            PoliceServicesRow = "Police Services";
            AssemblagePermitRow = "Assemblage Permit";
            SpecialEventPermitRow = "Specific Event Permit ❑";
            StreetClosureRow = "Street Closure";
            TentCanopyApprovalRow = "Tent/Canopy Approval ❑";
            ElectricianServicesRow = "Electrician Services";
            LiquorLicenseRow = "Liquor Liability Insurance";
            LiabilityInsuranceRow = "Event Liability Insurance";
            SupplierInsuranceRow = "Suppliers Insurance";
            VendorInsuranceRow = "Vendors Insurance";

        }

        public RegisterInformation(int id, string pw, int applicationFinished)
        {
            this.ApplicationID = id;
            this.Password = pw;
            this.ApplicationFinished = applicationFinished;

            //Permit row labels

            SecurityDepositRow = "Security Deposit/Fee";
            BusinessLicenseRow = "Business License";
            DancePermitRow = "Dance Permit Required";
            EnvironmentalHealthPermitRow = "Environmental Health Permit";
            ABCLicenseRow = "ABC License";
            PoliceServicesRow = "Police Services";
            AssemblagePermitRow = "Assemblage Permit";
            SpecialEventPermitRow = "Specific Event Permit ❑";
            StreetClosureRow = "Street Closure";
            TentCanopyApprovalRow = "Tent/Canopy Approval ❑";
            ElectricianServicesRow = "Electrician Services";
            LiquorLicenseRow = "Liquor Liability Insurance";
            LiabilityInsuranceRow = "Event Liability Insurance";
            SupplierInsuranceRow = "Suppliers Insurance";
            VendorInsuranceRow = "Vendors Insurance";

        }

        // Important Notice Form Variables
        public int ApplicationID { get; set; }
        public string Password { get; set; }
        public string Agreement { get; set; }
        public int ApplicationFinished { get; set; }

        public FormSectionImportantNotice importantNotice { get; set; }

        // ApplicantInformation Form Variables
        public string NameIsAIndividual { get; set; }
        public string NameIsACorporation { get; set; }
        public string NameIsATrustOfEstate { get; set; }
        public string NameIsAUnicorpAssoc { get; set; }
        public string NameIsAGeneralPartnership { get; set; }
        public string NameIsALLCorLLP { get; set; }
        public string NameIsAPublicAgency { get; set; }
        public string NameIsALaborUnion { get; set; }
        public string NameIsAInformalGroup { get; set; }
        public string NameIsALimitedPartnership { get; set; }
        public string NameIsANotForProfit { get; set; }
        public string NameIsARegliousGroup { get; set; }
        public string NameIsAJointVenture { get; set; }

        public string NameIsAOther { get; set; }
        public string NameIsAOtherIs { get; set; } // This is for textbox

        public string NameAsAppeared { get; set; }
        public string DoingBusinessAs { get; set; }
        public string MailingAddress { get; set; }
        public string ApplicantCity { get; set; }
        public string ApplicantState { get; set; }
        public string ApplicantZip { get; set; }
        public string ApplicantContact { get; set; }
        public string ApplicantEmail { get; set; }
        public string ApplicantHomePhone { get; set; }
        public string ApplicantBusinessPhone { get; set; }
        public string ApplicantFax { get; set; }
        public string ApplicantWebAddress { get; set; }

        // Event Information Form Variables
        public string EventName { get; set; }
        public string ActivitiesDescription { get; set; }

        // insured name or company
        public string InsuredIsOwner { get; set; }
        public string InsuredIsManager { get; set; }
        public string InsuredIsThirdParty { get; set; }
        public string EventIsPrivacy { get; set; }

        // admission and ticket
        public string AdmissionCharge { get; set; }
        public string AdmissionCost { get; set; }
        public string SellTicket { get; set; }
        public string SellHowManyTickets { get; set; }
        public string TotalTicketSalesAmount { get; set; }
        public string PricePerTicket { get; set; }
        public string HowToSellTicket { get; set; }
        public string WhoSellTickets { get; set; }
        public string RecieveDonate { get; set; }

        // type of seating
        public string SeatType1 { get; set; }
        public string SeatType2 { get; set; }
        public string SeatType3 { get; set; }
        public string SeatType4 { get; set; }
        public string SeatType5 { get; set; }

        // security
        public string NumOfPrivateSecurityPersons { get; set; }
        public string NumOfPoliceOrSheriffPersons { get; set; }
        public string NumOfPeerGroupOrUshersPersons { get; set; }
        public string NumOfEmployeesPersons { get; set; }
        public string NumOfParentChaperonsPersons { get; set; }
        public string NumOfVolunteersPersons { get; set; }

        // safety and insurance
        public string Armed { get; set; }
        public string BagCheck { get; set; }
        public string FirstAid { get; set; }
        public string CompanyForFirstAide { get; set; }
        public string RecievedInsurance { get; set; }

        // parking
        public string EntranceExit { get; set; }
        public string AccessibleParking { get; set; }

        // event
        public string EventAdvertise { get; set; }
        public string EventIsOnWebsite { get; set; }
        public string EventWebsite { get; set; }
        public string EventTelevised { get; set; }
        public string EventRadio { get; set; }
        public string EventNewsPaper { get; set; }
        public string EventBrochure { get; set; }
        public string EventHandOut { get; set; }
        public string EventBillBoard { get; set; }
        public string EventPoster { get; set; }
        public string EventOther { get; set; }

        // alcohol information
        public string AlcoholServe { get; set; }
        public string AlcoholIsSold { get; set; }
        public string AlcoholFee { get; set; }

        // event finance
        public string EventFee { get; set; }
        public string EventDonation { get; set; }

        // alcohol type
        public string AlcoholType1 { get; set; }
        public string AlcoholType2 { get; set; }
        public string AlcoholType3 { get; set; }

        // alcohol vending
        public string AlcoholVending { get; set; }
        public string AlcoholVendingInsurance { get; set; }
        public string EstimatedAlcoholSales { get; set; }
        public string NumOfAlcoholLocations { get; set; }
        public string LiquorLicense { get; set; }
        public string LiquorDrinkArea { get; set; }
        public string LiquorIdentification { get; set; }
        public string DrinkingAge { get; set; }
        public string LiquorServingLimit { get; set; }
        public string LiquorStaffMonitor { get; set; }
        public string LiquorBarClose { get; set; }

        // activity and liability
        public string AthleticRecreationalActivity { get; set; }
        public string WaiverAndLiabilityProcedure { get; set; }

        //  music
        public string HaveMusic { get; set; }
        public string TypeOfMusic1 { get; set; } //Under Testing
        public string TypeOfMusic2 { get; set; } //Under Testing
        public string TypeOfMusic3 { get; set; } //Under Testing
        public string AmplifiedMusic { get; set; }
        public string NumOfBandsOrArtists { get; set; }

        // power and electricity
        public string OwnElectricity { get; set; }
        public string ElectricityArranging { get; set; }

        // entertainment
        public string OtherEntertainment { get; set; }
        public string OtherEntertainmentDescription { get; set; }

        // activities options
        public string ActivityStuff { get; set; }
        public string HiredCompanyForActivities { get; set; }
        public string ExplainProcedureForWaivers { get; set; }

        // Separate Table: type of music played 

        public string MusicType1 { get; set; }
        public string MusicType2 { get; set; }
        public string MusicType3 { get; set; }
        public string MusicType4 { get; set; }
        public string MusicType5 { get; set; }
        public string MusicType6 { get; set; }
        public string MusicType7 { get; set; }
        public string MusicType8 { get; set; }
        public string MusicType9 { get; set; }
        public string MusicType10 { get; set; }
        public string MusicType11 { get; set; }
        public string MusicType12 { get; set; }
        public string MusicType13 { get; set; }
        public string MusicType14 { get; set; }
        public string MusicType15 { get; set; }
        public string MusicType16 { get; set; }
        public string MusicType17 { get; set; }
        public string MusicType18 { get; set; }
        public string MusicType19 { get; set; }
        public string MusicType20 { get; set; }
        public string MusicType21 { get; set; }
        public string MusicType22 { get; set; }
        public string MusicType23 { get; set; }
        public string MusicType24 { get; set; }
        public string MusicType25 { get; set; }
        public string MusicType26 { get; set; }
        public string MusicType27 { get; set; }
        public string MusicType28 { get; set; }
        public string MusicType29 { get; set; }
        public string MusicType30 { get; set; }
        public string MusicType31 { get; set; }
        public string MusicType32 { get; set; }
        public string MusicType33 { get; set; }
        public string MusicType34 { get; set; }
        public string MusicType35 { get; set; }
        public string MusicType36 { get; set; }
        public string MusicType37 { get; set; }
        public string MusicType38 { get; set; }
        public string OtherTypeOfMusic { get; set; }

        // Separate Table: FollowingActivities1 Included

        public string ClimbWall { get; set; }
        public string SkateBoard { get; set; }
        public string RollerAct { get; set; }
        public string CycleAct { get; set; }
        public string WaterAct { get; set; }
        public string GunAct { get; set; }
        public string FireAct { get; set; }
        public string ArmoryAct { get; set; }
        public string ChemicalAct { get; set; }
        public string MedicalAct { get; set; }
        public string DemolitionAct { get; set; }
        public string ScaffoldingfAct { get; set; }

        // Separate Table: FollowingActivities2 Included

        public string AirRiding { get; set; }
        public string TerrainBoarding { get; set; }
        public string BaseJumping { get; set; }
        public string Bouldering { get; set; }
        public string BoxingMaritalArts { get; set; }
        public string BungeeAct { get; set; }
        public string CircusCarnival { get; set; }
        public string Concert6HrAct { get; set; }
        public string ConcertDanceAct { get; set; }
        public string PlatformBoardDiving { get; set; }
        public string HangGliding { get; set; }
        public string KayalRaftCanoeing { get; set; }
        public string MechanicalRide { get; set; }
        public string MotorSportEquipment { get; set; }
        public string MountainBiking { get; set; }
        public string PowerBoats { get; set; }
        public string ProSportCash { get; set; }
        public string PyroFireAct { get; set; }
        public string RapRockConcert { get; set; }
        public string RockClimbAct { get; set; }
        public string RodeoRopeAct { get; set; }
        public string SkinDiveAct { get; set; }
        public string ScubaDiveAct { get; set; }
        public string TractorTruckPull { get; set; }
        public string Trampoline { get; set; }

        // Event Location Form Variables
        public string FacilityName { get; set; }
        public string FacilityStreetName { get; set; }
        public string FacilityCity { get; set; }
        public string FacilityState { get; set; }
        public string FacilityZip { get; set; }
        public string OutdoorAreaSize { get; set; }
        public string OutdoorAreaInsured { get; set; }
        public string IsVendorSellingAlcohol { get; set; }

        public string HeldBefore { get; set; }
        public string EvacuationPlan { get; set; }
        public string EvacuationPlanDescription { get; set; }
        public string IsThereMedicalPresence { get; set; }
        public string NumOfDoctors { get; set; }
        public string NumOfParamedics { get; set; }
        public string NumOfNurses { get; set; }
        public string NumOfEMTOrEMS { get; set; }
        public string NumOfOther { get; set; }
        public string AmbulanceOnSite { get; set; }

        public string StreetClosure { get; set; }
        public string TrafficMitigation { get; set; }
        public string TrafficMitigationDescription { get; set; }


        // Files from all forms are here

        // All files for Event Information
        public IFormFile EventDateFile { get; set; }
        public IFormFile ActivitiesDescriptionFile { get; set; }
        public IFormFile FollowingActivitiesFile { get; set; }
        public IFormFile LiabilityReleaseFile { get; set; }

        // All files for Event Location
        public IFormFile VendorsTableFile { get; set; }
        public IFormFile ExhibitorsTableFile { get; set; }
        public IFormFile CertificationOfEventLocationFile { get; set; }

        public IFormFile LACertificationFile { get; set; }
        public IFormFile AllVendorsCertificationsFile { get; set; }
        public IFormFile AllBrochuresFile { get; set; }
        public IFormFile CompleteScheduleOfEventsFile { get; set; }
        public IFormFile WaiverReleasesSignedFile { get; set; }
        public IFormFile DiagramOrSitePlanFile { get; set; }
        public IFormFile FiveYearLossHistoryFile { get; set; }
        public IFormFile EvacuationParkAndTrafficPlanDiagramFile { get; set; }

        //Files retrieve from database

        public string EventDateFileLabel { get; set; }
        public string ActivitiesDescriptionFileLabel { get; set; }
        public string LiabilityReleaseFileLabel { get; set; }
        public string FollowingActivitiesFileLabel { get; set; }


        // All files for Event Location
        public string VendorsTableFileLabel { get; set; }
        public string ExhibitorsTableFileLabel { get; set; }
        public string CertificationOfEventLocationFileLabel { get; set; }

        public string LACertificationFileLabel { get; set; }
        public string AllVendorsCertificationsFileLabel { get; set; }
        public string AllBrochuresFileLabel { get; set; }
        public string CompleteScheduleOfEventsFileLabel { get; set; }
        public string WaiverReleasesSignedFileLabel { get; set; }
        public string DiagramOrSitePlanFileLabel { get; set; }
        public string FiveYearLossHistoryFileLabel { get; set; }
        public string EvacuationParkAndTrafficPlanDiagramFileLabel { get; set; }

        /////////////////////////////////////////// Testing to here

        // Final Section Form Variables
        public string ApplicantSignature { get; set; }
        public string ApplicantTitle { get; set; }
        public DateTime ApplicationDate { get; set; }
        public string SupervisorInitials { get; set; }
        public DateTime AssemblingsPermitSignedDate { get; set; }

        // Separate Table: Permit //Variables with "Row" already have a value given at construction time

        public string SecurityDepositRow { get; set; }
        public string SecurityDepositRadio { get; set; }
        public string SecurityDepositApproval { get; set; }
        public DateTime SecurityDepositSignedDate { get; set; }

        public string BusinessLicenseRow { get; set; }
        public string BusinessLicenseRadio { get; set; }
        public string BusinessLicenseApproval { get; set; }
        public DateTime BusinessLicenseSignedDate { get; set; }

        public string DancePermitRow { get; set; }
        public string DancePermitRadio { get; set; }
        public string DancePermitApproval { get; set; }
        public DateTime DancePermitSignedDate { get; set; }

        public string EnvironmentalHealthPermitRow { get; set; }
        public string EnvironmentalHealthPermitRadio { get; set; }
        public string EnvironmentalHealthPermitApproval { get; set; }
        public DateTime EnvironmentalHealthPermitSignedDate { get; set; }

        public string ABCLicenseRow { get; set; }
        public string ABCLicenseRadio { get; set; }
        public string ABCLicenseApproval { get; set; }
        public DateTime ABCLicenseSignedDate { get; set; }

        public string PoliceServicesRow { get; set; }
        public string PoliceServicesRadio { get; set; }
        public string PoliceServicesApproval { get; set; }
        public DateTime PoliceServicesSignedDate { get; set; }

        public string AssemblagePermitRow { get; set; }
        public string AssemblagePermitRadio { get; set; }
        public string AssemblagePermitApproval { get; set; }
        public DateTime AssemblagePermitSignedDate { get; set; }

        public string SpecialEventPermitRow { get; set; }
        public string SpecialEventPermitRadio { get; set; }
        public string SpecialEventPermitApproval { get; set; }
        public DateTime SpecialEventPermitSignedDate { get; set; }

        public string StreetClosureRow { get; set; }
        public string StreetClosureRadio { get; set; }
        public string StreetClosureApproval { get; set; }
        public DateTime StreetClosureSignedDate { get; set; }

        public string TentCanopyApprovalRow { get; set; }
        public string TentCanopyApprovalRadio { get; set; }
        public string TentCanopyApprovalApproval { get; set; }
        public DateTime TentCanopyApprovalSignedDate { get; set; }

        public string ElectricianServicesRow { get; set; }
        public string ElectricianServicesRadio { get; set; }
        public string ElectricianServicesApproval { get; set; }
        public DateTime ElectricianServicesSignedDate { get; set; }

        public string LiquorLicenseRow { get; set; }
        public string LiquorLicenseRadio { get; set; }
        public string LiquorLicenseApproval { get; set; }
        public DateTime LiquorLicenseSignedDate { get; set; }

        public string LiabilityInsuranceRow { get; set; }
        public string LiabilityInsuranceRadio { get; set; }
        public string LiabilityInsuranceApproval { get; set; }
        public DateTime LiabilityInsuranceSignedDate { get; set; }

        public string SupplierInsuranceRow { get; set; }
        public string SupplierInsuranceRadio { get; set; }
        public string SupplierInsuranceApproval { get; set; }
        public DateTime SupplierInsuranceSignedDate { get; set; }

        public string VendorInsuranceRow { get; set; }
        public string VendorInsuranceRadio { get; set; }
        public string VendorInsuranceApproval { get; set; }
        public DateTime VendorInsuranceSignedDate { get; set; }

        //public FinalSectionPermitsList finalSectionListOfPermits { get; set; } Can't get this to work

        // Arrays for tables with a lot of rows
        public EventTableRow[] eventTableRows { get; set; }
        public ActivityTableRow[] activityTableRows { get; set; }
        public MusicArtistsTableRow[] musicArtistsTableRows { get; set; }
        public VendorTableRow[] vendorTableRows { get; set; }
        public ExhibitorTableRow[] exhibitorTableRows { get; set; }
        public PastEventRow[] pastEventTableRows { get; set; }
        public StreetClosureRow[] streetClosureRows { get; set; }

        // Lists for retrieving tables with a lot of rows
        public List<EventTableRow> returningEventTableRows = new List<EventTableRow>();
        public List<ActivityTableRow> returningActivityTableRows = new List<ActivityTableRow>();
        public List<MusicArtistsTableRow> returningMusicArtistsTableRows = new List<MusicArtistsTableRow>();
        public List<VendorTableRow> returningVendorTableRows = new List<VendorTableRow>();
        public List<ExhibitorTableRow> returningExhibitorTableRows = new List<ExhibitorTableRow>();
        public List<PastEventRow> returningPastEventTableRows = new List<PastEventRow>();
        public List<StreetClosureRow> returningStreetCLosureTableRows = new List<StreetClosureRow>();
    }

}
