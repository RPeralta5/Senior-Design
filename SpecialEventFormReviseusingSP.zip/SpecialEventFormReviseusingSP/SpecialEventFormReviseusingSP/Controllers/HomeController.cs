﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SpecialEventFormReviseusingSP.Models;

using System.Data.SqlClient;

namespace SpecialEventFormReviseusingSP.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SubmitApplication(RegisterInformation registerInformation)
        {
            //ViewBag.Message = string.Format("Hello {0}.\\nCurrent Date and Time: {1}", name, DateTime.Now.ToString());
            if (registerInformation.Password.ToString() == "" && registerInformation.ApplicationID == "")
            {
                var length = 16;
                string charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789`~!@#$%^&*()-_=+[{]}|;:,<.>/?";
                //password = "";
                for (int i = 0, n = charset.Length; i < length; ++i)
                {
                    // password += charset.charAt(Math.floor(Math.random() * n));
                }

                int agreement = 0;
                if (registerInformation.Agreement)
                {
                    agreement = 1;
                }
            }



            string connectionString = @" Data Source = DESKTOP - FSJF92K\JWSQL; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
            string queryString = " Insert into ImportantNotice values";

            using (SqlConnection connection = new SqlConnection(
            connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(queryString, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                }
            }
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
