﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventFormReviseusingSP.Models
{
    public class RegisterInformation
    {
        public string ApplicationID { get; set; }
        public string Password { get; set; }
        public bool Agreement { get; set; }

        public bool NameIsAIndividual { get; set; }
        public bool NameIsACorporation { get; set; }
        public bool NameIsATrustOfEstate { get; set; }
        public bool NameIsAUnicorpAssoc { get; set; }
        public bool NameIsAGeneralPartnership { get; set; }
        public bool NameIsALLCorLLP { get; set; }
        public bool NameIsAPublicAgency { get; set; }
        public bool NameIsALaborUnion { get; set; }
        public bool NameIsAInformalGroup { get; set; }
        public bool NameIsALimitedPartnership { get; set; }
        public bool NameIsANotForProfit { get; set; }
        public bool NameIsARegliousGroup { get; set; }
        public bool NameIsAJointVenture { get; set; }

        public bool NameIsAOther { get; set; }
        public bool NameIsAOtherIs { get; set; }

        public bool NameAsAppeared { get; set; }
        public bool DoingBusinessAs { get; set; }
        public bool MailingAddress { get; set; }
        public bool ApplicantCity { get; set; }
        public bool ApplicantState { get; set; }
        public bool ApplicantZip { get; set; }
        public bool ApplicantContact { get; set; }
        public bool ApplicantEmail { get; set; }
        public bool ApplicantHomePhone { get; set; }
        public bool ApplicantBusinessPhone { get; set; }
        public bool ApplicantFax { get; set; }
        public bool ApplicantWebAddress { get; set; }

    }

}
