﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using GoogleMap1.Models;

namespace GoogleMap1.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        /*
        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }
        */

        public IActionResult LatAndLongSearch(double latitude, double longitude)
        {
            ViewBag.Ilatitude = latitude;
            ViewBag.Ilongitude = longitude;

            return View();
        }

        public IActionResult AutoCompleteAddressSearch()
        {
            return View();
        }

        public IActionResult Geolocation()
        {
            return View();
        }

        public IActionResult DirectionsWithText()
        {
            return View();
        }

        public IActionResult DirectionsWithAutoComplete()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
