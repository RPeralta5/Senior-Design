﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventsForm03162020.Models
{
    public class RegisterInformation
    {
        public RegisterInformation()
        {
            //Permit row labels
            SecurityDepositRow = "SecurityDepositRow";
            BusinessLicenseRow = "BusinessLicenseRow";
            DancePermitRow = "DancePermitRow";
            EnvironmentalHealthPermitRow = "EnvironmentalHealthPermitRow";
            ABCLicenseRow = "ABCLicenseRow";
            PoliceServicesRow = "PoliceServicesRow";
            AssemblagePermitRow = "AssemblagePermitRow";
            SpecialEventPermitRow = "SpecialEventPermitRow";
            StreetClosureRow = "StreedClosureRow";
            TentCanopyApprovalRow = "TenCanopyApprovalRow";
            ElectricianServicesRow = "ElectricianServicesRow";
            LiquorLicenseRow = "LiquorLicenseRow";
            LiabilityInsuranceRow = "LiabilityInsuranceRow";
            SupplierInsuranceRow = "SupplierInsuranceRow";
            VendorInsuranceRow = "VendorInsuranceRow";

            //eventRows[0] = new EventTableRow();

        }
        public RegisterInformation(int id, string pw)
        {
            this.ApplicationID = id;
            this.Password = pw;

            //Permit row labels
            SecurityDepositRow = "SecurityDepositRow";
            BusinessLicenseRow = "BusinessLicenseRow";
            DancePermitRow = "DancePermitRow";
            EnvironmentalHealthPermitRow = "EnvironmentalHealthPermitRow";
            ABCLicenseRow = "ABCLicenseRow";
            PoliceServicesRow = "PoliceServicesRow";
            AssemblagePermitRow = "AssemblagePermitRow";
            SpecialEventPermitRow = "SpecialEventPermitRow";
            StreetClosureRow = "StreedClosureRow";
            TentCanopyApprovalRow = "TenCanopyApprovalRow";
            ElectricianServicesRow = "ElectricianServicesRow";
            LiquorLicenseRow = "LiquorLicenseRow";
            LiabilityInsuranceRow = "LiabilityInsuranceRow";
            SupplierInsuranceRow = "SupplierInsuranceRow";
            VendorInsuranceRow = "VendorInsuranceRow";

            //eventRows[0] = new EventTableRow();

        }

        // Important Notice Form Variables
        public int ApplicationID { get; set; }
        public string Password { get; set; }
        public bool Agreement { get; set; }

        // ApplicantInformation Form Variables
        public string NameIsAIndividual { get; set; }
        public string NameIsACorporation { get; set; }
        public string NameIsATrustOfEstate { get; set; }
        public string NameIsAUnicorpAssoc { get; set; }
        public string NameIsAGeneralPartnership { get; set; }
        public string NameIsALLCorLLP { get; set; }
        public string NameIsAPublicAgency { get; set; }
        public string NameIsALaborUnion { get; set; }
        public string NameIsAInformalGroup { get; set; }
        public string NameIsALimitedPartnership { get; set; }
        public string NameIsANotForProfit { get; set; }
        public string NameIsARegliousGroup { get; set; }
        public string NameIsAJointVenture { get; set; }

        public string NameIsAOther { get; set; }
        public string NameIsAOtherIs { get; set; }

        public string NameAsAppeared { get; set; }
        public string DoingBusinessAs { get; set; }
        public string MailingAddress { get; set; }
        public string ApplicantCity { get; set; }
        public string ApplicantState { get; set; }
        public int ApplicantZip { get; set; }
        public string ApplicantContact { get; set; }
        public string ApplicantEmail { get; set; }
        public int ApplicantHomePhone { get; set; }
        public int ApplicantBusinessPhone { get; set; }
        public int ApplicantFax { get; set; }
        public string ApplicantWebAddress { get; set; }

        // Event Information Form Variables
        public string EventName { get; set; }
        public string EventFile { get; set; }
        public string ActivitiesDescription { get; set; }
        public string ActivitiesDescriptionFile { get; set; }

        // insured name or company
        public string InsuredIsOwner { get; set; }
        public string InsuredIsManager { get; set; }
        public string InsuredIsThirdParty { get; set; }
        public string EventIsPrivacy { get; set; }

        // admission and ticket
        public string AdmissionCharge { get; set; }
        public decimal AdmissionCost { get; set; }
        public bool SellTicket { get; set; }
        public int SellHowManyTickets { get; set; }
        public decimal TotalTicketSalesAmount { get; set; }
        public decimal PricePerTicket { get; set; }
        public string HowToSellTicket { get; set; }
        public string WhoSellTickets { get; set; }
        public string RecieveDonate { get; set; }

        // type of seating
        public string SeatType1 { get; set; }
        public string SeatType2 { get; set; }
        public string SeatType3 { get; set; }
        public string SeatType4 { get; set; }
        public string SeatType5 { get; set; }

        // security
        public int NumOfPrivateSecurityPersons { get; set; }
        public int NumOfPoliceOrSheriffPersons { get; set; }
        public int NumOfPeerGroupOrUshersPersons { get; set; }
        public int NumOfEmployeesPersons { get; set; }
        public int NumOfParentChaperonsPersons { get; set; }
        public int NumOfVolunteersPersons { get; set; }

        // safety and insurance
        public string Armed { get; set; }
        public string BagCheck { get; set; }
        public string FirstAid { get; set; }
        public string CompanyForFirstAide { get; set; }
        public string RecievedInsurance { get; set; }

        // parking
        public string EntranceExit { get; set; }
        public string AccessibleParking { get; set; }

        // event
        public string EventAdvertise { get; set; }
        public string EventIsOnWebsite { get; set; }
        public string EventWebsite { get; set; }
        public string EventTelevised { get; set; }
        public string EventRadio { get; set; }
        public string EventNewsPaper { get; set; }
        public string EventBrochure { get; set; }
        public string EventHandOut { get; set; }
        public string EventBillBoard { get; set; }
        public string EventPoster { get; set; }
        public string EventOther { get; set; }

        // alcohol information
        public string AlcoholServe { get; set; }
        public string AlcoholIsSold { get; set; }
        public string AlcoholFee { get; set; }

        // event finance
        public string EventFee { get; set; }
        public string EventDonation { get; set; }

        // alcohol type
        public string AlcoholType1 { get; set; }
        public string AlcoholType2 { get; set; }
        public string AlcoholType3 { get; set; }

        // alcohol vending
        public string AlcoholVending { get; set; }
        public string AlcoholVendingInsurance { get; set; }
        public decimal EstimatedAlcoholSales { get; set; }
        public int NumOfAlcoholLocations { get; set; }
        public string LiquorLicense { get; set; }
        public string LiquorDrinkArea { get; set; }
        public string LiquorIdentification { get; set; }
        public string DrinkingAge { get; set; }
        public string LiquorServingLimit { get; set; }
        public string LiquorStaffMonitor { get; set; }
        public string LiquorBarClose { get; set; }

        // activity and liability
        public string AthleticRecreationalActivity { get; set; }
        public string WaiverAndLiabilityProcedure { get; set; }
        public string LiabilityReleaseFile { get; set; }

        //  music
        public string HaveMusic { get; set; }
        public string TypeOfMusic1 { get; set; } //Under Testing
        public string TypeOfMusic2 { get; set; } //Under Testing
        public string TypeOfMusic3 { get; set; } //Under Testing
        public string AmplifiedMusic { get; set; }
        public int NumOfBandsOrArtists { get; set; }

        // power and electricity
        public string OwnElectricity { get; set; }
        public string ElectricityArranging { get; set; }

        // entertainment
        public string OtherEntertainment { get; set; }
        public string OtherEntertainmentDescription { get; set; }

        // activities options
        public string ActivityStuff { get; set; }
        public string HiredCompanyForActivities { get; set; }
        public string FollowingActivitiesFile { get; set; }
        public string ExplainProcedureForWaivers { get; set; }

        // Separate Table: type of music played 

        public string MusicType1 { get; set; }
        public string MusicType2 { get; set; }
        public string MusicType3 { get; set; }
        public string MusicType4 { get; set; }
        public string MusicType5 { get; set; }
        public string MusicType6 { get; set; }
        public string MusicType7 { get; set; }
        public string MusicType8 { get; set; }
        public string MusicType9 { get; set; }
        public string MusicType10 { get; set; }
        public string MusicType11 { get; set; }
        public string MusicType12 { get; set; }
        public string MusicType13 { get; set; }
        public string MusicType14 { get; set; }
        public string MusicType15 { get; set; }
        public string MusicType16 { get; set; }
        public string MusicType17 { get; set; }
        public string MusicType18 { get; set; }
        public string MusicType19 { get; set; }
        public string MusicType20 { get; set; }
        public string MusicType21 { get; set; }
        public string MusicType22 { get; set; }
        public string MusicType23 { get; set; }
        public string MusicType24 { get; set; }
        public string MusicType25 { get; set; }
        public string MusicType26 { get; set; }
        public string MusicType27 { get; set; }
        public string MusicType28 { get; set; }
        public string MusicType29 { get; set; }
        public string MusicType30 { get; set; }
        public string MusicType31 { get; set; }
        public string MusicType32 { get; set; }
        public string MusicType33 { get; set; }
        public string MusicType34 { get; set; }
        public string MusicType35 { get; set; }
        public string MusicType36 { get; set; }
        public string MusicType37 { get; set; }
        public string MusicType38 { get; set; }
        public string OtherTypeOfMusic { get; set; }

        // Separate Table: FollowingActivities1 Included

        public string ClimbWall { get; set; }
        public string SkateBoard { get; set; }
        public string RollerAct { get; set; }
        public string CycleAct { get; set; }
        public string WaterAct { get; set; }
        public string GunAct { get; set; }
        public string FireAct { get; set; }
        public string ArmoryAct { get; set; }
        public string ChemicalAct { get; set; }
        public string MedicalAct { get; set; }
        public string DemolitionAct { get; set; }
        public string ScaffoldingfAct { get; set; }

        // Separate Table: FollowingActivities2 Included

        public string AirRiding { get; set; }
        public string TerrainBoarding { get; set; }
        public string BaseJumping { get; set; }
        public string Bouldering { get; set; }
        public string BoxingMaritalArts { get; set; }
        public string BungeeAct { get; set; }
        public string CircusCarnival { get; set; }
        public string Concert6HrAct { get; set; }
        public string ConcertDanceAct { get; set; }
        public string PlatformBoardDiving { get; set; }
        public string HangGliding { get; set; }
        public string KayalRaftCanoeing { get; set; }
        public string MechanicalRide { get; set; }
        public string MotorSportEquipment { get; set; }
        public string MountainBiking { get; set; }
        public string PowerBoats { get; set; }
        public string ProSportCash { get; set; }
        public string PyroFireAct { get; set; }
        public string RapRockConcert { get; set; }
        public string RockClimbAct { get; set; }
        public string RodeoRopeAct { get; set; }
        public string SkinDiveAct { get; set; }
        public string ScubaDiveAct { get; set; }
        public string TractorTruckPull { get; set; }
        public string Trampoline { get; set; }

        // Event Location Form Variables
        public string FacilityName { get; set; }
        public string FacilityStreetName { get; set; }
        public string FacilityCity { get; set; }
        public string FacilityState { get; set; }
        public int FacilityZip { get; set; }
        public string OutdoorAreaSize { get; set; }
        public string OutdoorAreaInsured { get; set; }
        public string IsVendorSellingAlcohol { get; set; }
        public string VendorsTableFile { get; set; }
        public string ExhibitorsTableFile { get; set; }
        public string HeldBefore { get; set; }
        public string CertificationOfEventLocationFile { get; set; }
        public string EvacuationPlan { get; set; }
        public string EvacuationPlanDescription { get; set; }
        public string IsThereMedicalPresence { get; set; }
        public string NumOfDoctors { get; set; }
        public string NumOfParamedics { get; set; }
        public string NumOfNurses { get; set; }
        public string NumOfEMTOrEMS { get; set; }
        public string NumOfOther { get; set; }
        public string AmbulanceOnSite { get; set; }

        public string StreetClosure { get; set; }
        public string TrafficMitigation { get; set; }
        public string TrafficMitigationDescription { get; set; }

        public string LACertificationFile { get; set; }
        public string AllVendorsCertificationsFile { get; set; }
        public string AllBrochuresFile { get; set; }
        public string CompleteScheduleOfEventsFile { get; set; }
        public string WaiverReleasesSignedFile { get; set; }
        public string DiagramOrSitePlanFile { get; set; }
        public string FiveYearLossHistoryFile { get; set; }
        public string EvacuationParkAndTrafficPlanDiagramFile { get; set; }

        /////////////////////////////////////////// Testing to here

        // Event Location Form Variables
        public string ApplicantSignature { get; set; }
        public string ApplicantTitle { get; set; }
        public string ApplicationDate { get; set; }
        public string SupervisorInitials { get; set; }
        public string AssemblingsPermitSignedDate { get; set; }

        // Separate Table: Permit
        public string SecurityDepositRow { get; set; }
        public string SecurityDepositRadio { get; set; }
        public string SecurityDepositApproval { get; set; }
        public string SecurityDepositSignedDate { get; set; }

        public string BusinessLicenseRow { get; set; }
        public string BusinessLicenseRadio { get; set; }
        public string BusinessLicenseApproval { get; set; }
        public string BusinessLicenseSignedDate { get; set; }

        public string DancePermitRow { get; set; }
        public string DancePermitRadio { get; set; }
        public string DancePermitApproval { get; set; }
        public string DancePermitSignedDate { get; set; }

        public string EnvironmentalHealthPermitRow { get; set; }
        public string EnvironmentalHealthPermitRadio { get; set; }
        public string EnvironmentalHealthPermitApproval { get; set; }
        public string EnvironmentalHealthPermitSignedDate { get; set; }

        public string ABCLicenseRow { get; set; }
        public string ABCLicenseRadio { get; set; }
        public string ABCLicenseApproval { get; set; }
        public string ABCLicenseSignedDate { get; set; }

        public string PoliceServicesRow { get; set; }
        public string PoliceServicesRadio { get; set; }
        public string PoliceServicesApproval { get; set; }
        public string PoliceServicesSignedDate { get; set; }

        public string AssemblagePermitRow { get; set; }
        public string AssemblagePermitRadio { get; set; }
        public string AssemblagePermitApproval { get; set; }
        public string AssemblagePermitSignedDate { get; set; }

        public string SpecialEventPermitRow { get; set; }
        public string SpecialEventPermitRadio { get; set; }
        public string SpecialEventPermitApproval { get; set; }
        public string SpecialEventPermitSignedDate { get; set; }

        public string StreetClosureRow { get; set; }
        public string StreetClosureRadio { get; set; }
        public string StreetClosureApproval { get; set; }
        public string StreetClosureSignedDate { get; set; }

        public string TentCanopyApprovalRow { get; set; }
        public string TentCanopyApprovalRadio { get; set; }
        public string TentCanopyApprovalApproval { get; set; }
        public string TentCanopyApprovalSignedDate { get; set; }

        public string ElectricianServicesRow { get; set; }
        public string ElectricianServicesRadio { get; set; }
        public string ElectricianServicesApproval { get; set; }
        public string ElectricianServicesSignedDate { get; set; }

        public string LiquorLicenseRow { get; set; }
        public string LiquorLicenseRadio { get; set; }
        public string LiquorLicenseApproval { get; set; }
        public string LiquorLicenseSignedDate { get; set; }

        public string LiabilityInsuranceRow { get; set; }
        public string LiabilityInsuranceRadio { get; set; }
        public string LiabilityInsuranceApproval { get; set; }
        public string LiabilityInsuranceSignedDate { get; set; }

        public string SupplierInsuranceRow { get; set; }
        public string SupplierInsuranceRadio { get; set; }
        public string SupplierInsuranceApproval { get; set; }
        public string SupplierInsuranceSignedDate { get; set; }

        public string VendorInsuranceRow { get; set; }
        public string VendorInsuranceRadio { get; set; }
        public string VendorInsuranceApproval { get; set; }
        public string VendorInsuranceSignedDate { get; set; }

        // Arrays for tables with a lot of rows
        public EventTableRow[] eventTableRows { get; set; }
        public ActivityTableRow[] activityTableRows { get; set; }
        public MusicArtistsTableRow[] musicArtistsTableRows { get; set; }
        public VendorTableRow[] vendorTableRows { get; set; }
        public ExhibitorTableRow[] exhibitorTableRows { get; set; }
        public PastEventRow[] pastEventTableRows { get; set; }
        public StreetClosureRow[] streetClosureRows { get; set; }
    }

}
