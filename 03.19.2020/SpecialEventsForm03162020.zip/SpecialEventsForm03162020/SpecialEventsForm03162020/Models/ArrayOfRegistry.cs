﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventsForm03162020.Models
{
    public class ArrayOfRegistry
    {
        public List<RegisterInformation> ListArray = new List<RegisterInformation>();
        public static IEnumerable<RegisterInformation> Registry
        {
            get
            {
                return Registry;
            }
        }

        public void AddRegistry(RegisterInformation RegInfo)
        {
            ListArray.Add(RegInfo);
        }
    }
}
