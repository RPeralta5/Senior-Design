﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SpecialEventsForm03162020.Models
{
    public class MusicArtistsTableRow
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        [DataType(DataType.PhoneNumber)]
        public int PhoneNumber { get; set; }
        public string Contact { get; set; }
    }
}
